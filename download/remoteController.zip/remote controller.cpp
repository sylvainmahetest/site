#include <GpioRead.h>
#include <GpioWrite.h>
#include <AnalogRead.h>
#include <SoundWrite.h>
#include <Timer.h>
#include <Delay.h>
#include <Math.h>
#include <Filter.h>
#include <Hysteresis.h>
#include <SpiMax7219.h>
#include <SpiNrf24l01p.h>
#include <Eeprom.h>
#include <Tool.h>

int main()
{
	GpioRead switchPowerState = GpioRead (1, false, 10);
	GpioWrite switchPowerHold = GpioWrite (2);
	SpiMax7219 display = SpiMax7219 (3);
	unsigned char iterationAnimation = 0;
	GpioRead buttonSelect = GpioRead (9, true, 100);
	GpioRead switchCut = GpioRead (10, true, 10);
	GpioRead switchAuxiliaryA1 = GpioRead (11, true, 10);
	GpioRead switchAuxiliaryA2 = GpioRead (12, true, 10);
	GpioRead switchAuxiliaryB1 = GpioRead (13, true, 10);
	GpioRead switchAuxiliaryB2 = GpioRead (14, true, 10);
	GpioRead switchAuxiliaryC1 = GpioRead (15, true, 10);
	GpioRead switchAuxiliaryC2 = GpioRead (16, true, 10);
	GpioRead switchTrimThrottle1 = GpioRead (17, true, 10);
	GpioRead switchTrimThrottle2 = GpioRead (18, true, 10);
	GpioRead switchTrimPitch1 = GpioRead (19, true, 10);
	GpioRead switchTrimPitch2 = GpioRead (20, true, 10);
	GpioRead switchTrimRoll1 = GpioRead (21, true, 10);
	GpioRead switchTrimRoll2 = GpioRead (22, true, 10);
	GpioRead switchTrimYaw1 = GpioRead (23, true, 10);
	GpioRead switchTrimYaw2 = GpioRead (24, true, 10);
	AnalogRead potentiometerSelect = AnalogRead (25);
	AnalogRead potentiometerThrottle = AnalogRead (26);
	AnalogRead potentiometerPitch = AnalogRead (27);
	AnalogRead potentiometerRoll = AnalogRead (28);
	AnalogRead potentiometerYaw = AnalogRead (29);
	AnalogRead potentiometerAuxiliaryD = AnalogRead (30);
	AnalogRead voltageBatteryControl = AnalogRead (31);
	bool flipFlopTransmit = false;
	SpiNrf24l01p channelThrottleRollAuxiliaryCAuxiliaryD = SpiNrf24l01p (1);
	SpiNrf24l01p channelPitchYawCutAuxiliaryAAuxiliaryBFailSafeUpdate = SpiNrf24l01p (2);
	SpiNrf24l01p channelVoltageBatteryModelTelemetryWatchDogUpdated = SpiNrf24l01p (3);
	SpiNrf24l01p channelSettingBatteryTimer = SpiNrf24l01p (4);
	SpiNrf24l01p channelSettingTrim = SpiNrf24l01p (5);
	SpiNrf24l01p channelSettingStick = SpiNrf24l01p (6);
	SpiNrf24l01p channelSettingOptionWord1 = SpiNrf24l01p (7);
	SpiNrf24l01p channelSettingOption1 = SpiNrf24l01p (8);
	SpiNrf24l01p channelSettingOptionWord2 = SpiNrf24l01p (9);
	SpiNrf24l01p channelSettingOption2 = SpiNrf24l01p (10);
	SpiNrf24l01p channelSettingOptionWord3 = SpiNrf24l01p (11);
	SpiNrf24l01p channelSettingOption3 = SpiNrf24l01p (12);
	SpiNrf24l01p channelSettingOptionWord4 = SpiNrf24l01p (13);
	SpiNrf24l01p channelSettingOption4 = SpiNrf24l01p (14);
	SpiNrf24l01p channelSettingOptionWord5 = SpiNrf24l01p (15);
	SpiNrf24l01p channelSettingOption5 = SpiNrf24l01p (16);
	SpiNrf24l01p channelSettingOptionWord6 = SpiNrf24l01p (17);
	SpiNrf24l01p channelSettingOption6 = SpiNrf24l01p (18);
	SpiNrf24l01p channelSettingOptionWord7 = SpiNrf24l01p (19);
	SpiNrf24l01p channelSettingOption7 = SpiNrf24l01p (20);
	SpiNrf24l01p channelSettingOptionWord8 = SpiNrf24l01p (21);
	SpiNrf24l01p channelSettingOption8 = SpiNrf24l01p (22);
	SpiNrf24l01p channelSettingOptionWord9 = SpiNrf24l01p (23);
	SpiNrf24l01p channelSettingOption9 = SpiNrf24l01p (24);
	SpiNrf24l01p channelSettingOptionWord10 = SpiNrf24l01p (25);
	SpiNrf24l01p channelSettingOption10 = SpiNrf24l01p (26);
	SpiNrf24l01p channelSettingOptionWord11 = SpiNrf24l01p (27);
	SpiNrf24l01p channelSettingOption11 = SpiNrf24l01p (28);
	SpiNrf24l01p channelSettingOptionWord12 = SpiNrf24l01p (29);
	SpiNrf24l01p channelSettingOption12 = SpiNrf24l01p (30);
	SpiNrf24l01p channelSettingOptionWord13 = SpiNrf24l01p (31);
	SpiNrf24l01p channelSettingOption13 = SpiNrf24l01p (32);
	SpiNrf24l01p channelSettingOptionWord14 = SpiNrf24l01p (33);
	SpiNrf24l01p channelSettingOption14 = SpiNrf24l01p (34);
	SpiNrf24l01p channelSettingOptionWord15 = SpiNrf24l01p (35);
	SpiNrf24l01p channelSettingOption15 = SpiNrf24l01p (36);
	SpiNrf24l01p channelSettingOptionWord16 = SpiNrf24l01p (37);
	SpiNrf24l01p channelSettingOption16 = SpiNrf24l01p (38);
	Timer timeButtonSelect = Timer();
	unsigned long long timeButtonSelectPrevious = 0;
	Timer timeDisplay = Timer();
	unsigned long long timeDisplayPrevious = 0;
	Timer timeSound = Timer();
	unsigned long long timeSoundPrevious = 0;
	Timer timer = Timer();
	bool timerStarted = false;
	bool timerEnded = false;
	unsigned char brightness = 16;
	bool exit = false;
	bool lowVoltageBatteryControl = false;
	bool lowVoltageBatteryModel = false;
	Filter filterPotentiometerSetting = Filter (250, true);
	Hysteresis hysteresisPotentiometerSetting = Hysteresis();
	Filter filterVoltageBatteryControl = Filter (500, true);
	Hysteresis hysteresisVoltageBatteryControl = Hysteresis();
	Filter filterVoltageBatteryModel = Filter (500, true);
	Hysteresis hysteresisVoltageBatteryModel = Hysteresis();
	Filter filterTelemetry = Filter (500, true);
	Hysteresis hysteresisTelemetry = Hysteresis();
	Delay delayDisplayLowVoltageBatteryControl = Delay (500, true);
	Delay delaySoundLowVoltageBatteryControl = Delay (200, true);
	Delay delayDisplayLowVoltageBatteryModel = Delay (500, true);
	Delay delaySoundLowVoltageBatteryModel = Delay (1000, true);
	Delay delayDisplayTimerEnded = Delay (500, true);
	Delay delaySoundTimerEnded = Delay (1000, true);
	Delay delaySoundAlarm = Delay (30000, false);
	Delay delayTrimThrottle = Delay (1000, false);
	Delay delayTrimPitch = Delay (1000, false);
	Delay delayTrimRoll = Delay (1000, false);
	Delay delayTrimYaw = Delay (1000, false);
	Hysteresis select = Hysteresis();
	unsigned char selectPrevious = 0;
	bool onAir = true;
	bool downloadedSetting = true;
	bool locked = false;
	unsigned char stateLocked = 0;
	bool resetShutdown = false;
	bool menuSetting = false;
	unsigned char stateSettingTune = 2;
	const char *WORD_EXIT = "  exit  ";
	bool updateNeeded = false;
	bool updateLeaved = false;
	const char *WORD_UPDATE = " update ";
	const char *WORD_UPDATE_NEEDED = "-update-";
	unsigned char displayVoltageBatteryControl = 0;
	unsigned char displayVoltageBatteryModel = 0;
	unsigned char displayTimerEnded = 0;
	bool soundOnline = false;
	bool soundOffline = false;
	bool soundLowVoltageBatteryControl = false;
	unsigned char soundLowVoltageBatteryModel = 0;
	unsigned char soundWatchDog = 0;
	unsigned char soundTimerEnded = 0;
	bool soundAlarm = false;
	bool soundLock = false;
	bool soundLocked = false;
	bool soundSelect = false;
	bool soundTimerStart = false;
	bool soundSwitch1 = false;
	bool soundSwitch2 = false;
	bool soundSwitch3 = false;
	bool soundTune = false;
	bool soundOk = false;
	bool soundNull = false;
	bool inhibitSound = true;
	const unsigned char TIME_SPACE_SOUND = 10;
	unsigned char iterationFilterPotentiometer = 0;
	const unsigned char COUNT_FILTER_POTENTIOMETER = 32;
	const unsigned char OFFSET_POTENTIOMETER = 4;
	float filterPotentiometerThrottle = 0;
	unsigned int throttle = 0;
	unsigned int throttleRaw = 0;
	unsigned int settingThrottleTune = 0;
	unsigned int settingMinThrottle = 0;
	unsigned int settingMinThrottleTune = 0;
	unsigned int settingMaxThrottle = 0;
	unsigned int settingMaxThrottleTune = 0;
	float filterPotentiometerPitch = 0;
	unsigned int pitch = 0;
	unsigned int settingPitchTune = 0;
	unsigned int settingMinPitch = 0;
	unsigned int settingMinPitchTune = 0;
	unsigned int settingMaxPitch = 0;
	unsigned int settingMaxPitchTune = 0;
	float filterPotentiometerRoll = 0;
	unsigned int roll = 0;
	unsigned int settingRollTune = 0;
	unsigned int settingMinRoll = 0;
	unsigned int settingMinRollTune = 0;
	unsigned int settingMaxRoll = 0;
	unsigned int settingMaxRollTune = 0;
	float filterPotentiometerYaw = 0;
	unsigned int yaw = 0;
	unsigned int settingYawTune = 0;
	unsigned int settingMinYaw = 0;
	unsigned int settingMinYawTune = 0;
	unsigned int settingMaxYaw = 0;
	unsigned int settingMaxYawTune = 0;
	bool cut = false;
	bool cutPrevious = false;
	unsigned char auxiliaryA = 0;
	unsigned char auxiliaryAPrevious = 0;
	unsigned char auxiliaryB = 0;
	unsigned char auxiliaryBPrevious = 0;
	unsigned char auxiliaryC = 0;
	unsigned char auxiliaryCPrevious = 0;
	float filterPotentiometerAuxiliaryD = 0;
	unsigned int auxiliaryD = 0;
	unsigned int settingAuxiliaryDTune = 0;
	unsigned int settingMinAuxiliaryD = 0;
	unsigned int settingMinAuxiliaryDTune = 0;
	unsigned int settingMaxAuxiliaryD = 0;
	unsigned int settingMaxAuxiliaryDTune = 0;
	unsigned char failSafe = 0;
	unsigned char update = 0;
	unsigned char dataWatchDog = 0;
	unsigned char dataWatchDogPrevious = 0;
	Timer timeWatchDog = Timer();
	unsigned long long timeWatchDogPrevious = 0;
	bool watchDog = false;
	bool watchDogPrevious = false;
	bool updated = false;
	Delay delayBinding = Delay (500, false);
	Delay delayDotBinding = Delay (100, true);
	bool binding = false;
	const char *WORD_BINDING = "binding ";
	unsigned char dotBinding = 0;
	signed long dataSettingBatteryTimer = 0;
	signed long dataSettingTrim = 0;
	signed long dataSettingStick = 0;
	signed long dataSettingOption1 = 0;
	signed long dataSettingOption2 = 0;
	signed long dataSettingOption3 = 0;
	signed long dataSettingOption4 = 0;
	signed long dataSettingOption5 = 0;
	signed long dataSettingOption6 = 0;
	signed long dataSettingOption7 = 0;
	signed long dataSettingOption8 = 0;
	signed long dataSettingOption9 = 0;
	signed long dataSettingOption10 = 0;
	signed long dataSettingOption11 = 0;
	signed long dataSettingOption12 = 0;
	signed long dataSettingOption13 = 0;
	signed long dataSettingOption14 = 0;
	signed long dataSettingOption15 = 0;
	signed long dataSettingOption16 = 0;
	unsigned int settingVoltageBatteryModelLow = 0;
	unsigned int settingVoltageBatteryModelLowTune = 0;
	unsigned int settingTimerEnd = 0;
	unsigned int settingTimerEndTune = 0;
	unsigned int settingTimerTrigger = 0;
	unsigned int settingTimerTriggerTune = 0;
	unsigned char settingTrimThrottle = 255;
	unsigned char settingTrimThrottleTune = 255;
	unsigned char settingTrimPitch = 255;
	unsigned char settingTrimPitchTune = 255;
	unsigned char settingTrimRoll = 255;
	unsigned char settingTrimRollTune = 255;
	unsigned char settingTrimYaw = 255;
	unsigned char settingTrimYawTune = 255;
	bool settingInvertThrottle = false;
	bool settingInvertThrottleTune = false;
	bool settingInvertPitch = false;
	bool settingInvertPitchTune = false;
	bool settingInvertRoll = false;
	bool settingInvertRollTune = false;
	bool settingInvertYaw = false;
	bool settingInvertYawTune = false;
	unsigned char settingCurveThrottle = 0;
	unsigned char settingCurveThrottleTune = 0;
	unsigned char settingCurvePitch = 0;
	unsigned char settingCurvePitchTune = 0;
	unsigned char settingCurveRoll = 0;
	unsigned char settingCurveRollTune = 0;
	unsigned char settingCurveYaw = 0;
	unsigned char settingCurveYawTune = 0;
	unsigned char settingOptionWord [16][4] = {{0, 0, 0, 0}, {0, 0, 0, 0}, {0, 0, 0, 0}, {0, 0, 0, 0}, {0, 0, 0, 0}, {0, 0, 0, 0}, {0, 0, 0, 0}, {0, 0, 0, 0}, {0, 0, 0, 0}, {0, 0, 0, 0}, {0, 0, 0, 0}, {0, 0, 0, 0}, {0, 0, 0, 0}, {0, 0, 0, 0}, {0, 0, 0, 0}, {0, 0, 0, 0}};
	unsigned int settingOption [16] = {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
	unsigned int settingOptionTune [16] = {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
	unsigned int settingOptionMin [16] = {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
	unsigned int settingOptionMax [16] = {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
	bool settingOptionCenter [16] = {false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false};
	bool settingOptionDecimal [16] = {false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false};
	unsigned char mapSettingOption [16] = {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
	unsigned char iterationSettingOption = 0;
	unsigned char countSettingOption = 0;
	unsigned int settingTunePrevious = 0;
	const float SETUP_LOW_VOLTAGE_BATTERY_CONTROL = 6;
	const unsigned long SETUP_RFID = 1524003746;
	
	switchPowerHold.on();
	
	SoundWrite::pin (4);
	
	SoundWrite::add (128, 100);
	SoundWrite::add (256, 100);
	SoundWrite::add (0, 50);
	SoundWrite::add (256, 100);
	SoundWrite::add (512, 100);
	SoundWrite::add (0, 50);
	SoundWrite::add (512, 100);
	SoundWrite::add (1024, 100);
	SoundWrite::play (0, 0);
	
	for (iterationAnimation = 0; iterationAnimation < 4; iterationAnimation++)
	{
		display.clearDevice();
		display.draw (0b00110000, 4 - iterationAnimation);
		display.draw (0b00000110, 5 + iterationAnimation);
		Timer::pause (100);
		display.draw (0b00000110, 4 - iterationAnimation);
		display.draw (0b00110000, 5 + iterationAnimation);
		Timer::pause (100);
	}
	
	timeSound.start (0);
	
	while (exit == false)
	{
		timeSound.state();
		
		switchPowerState.read();
		potentiometerSelect.read();
		buttonSelect.read();
		switchCut.read();
		switchAuxiliaryA1.read();
		switchAuxiliaryA2.read();
		switchAuxiliaryB1.read();
		switchAuxiliaryB2.read();
		switchAuxiliaryC1.read();
		switchAuxiliaryC2.read();
		switchTrimThrottle1.read();
		switchTrimThrottle2.read();
		switchTrimPitch1.read();
		switchTrimPitch2.read();
		switchTrimRoll1.read();
		switchTrimRoll2.read();
		switchTrimYaw1.read();
		switchTrimYaw2.read();
		voltageBatteryControl.read();
		
		if (switchPowerState.bistable == false)
		{
			SoundWrite::add (1024, 100);
			SoundWrite::add (512, 100);
			SoundWrite::add (0, 50);
			SoundWrite::add (512, 100);
			SoundWrite::add (256, 100);
			SoundWrite::add (0, 50);
			SoundWrite::add (256, 100);
			SoundWrite::add (128, 100);
			SoundWrite::play (0, 0);
			
			for (iterationAnimation = 0; iterationAnimation < 4; iterationAnimation++)
			{
				display.clearDevice();
				display.draw (0b00000110, 1 + iterationAnimation);
				display.draw (0b00110000, 8 - iterationAnimation);
				Timer::pause (100);
				display.draw (0b00110000, 1 + iterationAnimation);
				display.draw (0b00000110, 8 - iterationAnimation);
				Timer::pause (100);
			}
			
			display.clearDevice();
			
			switchPowerHold.off();
			
			Timer::pause (1000);
			
			display.brightness (1);
			display.word ("turn off");
			
			for (iterationAnimation = 2; iterationAnimation < 16; iterationAnimation++)
			{
				Timer::pause (30);
				display.brightness (iterationAnimation);
			}
			
			while (true)
			{
			}
		}
		
		if (potentiometerSelect.value < 480 && selectPrevious == 1)
		{
			selectPrevious = 0;
			onAir = true;
			
			soundSelect = true;
		}
		else if (potentiometerSelect.value > 543 && selectPrevious == 0)
		{
			selectPrevious = 1;
			onAir = false;
			
			soundSelect = true;
		}
		
		if (buttonSelect.bistable == true)
		{
			exit = true;
			
			if (onAir == true)
			{
				soundOnline = true;
			}
			else
			{
				soundOffline = true;
			}
		}
		
		cut = switchCut.bistable;
		
		if (cut != cutPrevious)
		{
			cutPrevious = cut;
			
			if (cut == false)
			{
				soundSwitch1 = true;
			}
			else
			{
				soundSwitch2 = true;
			}
		}
		
		if (switchAuxiliaryA1.bistable == true)
		{
			auxiliaryA = 0;
		}
		else if (switchAuxiliaryA2.bistable == true)
		{
			auxiliaryA = 2;
		}
		else
		{
			auxiliaryA = 1;
		}
		
		if (auxiliaryA != auxiliaryAPrevious)
		{
			auxiliaryAPrevious = auxiliaryA;
			
			if (auxiliaryA == 0)
			{
				soundSwitch1 = true;
			}
			else if (auxiliaryA == 1)
			{
				soundSwitch2 = true;
			}
			else
			{
				soundSwitch3 = true;
			}
		}
		
		if (switchAuxiliaryB1.bistable == true)
		{
			auxiliaryB = 0;
		}
		else if (switchAuxiliaryB2.bistable == true)
		{
			auxiliaryB = 2;
		}
		else
		{
			auxiliaryB = 1;
		}
		
		if (auxiliaryB != auxiliaryBPrevious)
		{
			auxiliaryBPrevious = auxiliaryB;
			
			if (auxiliaryB == 0)
			{
				soundSwitch1 = true;
			}
			else if (auxiliaryB == 1)
			{
				soundSwitch2 = true;
			}
			else
			{
				soundSwitch3 = true;
			}
		}
		
		if (switchAuxiliaryC1.bistable == true)
		{
			auxiliaryC = 0;
		}
		else if (switchAuxiliaryC2.bistable == true)
		{
			auxiliaryC = 2;
		}
		else
		{
			auxiliaryC = 1;
		}
		
		if (auxiliaryC != auxiliaryCPrevious)
		{
			auxiliaryCPrevious = auxiliaryC;
			
			if (auxiliaryC == 0)
			{
				soundSwitch1 = true;
			}
			else if (auxiliaryC == 1)
			{
				soundSwitch2 = true;
			}
			else
			{
				soundSwitch3 = true;
			}
		}
		
		if (switchTrimThrottle1.monostable == true)
		{
			soundNull = true;
		}
		else if (switchTrimThrottle2.monostable == true)
		{
			soundNull = true;
		}
		else if (switchTrimThrottle1.bistable == true)
		{
			delayTrimThrottle.state();
			
			if (delayTrimThrottle.update == true)
			{
				soundNull = true;
				delayTrimThrottle.duration (50);
			}
		}
		else if (switchTrimThrottle2.bistable == true)
		{
			delayTrimThrottle.state();
			
			if (delayTrimThrottle.update == true)
			{
				soundNull = true;
				delayTrimThrottle.duration (50);
			}
		}
		else
		{
			delayTrimThrottle.duration (1000);
			delayTrimThrottle.reset();
		}
		
		if (switchTrimPitch1.monostable == true)
		{
			soundNull = true;
		}
		else if (switchTrimPitch2.monostable == true)
		{
			soundNull = true;
		}
		else if (switchTrimPitch1.bistable == true)
		{
			delayTrimPitch.state();
			
			if (delayTrimPitch.update == true)
			{
				soundNull = true;
				delayTrimPitch.duration (50);
			}
		}
		else if (switchTrimPitch2.bistable == true)
		{
			delayTrimPitch.state();
			
			if (delayTrimPitch.update == true)
			{
				soundNull = true;
				delayTrimPitch.duration (50);
			}
		}
		else
		{
			delayTrimPitch.duration (1000);
			delayTrimPitch.reset();
		}
		
		if (switchTrimRoll1.monostable == true)
		{
			soundNull = true;
		}
		else if (switchTrimRoll2.monostable == true)
		{
			soundNull = true;
		}
		else if (switchTrimRoll1.bistable == true)
		{
			delayTrimRoll.state();
			
			if (delayTrimRoll.update == true)
			{
				soundNull = true;
				delayTrimRoll.duration (50);
			}
		}
		else if (switchTrimRoll2.bistable == true)
		{
			delayTrimRoll.state();
			
			if (delayTrimRoll.update == true)
			{
				soundNull = true;
				delayTrimRoll.duration (50);
			}
		}
		else
		{
			delayTrimRoll.duration (1000);
			delayTrimRoll.reset();
		}
		
		if (switchTrimYaw1.monostable == true)
		{
			soundNull = true;
		}
		else if (switchTrimYaw2.monostable == true)
		{
			soundNull = true;
		}
		else if (switchTrimYaw1.bistable == true)
		{
			delayTrimYaw.state();
			
			if (delayTrimYaw.update == true)
			{
				soundNull = true;
				delayTrimYaw.duration (50);
			}
		}
		else if (switchTrimYaw2.bistable == true)
		{
			delayTrimYaw.state();
			
			if (delayTrimYaw.update == true)
			{
				soundNull = true;
				delayTrimYaw.duration (50);
			}
		}
		else
		{
			delayTrimYaw.duration (1000);
			delayTrimYaw.reset();
		}
		
		filterVoltageBatteryControl.set (Math::curve (0, voltageBatteryControl.value, 1023, 0, 30, 0));
		hysteresisVoltageBatteryControl.set (filterVoltageBatteryControl.value * 10.0);
		
		if (lowVoltageBatteryControl == false && (float)(hysteresisVoltageBatteryControl.value) / 10.0 < SETUP_LOW_VOLTAGE_BATTERY_CONTROL)
		{
			lowVoltageBatteryControl = true;
			soundLowVoltageBatteryControl = true;
		}
		
		if (onAir == true)
		{
			display.word ("on air  ");
		}
		else
		{
			display.word ("off air ");
		}
		
		if (soundOnline == true)
		{
			SoundWrite::add (256, 100);
			SoundWrite::add (0, 50);
			SoundWrite::add (512, 100);
			SoundWrite::add (0, 50);
			SoundWrite::add (1024, 100);
			SoundWrite::play (0, 0);
			
			timeSoundPrevious = timeSound.ms + 400ull + (unsigned long long)(TIME_SPACE_SOUND);
		}
		else if (soundOffline == true)
		{
			SoundWrite::add (256, 100);
			SoundWrite::add (0, 50);
			SoundWrite::add (256, 100);
			SoundWrite::play (0, 0);
			
			timeSoundPrevious = timeSound.ms + 250ull + (unsigned long long)(TIME_SPACE_SOUND);
		}
		else if (soundSelect == true && inhibitSound == false)
		{
			SoundWrite::play (1024, 20);
			timeSoundPrevious = timeSound.ms + 20ull + (unsigned long long)(TIME_SPACE_SOUND);
		}
		else if (soundNull == true && inhibitSound == false)
		{
			SoundWrite::play (128, 200);
			timeSoundPrevious = timeSound.ms + 200ull + (unsigned long long)(TIME_SPACE_SOUND);
		}
		else if (soundSwitch1 == true && inhibitSound == false)
		{
			SoundWrite::play (1024, 20);
			timeSoundPrevious = timeSound.ms + 20ull + (unsigned long long)(TIME_SPACE_SOUND);
		}
		else if (soundSwitch2 == true && inhibitSound == false)
		{
			SoundWrite::add (1024, 20);
			SoundWrite::add (0, 40);
			SoundWrite::add (1024, 20);
			SoundWrite::play (0, 0);
			
			timeSoundPrevious = timeSound.ms + 80ull + (unsigned long long)(TIME_SPACE_SOUND);
		}
		else if (soundSwitch3 == true && inhibitSound == false)
		{
			SoundWrite::add (1024, 20);
			SoundWrite::add (0, 40);
			SoundWrite::add (1024, 20);
			SoundWrite::add (0, 40);
			SoundWrite::add (1024, 20);
			SoundWrite::play (0, 0);
			
			timeSoundPrevious = timeSound.ms + 140ull + (unsigned long long)(TIME_SPACE_SOUND);
		}
		
		if (soundLowVoltageBatteryControl == true && timeSound.ms > timeSoundPrevious)
		{
			delaySoundLowVoltageBatteryControl.state();
			
			if (delaySoundLowVoltageBatteryControl.update == true)
			{
				SoundWrite::play (2048, 100);
			}
		}
		
		soundSelect = false;
		soundOnline = false;
		soundOffline = false;
		soundNull = false;
		soundSwitch1 = false;
		soundSwitch2 = false;
		soundSwitch3 = false;
		
		inhibitSound = false;
	}
	
	if (onAir == true)
	{
		inhibitSound = true;
		
		SpiNrf24l01p::start (5, 32, SETUP_RFID, true);
		
		while (downloadedSetting == true && (channelVoltageBatteryModelTelemetryWatchDogUpdated.received == false || channelSettingBatteryTimer.received == false || channelSettingTrim.received == false || channelSettingStick.received == false || channelSettingOptionWord1.received == false || channelSettingOption1.received == false || channelSettingOptionWord2.received == false || channelSettingOption2.received == false || channelSettingOptionWord3.received == false || channelSettingOption3.received == false || channelSettingOptionWord4.received == false || channelSettingOption4.received == false || channelSettingOptionWord5.received == false || channelSettingOption5.received == false || channelSettingOptionWord6.received == false || channelSettingOption6.received == false || channelSettingOptionWord7.received == false || channelSettingOption7.received == false || channelSettingOptionWord8.received == false || channelSettingOption8.received == false || channelSettingOptionWord9.received == false || channelSettingOption9.received == false || channelSettingOptionWord10.received == false || channelSettingOption10.received == false || channelSettingOptionWord11.received == false || channelSettingOption11.received == false || channelSettingOptionWord12.received == false || channelSettingOption12.received == false || channelSettingOptionWord13.received == false || channelSettingOption13.received == false || channelSettingOptionWord14.received == false || channelSettingOption14.received == false || channelSettingOptionWord15.received == false || channelSettingOption15.received == false || channelSettingOptionWord16.received == false || channelSettingOption16.received == false))
		{
			timeSound.state();
			
			delayBinding.state();
			
			switchPowerState.read();
			buttonSelect.read();
			switchCut.read();
			switchAuxiliaryA1.read();
			switchAuxiliaryA2.read();
			switchAuxiliaryB1.read();
			switchAuxiliaryB2.read();
			switchAuxiliaryC1.read();
			switchAuxiliaryC2.read();
			switchTrimThrottle1.read();
			switchTrimThrottle2.read();
			switchTrimPitch1.read();
			switchTrimPitch2.read();
			switchTrimRoll1.read();
			switchTrimRoll2.read();
			switchTrimYaw1.read();
			switchTrimYaw2.read();
			voltageBatteryControl.read();
			
			channelVoltageBatteryModelTelemetryWatchDogUpdated.receive();
			
			channelSettingBatteryTimer.receive();
			channelSettingTrim.receive();
			channelSettingStick.receive();
			channelSettingOptionWord1.receive();
			channelSettingOption1.receive();
			channelSettingOptionWord2.receive();
			channelSettingOption2.receive();
			channelSettingOptionWord3.receive();
			channelSettingOption3.receive();
			channelSettingOptionWord4.receive();
			channelSettingOption4.receive();
			channelSettingOptionWord5.receive();
			channelSettingOption5.receive();
			channelSettingOptionWord6.receive();
			channelSettingOption6.receive();
			channelSettingOptionWord7.receive();
			channelSettingOption7.receive();
			channelSettingOptionWord8.receive();
			channelSettingOption8.receive();
			channelSettingOptionWord9.receive();
			channelSettingOption9.receive();
			channelSettingOptionWord10.receive();
			channelSettingOption10.receive();
			channelSettingOptionWord11.receive();
			channelSettingOption11.receive();
			channelSettingOptionWord12.receive();
			channelSettingOption12.receive();
			channelSettingOptionWord13.receive();
			channelSettingOption13.receive();
			channelSettingOptionWord14.receive();
			channelSettingOption14.receive();
			channelSettingOptionWord15.receive();
			channelSettingOption15.receive();
			channelSettingOptionWord16.receive();
			channelSettingOption16.receive();
			
			if (switchPowerState.bistable == false)
			{
				SpiNrf24l01p::stop();
				
				SoundWrite::add (1024, 100);
				SoundWrite::add (512, 100);
				SoundWrite::add (0, 50);
				SoundWrite::add (512, 100);
				SoundWrite::add (256, 100);
				SoundWrite::add (0, 50);
				SoundWrite::add (256, 100);
				SoundWrite::add (128, 100);
				SoundWrite::play (0, 0);
				
				for (iterationAnimation = 0; iterationAnimation < 4; iterationAnimation++)
				{
					display.clearDevice();
					display.draw (0b00000110, 1 + iterationAnimation);
					display.draw (0b00110000, 8 - iterationAnimation);
					Timer::pause (100);
					display.draw (0b00110000, 1 + iterationAnimation);
					display.draw (0b00000110, 8 - iterationAnimation);
					Timer::pause (100);
				}
				
				display.clearDevice();
				
				switchPowerHold.off();
				
				Timer::pause (1000);
				
				display.brightness (1);
				display.word ("turn off");
				
				for (iterationAnimation = 2; iterationAnimation < 16; iterationAnimation++)
				{
					Timer::pause (30);
					display.brightness (iterationAnimation);
				}
				
				while (true)
				{
				}
			}
			
			if (delayBinding.update == true)
			{
				binding = true;
			}
			
			if (buttonSelect.monostable == true)
			{
				if (binding == true)
				{
					downloadedSetting = false;
				}
				
				soundNull = true;
			}
			
			cut = switchCut.bistable;
			
			if (cut != cutPrevious)
			{
				cutPrevious = cut;
				
				if (cut == false)
				{
					soundSwitch1 = true;
				}
				else
				{
					soundSwitch2 = true;
				}
			}
			
			if (switchAuxiliaryA1.bistable == true)
			{
				auxiliaryA = 0;
			}
			else if (switchAuxiliaryA2.bistable == true)
			{
				auxiliaryA = 2;
			}
			else
			{
				auxiliaryA = 1;
			}
			
			if (auxiliaryA != auxiliaryAPrevious)
			{
				auxiliaryAPrevious = auxiliaryA;
				
				if (auxiliaryA == 0)
				{
					soundSwitch1 = true;
				}
				else if (auxiliaryA == 1)
				{
					soundSwitch2 = true;
				}
				else
				{
					soundSwitch3 = true;
				}
			}
			
			if (switchAuxiliaryB1.bistable == true)
			{
				auxiliaryB = 0;
			}
			else if (switchAuxiliaryB2.bistable == true)
			{
				auxiliaryB = 2;
			}
			else
			{
				auxiliaryB = 1;
			}
			
			if (auxiliaryB != auxiliaryBPrevious)
			{
				auxiliaryBPrevious = auxiliaryB;
				
				if (auxiliaryB == 0)
				{
					soundSwitch1 = true;
				}
				else if (auxiliaryB == 1)
				{
					soundSwitch2 = true;
				}
				else
				{
					soundSwitch3 = true;
				}
			}
			
			if (switchAuxiliaryC1.bistable == true)
			{
				auxiliaryC = 0;
			}
			else if (switchAuxiliaryC2.bistable == true)
			{
				auxiliaryC = 2;
			}
			else
			{
				auxiliaryC = 1;
			}
			
			if (auxiliaryC != auxiliaryCPrevious)
			{
				auxiliaryCPrevious = auxiliaryC;
				
				if (auxiliaryC == 0)
				{
					soundSwitch1 = true;
				}
				else if (auxiliaryC == 1)
				{
					soundSwitch2 = true;
				}
				else
				{
					soundSwitch3 = true;
				}
			}
			
			if (switchTrimThrottle1.monostable == true)
			{
				soundNull = true;
			}
			else if (switchTrimThrottle2.monostable == true)
			{
				soundNull = true;
			}
			else if (switchTrimThrottle1.bistable == true)
			{
				delayTrimThrottle.state();
				
				if (delayTrimThrottle.update == true)
				{
					soundNull = true;
					delayTrimThrottle.duration (50);
				}
			}
			else if (switchTrimThrottle2.bistable == true)
			{
				delayTrimThrottle.state();
				
				if (delayTrimThrottle.update == true)
				{
					soundNull = true;
					delayTrimThrottle.duration (50);
				}
			}
			else
			{
				delayTrimThrottle.duration (1000);
				delayTrimThrottle.reset();
			}
			
			if (switchTrimPitch1.monostable == true)
			{
				soundNull = true;
			}
			else if (switchTrimPitch2.monostable == true)
			{
				soundNull = true;
			}
			else if (switchTrimPitch1.bistable == true)
			{
				delayTrimPitch.state();
				
				if (delayTrimPitch.update == true)
				{
					soundNull = true;
					delayTrimPitch.duration (50);
				}
			}
			else if (switchTrimPitch2.bistable == true)
			{
				delayTrimPitch.state();
				
				if (delayTrimPitch.update == true)
				{
					soundNull = true;
					delayTrimPitch.duration (50);
				}
			}
			else
			{
				delayTrimPitch.duration (1000);
				delayTrimPitch.reset();
			}
			
			if (switchTrimRoll1.monostable == true)
			{
				soundNull = true;
			}
			else if (switchTrimRoll2.monostable == true)
			{
				soundNull = true;
			}
			else if (switchTrimRoll1.bistable == true)
			{
				delayTrimRoll.state();
				
				if (delayTrimRoll.update == true)
				{
					soundNull = true;
					delayTrimRoll.duration (50);
				}
			}
			else if (switchTrimRoll2.bistable == true)
			{
				delayTrimRoll.state();
				
				if (delayTrimRoll.update == true)
				{
					soundNull = true;
					delayTrimRoll.duration (50);
				}
			}
			else
			{
				delayTrimRoll.duration (1000);
				delayTrimRoll.reset();
			}
			
			if (switchTrimYaw1.monostable == true)
			{
				soundNull = true;
			}
			else if (switchTrimYaw2.monostable == true)
			{
				soundNull = true;
			}
			else if (switchTrimYaw1.bistable == true)
			{
				delayTrimYaw.state();
				
				if (delayTrimYaw.update == true)
				{
					soundNull = true;
					delayTrimYaw.duration (50);
				}
			}
			else if (switchTrimYaw2.bistable == true)
			{
				delayTrimYaw.state();
				
				if (delayTrimYaw.update == true)
				{
					soundNull = true;
					delayTrimYaw.duration (50);
				}
			}
			else
			{
				delayTrimYaw.duration (1000);
				delayTrimYaw.reset();
			}
			
			filterVoltageBatteryControl.set (Math::curve (0, voltageBatteryControl.value, 1023, 0, 30, 0));
			hysteresisVoltageBatteryControl.set (filterVoltageBatteryControl.value * 10.0);
			
			if (lowVoltageBatteryControl == false && (float)(hysteresisVoltageBatteryControl.value) / 10.0 < SETUP_LOW_VOLTAGE_BATTERY_CONTROL)
			{
				lowVoltageBatteryControl = true;
				soundLowVoltageBatteryControl = true;
			}
			
			if (binding == true)
			{
				delayDotBinding.state();
				
				if (delayDotBinding.update == true)
				{
					for (iterationAnimation = 0; iterationAnimation < 8; iterationAnimation++)
					{
						if (iterationAnimation == dotBinding)
						{
							display.draw (Tool::characterToByte (&WORD_BINDING [iterationAnimation]) | 0b10000000, iterationAnimation + 1);
						}
						else
						{
							display.draw (Tool::characterToByte (&WORD_BINDING [iterationAnimation]), iterationAnimation + 1);
						}
					}
					
					if (dotBinding < 7)
					{
						dotBinding++;
					}
					else
					{
						dotBinding = 0;
					}
				}
			}
			
			if (soundNull == true && inhibitSound == false)
			{
				SoundWrite::play (128, 200);
				timeSoundPrevious = timeSound.ms + 200ull + (unsigned long long)(TIME_SPACE_SOUND);
			}
			else if (soundSwitch1 == true && inhibitSound == false)
			{
				SoundWrite::play (1024, 20);
				timeSoundPrevious = timeSound.ms + 20ull + (unsigned long long)(TIME_SPACE_SOUND);
			}
			else if (soundSwitch2 == true && inhibitSound == false)
			{
				SoundWrite::add (1024, 20);
				SoundWrite::add (0, 40);
				SoundWrite::add (1024, 20);
				SoundWrite::play (0, 0);
				
				timeSoundPrevious = timeSound.ms + 80ull + (unsigned long long)(TIME_SPACE_SOUND);
			}
			else if (soundSwitch3 == true && inhibitSound == false)
			{
				SoundWrite::add (1024, 20);
				SoundWrite::add (0, 40);
				SoundWrite::add (1024, 20);
				SoundWrite::add (0, 40);
				SoundWrite::add (1024, 20);
				SoundWrite::play (0, 0);
				
				timeSoundPrevious = timeSound.ms + 140ull + (unsigned long long)(TIME_SPACE_SOUND);
			}
			
			if (soundLowVoltageBatteryControl == true && timeSound.ms > timeSoundPrevious)
			{
				delaySoundLowVoltageBatteryControl.state();
				
				if (delaySoundLowVoltageBatteryControl.update == true)
				{
					SoundWrite::play (2048, 100);
				}
			}
			
			soundNull = false;
			soundSwitch1 = false;
			soundSwitch2 = false;
			soundSwitch3 = false;
			
			inhibitSound = false;
		}
	}
	else
	{
		downloadedSetting = false;
	}
	
	if (downloadedSetting == true)
	{
		watchDogPrevious = true;
		watchDog = true;
		
		if (binding == true)
		{
			SoundWrite::add (1024, 20);
			SoundWrite::add (0, 40);
			SoundWrite::add (1024, 20);
			SoundWrite::play (0, 0);
			
			timeSoundPrevious = timeSound.ms + 80ull + (unsigned long long)(TIME_SPACE_SOUND);
		}
		
		settingVoltageBatteryModelLow = channelSettingBatteryTimer.data & 0b00000000000000000000001111111111;
		settingTimerEnd = (channelSettingBatteryTimer.data & 0b00000000001111111111110000000000) >> 10;
		settingTimerTrigger = (channelSettingBatteryTimer.data & 0b11111111110000000000000000000000) >> 22;
		settingTrimThrottle = channelSettingTrim.data & 0b00000000000000000000000011111111;
		settingTrimPitch = (channelSettingTrim.data & 0b00000000000000001111111100000000) >> 8;
		settingTrimRoll = (channelSettingTrim.data & 0b00000000111111110000000000000000) >> 16;
		settingTrimYaw = (channelSettingTrim.data & 0b11111111000000000000000000000000) >> 24;
		settingInvertThrottle = channelSettingStick.data & 0b00000000000000000000000000000001;
		settingInvertPitch = (channelSettingStick.data & 0b00000000000000000000000000000010) >> 1;
		settingInvertRoll = (channelSettingStick.data & 0b00000000000000000000000000000100) >> 2;
		settingInvertYaw = (channelSettingStick.data & 0b00000000000000000000000000001000) >> 3;
		settingCurveThrottle = (channelSettingStick.data & 0b00000000000000000000011111110000) >> 4;
		settingCurvePitch = (channelSettingStick.data & 0b00000000000000111111100000000000) >> 11;
		settingCurveRoll = (channelSettingStick.data & 0b00000001111111000000000000000000) >> 18;
		settingCurveYaw = (channelSettingStick.data & 0b11111110000000000000000000000000) >> 25;
		settingOptionWord [0][0] = channelSettingOptionWord1.data & 0b00000000000000000000000011111111;
		settingOptionWord [0][1] = (channelSettingOptionWord1.data & 0b00000000000000001111111100000000) >> 8;
		settingOptionWord [0][2] = (channelSettingOptionWord1.data & 0b00000000111111110000000000000000) >> 16;
		settingOptionWord [0][3] = (channelSettingOptionWord1.data & 0b11111111000000000000000000000000) >> 24;
		settingOption [0] = channelSettingOption1.data & 0b00000000000000000000001111111111;
		settingOptionMin [0] = (channelSettingOption1.data & 0b00000000000011111111110000000000) >> 10;
		settingOptionMax [0] = (channelSettingOption1.data & 0b00111111111100000000000000000000) >> 20;
		settingOptionCenter [0] = (channelSettingOption1.data & 0b01000000000000000000000000000000) >> 30;
		settingOptionDecimal [0] = (channelSettingOption1.data & 0b10000000000000000000000000000000) >> 31;
		settingOptionWord [1][0] = channelSettingOptionWord2.data & 0b00000000000000000000000011111111;
		settingOptionWord [1][1] = (channelSettingOptionWord2.data & 0b00000000000000001111111100000000) >> 8;
		settingOptionWord [1][2] = (channelSettingOptionWord2.data & 0b00000000111111110000000000000000) >> 16;
		settingOptionWord [1][3] = (channelSettingOptionWord2.data & 0b11111111000000000000000000000000) >> 24;
		settingOption [1] = channelSettingOption2.data & 0b00000000000000000000001111111111;
		settingOptionMin [1] = (channelSettingOption2.data & 0b00000000000011111111110000000000) >> 10;
		settingOptionMax [1] = (channelSettingOption2.data & 0b00111111111100000000000000000000) >> 20;
		settingOptionCenter [1] = (channelSettingOption2.data & 0b01000000000000000000000000000000) >> 30;
		settingOptionDecimal [1] = (channelSettingOption2.data & 0b10000000000000000000000000000000) >> 31;
		settingOptionWord [2][0] = channelSettingOptionWord3.data & 0b00000000000000000000000011111111;
		settingOptionWord [2][1] = (channelSettingOptionWord3.data & 0b00000000000000001111111100000000) >> 8;
		settingOptionWord [2][2] = (channelSettingOptionWord3.data & 0b00000000111111110000000000000000) >> 16;
		settingOptionWord [2][3] = (channelSettingOptionWord3.data & 0b11111111000000000000000000000000) >> 24;
		settingOption [2] = channelSettingOption3.data & 0b00000000000000000000001111111111;
		settingOptionMin [2] = (channelSettingOption3.data & 0b00000000000011111111110000000000) >> 10;
		settingOptionMax [2] = (channelSettingOption3.data & 0b00111111111100000000000000000000) >> 20;
		settingOptionCenter [2] = (channelSettingOption3.data & 0b01000000000000000000000000000000) >> 30;
		settingOptionDecimal [2] = (channelSettingOption3.data & 0b10000000000000000000000000000000) >> 31;
		settingOptionWord [3][0] = channelSettingOptionWord4.data & 0b00000000000000000000000011111111;
		settingOptionWord [3][1] = (channelSettingOptionWord4.data & 0b00000000000000001111111100000000) >> 8;
		settingOptionWord [3][2] = (channelSettingOptionWord4.data & 0b00000000111111110000000000000000) >> 16;
		settingOptionWord [3][3] = (channelSettingOptionWord4.data & 0b11111111000000000000000000000000) >> 24;
		settingOption [3] = channelSettingOption4.data & 0b00000000000000000000001111111111;
		settingOptionMin [3] = (channelSettingOption4.data & 0b00000000000011111111110000000000) >> 10;
		settingOptionMax [3] = (channelSettingOption4.data & 0b00111111111100000000000000000000) >> 20;
		settingOptionCenter [3] = (channelSettingOption4.data & 0b01000000000000000000000000000000) >> 30;
		settingOptionDecimal [3] = (channelSettingOption4.data & 0b10000000000000000000000000000000) >> 31;
		settingOptionWord [4][0] = channelSettingOptionWord5.data & 0b00000000000000000000000011111111;
		settingOptionWord [4][1] = (channelSettingOptionWord5.data & 0b00000000000000001111111100000000) >> 8;
		settingOptionWord [4][2] = (channelSettingOptionWord5.data & 0b00000000111111110000000000000000) >> 16;
		settingOptionWord [4][3] = (channelSettingOptionWord5.data & 0b11111111000000000000000000000000) >> 24;
		settingOption [4] = channelSettingOption5.data & 0b00000000000000000000001111111111;
		settingOptionMin [4] = (channelSettingOption5.data & 0b00000000000011111111110000000000) >> 10;
		settingOptionMax [4] = (channelSettingOption5.data & 0b00111111111100000000000000000000) >> 20;
		settingOptionCenter [4] = (channelSettingOption5.data & 0b01000000000000000000000000000000) >> 30;
		settingOptionDecimal [4] = (channelSettingOption5.data & 0b10000000000000000000000000000000) >> 31;
		settingOptionWord [5][0] = channelSettingOptionWord6.data & 0b00000000000000000000000011111111;
		settingOptionWord [5][1] = (channelSettingOptionWord6.data & 0b00000000000000001111111100000000) >> 8;
		settingOptionWord [5][2] = (channelSettingOptionWord6.data & 0b00000000111111110000000000000000) >> 16;
		settingOptionWord [5][3] = (channelSettingOptionWord6.data & 0b11111111000000000000000000000000) >> 24;
		settingOption [5] = channelSettingOption6.data & 0b00000000000000000000001111111111;
		settingOptionMin [5] = (channelSettingOption6.data & 0b00000000000011111111110000000000) >> 10;
		settingOptionMax [5] = (channelSettingOption6.data & 0b00111111111100000000000000000000) >> 20;
		settingOptionCenter [5] = (channelSettingOption6.data & 0b01000000000000000000000000000000) >> 30;
		settingOptionDecimal [5] = (channelSettingOption6.data & 0b10000000000000000000000000000000) >> 31;
		settingOptionWord [6][0] = channelSettingOptionWord7.data & 0b00000000000000000000000011111111;
		settingOptionWord [6][1] = (channelSettingOptionWord7.data & 0b00000000000000001111111100000000) >> 8;
		settingOptionWord [6][2] = (channelSettingOptionWord7.data & 0b00000000111111110000000000000000) >> 16;
		settingOptionWord [6][3] = (channelSettingOptionWord7.data & 0b11111111000000000000000000000000) >> 24;
		settingOption [6] = channelSettingOption7.data & 0b00000000000000000000001111111111;
		settingOptionMin [6] = (channelSettingOption7.data & 0b00000000000011111111110000000000) >> 10;
		settingOptionMax [6] = (channelSettingOption7.data & 0b00111111111100000000000000000000) >> 20;
		settingOptionCenter [6] = (channelSettingOption7.data & 0b01000000000000000000000000000000) >> 30;
		settingOptionDecimal [6] = (channelSettingOption7.data & 0b10000000000000000000000000000000) >> 31;
		settingOptionWord [7][0] = channelSettingOptionWord8.data & 0b00000000000000000000000011111111;
		settingOptionWord [7][1] = (channelSettingOptionWord8.data & 0b00000000000000001111111100000000) >> 8;
		settingOptionWord [7][2] = (channelSettingOptionWord8.data & 0b00000000111111110000000000000000) >> 16;
		settingOptionWord [7][3] = (channelSettingOptionWord8.data & 0b11111111000000000000000000000000) >> 24;
		settingOption [7] = channelSettingOption8.data & 0b00000000000000000000001111111111;
		settingOptionMin [7] = (channelSettingOption8.data & 0b00000000000011111111110000000000) >> 10;
		settingOptionMax [7] = (channelSettingOption8.data & 0b00111111111100000000000000000000) >> 20;
		settingOptionCenter [7] = (channelSettingOption8.data & 0b01000000000000000000000000000000) >> 30;
		settingOptionDecimal [7] = (channelSettingOption8.data & 0b10000000000000000000000000000000) >> 31;
		settingOptionWord [8][0] = channelSettingOptionWord9.data & 0b00000000000000000000000011111111;
		settingOptionWord [8][1] = (channelSettingOptionWord9.data & 0b00000000000000001111111100000000) >> 8;
		settingOptionWord [8][2] = (channelSettingOptionWord9.data & 0b00000000111111110000000000000000) >> 16;
		settingOptionWord [8][3] = (channelSettingOptionWord9.data & 0b11111111000000000000000000000000) >> 24;
		settingOption [8] = channelSettingOption9.data & 0b00000000000000000000001111111111;
		settingOptionMin [8] = (channelSettingOption9.data & 0b00000000000011111111110000000000) >> 10;
		settingOptionMax [8] = (channelSettingOption9.data & 0b00111111111100000000000000000000) >> 20;
		settingOptionCenter [8] = (channelSettingOption9.data & 0b01000000000000000000000000000000) >> 30;
		settingOptionDecimal [8] = (channelSettingOption9.data & 0b10000000000000000000000000000000) >> 31;
		settingOptionWord [9][0] = channelSettingOptionWord10.data & 0b00000000000000000000000011111111;
		settingOptionWord [9][1] = (channelSettingOptionWord10.data & 0b00000000000000001111111100000000) >> 8;
		settingOptionWord [9][2] = (channelSettingOptionWord10.data & 0b00000000111111110000000000000000) >> 16;
		settingOptionWord [9][3] = (channelSettingOptionWord10.data & 0b11111111000000000000000000000000) >> 24;
		settingOption [9] = channelSettingOption10.data & 0b00000000000000000000001111111111;
		settingOptionMin [9] = (channelSettingOption10.data & 0b00000000000011111111110000000000) >> 10;
		settingOptionMax [9] = (channelSettingOption10.data & 0b00111111111100000000000000000000) >> 20;
		settingOptionCenter [9] = (channelSettingOption10.data & 0b01000000000000000000000000000000) >> 30;
		settingOptionDecimal [9] = (channelSettingOption10.data & 0b10000000000000000000000000000000) >> 31;
		settingOptionWord [10][0] = channelSettingOptionWord11.data & 0b00000000000000000000000011111111;
		settingOptionWord [10][1] = (channelSettingOptionWord11.data & 0b00000000000000001111111100000000) >> 8;
		settingOptionWord [10][2] = (channelSettingOptionWord11.data & 0b00000000111111110000000000000000) >> 16;
		settingOptionWord [10][3] = (channelSettingOptionWord11.data & 0b11111111000000000000000000000000) >> 24;
		settingOption [10] = channelSettingOption11.data & 0b00000000000000000000001111111111;
		settingOptionMin [10] = (channelSettingOption11.data & 0b00000000000011111111110000000000) >> 10;
		settingOptionMax [10] = (channelSettingOption11.data & 0b00111111111100000000000000000000) >> 20;
		settingOptionCenter [10] = (channelSettingOption11.data & 0b01000000000000000000000000000000) >> 30;
		settingOptionDecimal [10] = (channelSettingOption11.data & 0b10000000000000000000000000000000) >> 31;
		settingOptionWord [11][0] = channelSettingOptionWord12.data & 0b00000000000000000000000011111111;
		settingOptionWord [11][1] = (channelSettingOptionWord12.data & 0b00000000000000001111111100000000) >> 8;
		settingOptionWord [11][2] = (channelSettingOptionWord12.data & 0b00000000111111110000000000000000) >> 16;
		settingOptionWord [11][3] = (channelSettingOptionWord12.data & 0b11111111000000000000000000000000) >> 24;
		settingOption [11] = channelSettingOption12.data & 0b00000000000000000000001111111111;
		settingOptionMin [11] = (channelSettingOption12.data & 0b00000000000011111111110000000000) >> 10;
		settingOptionMax [11] = (channelSettingOption12.data & 0b00111111111100000000000000000000) >> 20;
		settingOptionCenter [11] = (channelSettingOption12.data & 0b01000000000000000000000000000000) >> 30;
		settingOptionDecimal [11] = (channelSettingOption12.data & 0b10000000000000000000000000000000) >> 31;
		settingOptionWord [12][0] = channelSettingOptionWord13.data & 0b00000000000000000000000011111111;
		settingOptionWord [12][1] = (channelSettingOptionWord13.data & 0b00000000000000001111111100000000) >> 8;
		settingOptionWord [12][2] = (channelSettingOptionWord13.data & 0b00000000111111110000000000000000) >> 16;
		settingOptionWord [12][3] = (channelSettingOptionWord13.data & 0b11111111000000000000000000000000) >> 24;
		settingOption [12] = channelSettingOption13.data & 0b00000000000000000000001111111111;
		settingOptionMin [12] = (channelSettingOption13.data & 0b00000000000011111111110000000000) >> 10;
		settingOptionMax [12] = (channelSettingOption13.data & 0b00111111111100000000000000000000) >> 20;
		settingOptionCenter [12] = (channelSettingOption13.data & 0b01000000000000000000000000000000) >> 30;
		settingOptionDecimal [12] = (channelSettingOption13.data & 0b10000000000000000000000000000000) >> 31;
		settingOptionWord [13][0] = channelSettingOptionWord14.data & 0b00000000000000000000000011111111;
		settingOptionWord [13][1] = (channelSettingOptionWord14.data & 0b00000000000000001111111100000000) >> 8;
		settingOptionWord [13][2] = (channelSettingOptionWord14.data & 0b00000000111111110000000000000000) >> 16;
		settingOptionWord [13][3] = (channelSettingOptionWord14.data & 0b11111111000000000000000000000000) >> 24;
		settingOption [13] = channelSettingOption14.data & 0b00000000000000000000001111111111;
		settingOptionMin [13] = (channelSettingOption14.data & 0b00000000000011111111110000000000) >> 10;
		settingOptionMax [13] = (channelSettingOption14.data & 0b00111111111100000000000000000000) >> 20;
		settingOptionCenter [13] = (channelSettingOption14.data & 0b01000000000000000000000000000000) >> 30;
		settingOptionDecimal [13] = (channelSettingOption14.data & 0b10000000000000000000000000000000) >> 31;
		settingOptionWord [14][0] = channelSettingOptionWord15.data & 0b00000000000000000000000011111111;
		settingOptionWord [14][1] = (channelSettingOptionWord15.data & 0b00000000000000001111111100000000) >> 8;
		settingOptionWord [14][2] = (channelSettingOptionWord15.data & 0b00000000111111110000000000000000) >> 16;
		settingOptionWord [14][3] = (channelSettingOptionWord15.data & 0b11111111000000000000000000000000) >> 24;
		settingOption [14] = channelSettingOption15.data & 0b00000000000000000000001111111111;
		settingOptionMin [14] = (channelSettingOption15.data & 0b00000000000011111111110000000000) >> 10;
		settingOptionMax [14] = (channelSettingOption15.data & 0b00111111111100000000000000000000) >> 20;
		settingOptionCenter [14] = (channelSettingOption15.data & 0b01000000000000000000000000000000) >> 30;
		settingOptionDecimal [14] = (channelSettingOption15.data & 0b10000000000000000000000000000000) >> 31;
		settingOptionWord [15][0] = channelSettingOptionWord16.data & 0b00000000000000000000000011111111;
		settingOptionWord [15][1] = (channelSettingOptionWord16.data & 0b00000000000000001111111100000000) >> 8;
		settingOptionWord [15][2] = (channelSettingOptionWord16.data & 0b00000000111111110000000000000000) >> 16;
		settingOptionWord [15][3] = (channelSettingOptionWord16.data & 0b11111111000000000000000000000000) >> 24;
		settingOption [15] = channelSettingOption16.data & 0b00000000000000000000001111111111;
		settingOptionMin [15] = (channelSettingOption16.data & 0b00000000000011111111110000000000) >> 10;
		settingOptionMax [15] = (channelSettingOption16.data & 0b00111111111100000000000000000000) >> 20;
		settingOptionCenter [15] = (channelSettingOption16.data & 0b01000000000000000000000000000000) >> 30;
		settingOptionDecimal [15] = (channelSettingOption16.data & 0b10000000000000000000000000000000) >> 31;
		
		for (iterationSettingOption = 0; iterationSettingOption < 16; iterationSettingOption++)
		{
			if ((settingOptionWord [iterationSettingOption][0] != 0 || settingOptionWord [iterationSettingOption][1] != 0 || settingOptionWord [iterationSettingOption][2] != 0 || settingOptionWord [iterationSettingOption][3] != 0) && (settingOptionMin [iterationSettingOption] < settingOptionMax [iterationSettingOption]))
			{
				mapSettingOption [countSettingOption] = iterationSettingOption;
				countSettingOption++;
			}
		}
		
		settingTrimThrottleTune = settingTrimThrottle;
		settingTrimPitchTune = settingTrimPitch;
		settingTrimRollTune = settingTrimRoll;
		settingTrimYawTune = settingTrimYaw;
	}
	
	inhibitSound = true;
	
	timeDisplay.start (0);
	
	while (brightness > 1)
	{
		timeDisplay.state();
		timeSound.state();
		
		switchPowerState.read();
		buttonSelect.read();
		switchCut.read();
		switchAuxiliaryA1.read();
		switchAuxiliaryA2.read();
		switchAuxiliaryB1.read();
		switchAuxiliaryB2.read();
		switchAuxiliaryC1.read();
		switchAuxiliaryC2.read();
		switchTrimThrottle1.read();
		switchTrimThrottle2.read();
		switchTrimPitch1.read();
		switchTrimPitch2.read();
		switchTrimRoll1.read();
		switchTrimRoll2.read();
		switchTrimYaw1.read();
		switchTrimYaw2.read();
		voltageBatteryControl.read();
		
		if (switchPowerState.bistable == false)
		{
			if (resetShutdown == false)
			{
				resetShutdown = true;
				soundNull = true;
			}
		}
		else
		{
			resetShutdown = false;
		}
		
		if (buttonSelect.monostable == true)
		{
			soundNull = true;
		}
		
		cut = switchCut.bistable;
		
		if (cut != cutPrevious)
		{
			cutPrevious = cut;
			
			if (cut == false)
			{
				soundSwitch1 = true;
			}
			else
			{
				soundSwitch2 = true;
			}
		}
		
		if (switchAuxiliaryA1.bistable == true)
		{
			auxiliaryA = 0;
		}
		else if (switchAuxiliaryA2.bistable == true)
		{
			auxiliaryA = 2;
		}
		else
		{
			auxiliaryA = 1;
		}
		
		if (auxiliaryA != auxiliaryAPrevious)
		{
			auxiliaryAPrevious = auxiliaryA;
			
			if (auxiliaryA == 0)
			{
				soundSwitch1 = true;
			}
			else if (auxiliaryA == 1)
			{
				soundSwitch2 = true;
			}
			else
			{
				soundSwitch3 = true;
			}
		}
		
		if (switchAuxiliaryB1.bistable == true)
		{
			auxiliaryB = 0;
		}
		else if (switchAuxiliaryB2.bistable == true)
		{
			auxiliaryB = 2;
		}
		else
		{
			auxiliaryB = 1;
		}
		
		if (auxiliaryB != auxiliaryBPrevious)
		{
			auxiliaryBPrevious = auxiliaryB;
			
			if (auxiliaryB == 0)
			{
				soundSwitch1 = true;
			}
			else if (auxiliaryB == 1)
			{
				soundSwitch2 = true;
			}
			else
			{
				soundSwitch3 = true;
			}
		}
		
		if (switchAuxiliaryC1.bistable == true)
		{
			auxiliaryC = 0;
		}
		else if (switchAuxiliaryC2.bistable == true)
		{
			auxiliaryC = 2;
		}
		else
		{
			auxiliaryC = 1;
		}
		
		if (auxiliaryC != auxiliaryCPrevious)
		{
			auxiliaryCPrevious = auxiliaryC;
			
			if (auxiliaryC == 0)
			{
				soundSwitch1 = true;
			}
			else if (auxiliaryC == 1)
			{
				soundSwitch2 = true;
			}
			else
			{
				soundSwitch3 = true;
			}
		}
		
		if (switchTrimThrottle1.monostable == true)
		{
			soundNull = true;
		}
		else if (switchTrimThrottle2.monostable == true)
		{
			soundNull = true;
		}
		else if (switchTrimThrottle1.bistable == true)
		{
			delayTrimThrottle.state();
			
			if (delayTrimThrottle.update == true)
			{
				soundNull = true;
				delayTrimThrottle.duration (50);
			}
		}
		else if (switchTrimThrottle2.bistable == true)
		{
			delayTrimThrottle.state();
			
			if (delayTrimThrottle.update == true)
			{
				soundNull = true;
				delayTrimThrottle.duration (50);
			}
		}
		else
		{
			delayTrimThrottle.duration (1000);
			delayTrimThrottle.reset();
		}
		
		if (switchTrimPitch1.monostable == true)
		{
			soundNull = true;
		}
		else if (switchTrimPitch2.monostable == true)
		{
			soundNull = true;
		}
		else if (switchTrimPitch1.bistable == true)
		{
			delayTrimPitch.state();
			
			if (delayTrimPitch.update == true)
			{
				soundNull = true;
				delayTrimPitch.duration (50);
			}
		}
		else if (switchTrimPitch2.bistable == true)
		{
			delayTrimPitch.state();
			
			if (delayTrimPitch.update == true)
			{
				soundNull = true;
				delayTrimPitch.duration (50);
			}
		}
		else
		{
			delayTrimPitch.duration (1000);
			delayTrimPitch.reset();
		}
		
		if (switchTrimRoll1.monostable == true)
		{
			soundNull = true;
		}
		else if (switchTrimRoll2.monostable == true)
		{
			soundNull = true;
		}
		else if (switchTrimRoll1.bistable == true)
		{
			delayTrimRoll.state();
			
			if (delayTrimRoll.update == true)
			{
				soundNull = true;
				delayTrimRoll.duration (50);
			}
		}
		else if (switchTrimRoll2.bistable == true)
		{
			delayTrimRoll.state();
			
			if (delayTrimRoll.update == true)
			{
				soundNull = true;
				delayTrimRoll.duration (50);
			}
		}
		else
		{
			delayTrimRoll.duration (1000);
			delayTrimRoll.reset();
		}
		
		if (switchTrimYaw1.monostable == true)
		{
			soundNull = true;
		}
		else if (switchTrimYaw2.monostable == true)
		{
			soundNull = true;
		}
		else if (switchTrimYaw1.bistable == true)
		{
			delayTrimYaw.state();
			
			if (delayTrimYaw.update == true)
			{
				soundNull = true;
				delayTrimYaw.duration (50);
			}
		}
		else if (switchTrimYaw2.bistable == true)
		{
			delayTrimYaw.state();
			
			if (delayTrimYaw.update == true)
			{
				soundNull = true;
				delayTrimYaw.duration (50);
			}
		}
		else
		{
			delayTrimYaw.duration (1000);
			delayTrimYaw.reset();
		}
		
		filterVoltageBatteryControl.set (Math::curve (0, voltageBatteryControl.value, 1023, 0, 30, 0));
		hysteresisVoltageBatteryControl.set (filterVoltageBatteryControl.value * 10.0);
		
		if (lowVoltageBatteryControl == false && (float)(hysteresisVoltageBatteryControl.value) / 10.0 < SETUP_LOW_VOLTAGE_BATTERY_CONTROL)
		{
			lowVoltageBatteryControl = true;
			soundLowVoltageBatteryControl = true;
		}
		
		if (timeDisplay.ms >= timeDisplayPrevious)
		{
			brightness--;
			
			display.brightness (brightness);
			
			timeDisplayPrevious = timeDisplay.ms + 30ull;
		}
		
		if (soundNull == true && inhibitSound == false)
		{
			SoundWrite::play (128, 200);
			timeSoundPrevious = timeSound.ms + 200ull + (unsigned long long)(TIME_SPACE_SOUND);
		}
		else if (soundSwitch1 == true && inhibitSound == false)
		{
			SoundWrite::play (1024, 20);
			timeSoundPrevious = timeSound.ms + 20ull + (unsigned long long)(TIME_SPACE_SOUND);
		}
		else if (soundSwitch2 == true && inhibitSound == false)
		{
			SoundWrite::add (1024, 20);
			SoundWrite::add (0, 40);
			SoundWrite::add (1024, 20);
			SoundWrite::play (0, 0);
			
			timeSoundPrevious = timeSound.ms + 80ull + (unsigned long long)(TIME_SPACE_SOUND);
		}
		else if (soundSwitch3 == true && inhibitSound == false)
		{
			SoundWrite::add (1024, 20);
			SoundWrite::add (0, 40);
			SoundWrite::add (1024, 20);
			SoundWrite::add (0, 40);
			SoundWrite::add (1024, 20);
			SoundWrite::play (0, 0);
			
			timeSoundPrevious = timeSound.ms + 140ull + (unsigned long long)(TIME_SPACE_SOUND);
		}
		
		if (soundLowVoltageBatteryControl == true && timeSound.ms > timeSoundPrevious)
		{
			delaySoundLowVoltageBatteryControl.state();
			
			if (delaySoundLowVoltageBatteryControl.update == true)
			{
				SoundWrite::play (2048, 100);
			}
		}
		
		soundNull = false;
		soundSwitch1 = false;
		soundSwitch2 = false;
		soundSwitch3 = false;
		
		inhibitSound = false;
	}
	
	if (Eeprom::read (1, 8) != 0)
	{
		Eeprom::write (1, 0, 8);
		Eeprom::write (2, 512, 16);
		Eeprom::write (4, 512, 16);
		Eeprom::write (6, 512, 16);
		Eeprom::write (8, 512, 16);
		Eeprom::write (10, 512, 16);
		Eeprom::write (12, 512, 16);
		Eeprom::write (14, 512, 16);
		Eeprom::write (16, 512, 16);
		Eeprom::write (18, 512, 16);
		Eeprom::write (20, 512, 16);
	}
	
	settingMinThrottle = Eeprom::read (2, 16);
	settingMaxThrottle = Eeprom::read (4, 16);
	settingMinPitch = Eeprom::read (6, 16);
	settingMaxPitch = Eeprom::read (8, 16);
	settingMinRoll = Eeprom::read (10, 16);
	settingMaxRoll = Eeprom::read (12, 16);
	settingMinYaw = Eeprom::read (14, 16);
	settingMaxYaw = Eeprom::read (16, 16);
	settingMinAuxiliaryD = Eeprom::read (18, 16);
	settingMaxAuxiliaryD = Eeprom::read (20, 16);
	
	inhibitSound = true;
	
	timeWatchDog.start (0);
	timeButtonSelect.start (0);
	
	while (true)
	{
		timeWatchDog.state();
		timeButtonSelect.state();
		timeDisplay.state();
		timeSound.state();
		timer.state();
		
		filterPotentiometerThrottle = 0;
		filterPotentiometerPitch = 0;
		filterPotentiometerRoll = 0;
		filterPotentiometerYaw = 0;
		filterPotentiometerAuxiliaryD = 0;
		
		for (iterationFilterPotentiometer = 0; iterationFilterPotentiometer < COUNT_FILTER_POTENTIOMETER; iterationFilterPotentiometer++)
		{
			potentiometerThrottle.read();
			potentiometerPitch.read();
			potentiometerRoll.read();
			potentiometerYaw.read();
			potentiometerAuxiliaryD.read();
			
			filterPotentiometerThrottle += potentiometerThrottle.value;
			filterPotentiometerPitch += potentiometerPitch.value;
			filterPotentiometerRoll += potentiometerRoll.value;
			filterPotentiometerYaw += potentiometerYaw.value;
			filterPotentiometerAuxiliaryD += potentiometerAuxiliaryD.value;
		}
		
		filterPotentiometerThrottle = filterPotentiometerThrottle / (float)(COUNT_FILTER_POTENTIOMETER);
		filterPotentiometerPitch = filterPotentiometerPitch / (float)(COUNT_FILTER_POTENTIOMETER);
		filterPotentiometerRoll = filterPotentiometerRoll / (float)(COUNT_FILTER_POTENTIOMETER);
		filterPotentiometerYaw = filterPotentiometerYaw / (float)(COUNT_FILTER_POTENTIOMETER);
		filterPotentiometerAuxiliaryD = filterPotentiometerAuxiliaryD / (float)(COUNT_FILTER_POTENTIOMETER);
		
		switchPowerState.read();
		potentiometerSelect.read();
		buttonSelect.read();
		switchCut.read();
		switchAuxiliaryA1.read();
		switchAuxiliaryA2.read();
		switchAuxiliaryB1.read();
		switchAuxiliaryB2.read();
		switchAuxiliaryC1.read();
		switchAuxiliaryC2.read();
		switchTrimThrottle1.read();
		switchTrimThrottle2.read();
		switchTrimPitch1.read();
		switchTrimPitch2.read();
		switchTrimRoll1.read();
		switchTrimRoll2.read();
		switchTrimYaw1.read();
		switchTrimYaw2.read();
		voltageBatteryControl.read();
		
		channelVoltageBatteryModelTelemetryWatchDogUpdated.receive();
		
		filterVoltageBatteryModel.set (Math::curve (0, channelVoltageBatteryModelTelemetryWatchDogUpdated.data & 0b00000000000000000000001111111111, 1023, 0, 30, 0));
		hysteresisVoltageBatteryModel.set (filterVoltageBatteryModel.value * 10.0);
		filterTelemetry.set ((float)((channelVoltageBatteryModelTelemetryWatchDogUpdated.data & 0b00000011111111111111110000000000) >> 10) / 10.0);
		hysteresisTelemetry.set (filterTelemetry.value * 10.0);
		
		if (onAir == true)
		{
			dataWatchDog = (channelVoltageBatteryModelTelemetryWatchDogUpdated.data & 0b01111100000000000000000000000000) >> 26;
			
			if (dataWatchDog != dataWatchDogPrevious)
			{
				dataWatchDogPrevious = dataWatchDog;
				timeWatchDogPrevious = timeWatchDog.ms;
				
				watchDog = true;
			}
			else if (timeWatchDog.ms >= timeWatchDogPrevious + 3000ull)
			{
				watchDog = false;
			}
			
			if (watchDog != watchDogPrevious)
			{
				watchDogPrevious = watchDog;
				
				if (watchDog == true)
				{
					soundWatchDog = 1;
				}
				else
				{
					soundWatchDog = 2;
				}
			}
		}
		
		updated = (channelVoltageBatteryModelTelemetryWatchDogUpdated.data & 0b10000000000000000000000000000000) >> 31;
		
		if (settingTrimThrottleTune != 255)
		{
			if (settingInvertThrottle == false)
			{
				throttle = Math::round (Math::wurve (settingMinThrottle + OFFSET_POTENTIOMETER, filterPotentiometerThrottle, settingMaxThrottle - OFFSET_POTENTIOMETER, 0, ((float)(settingTrimThrottleTune) * 4.0) + 3.5, 1023, (float)(settingCurveThrottle) / 10.0, (float)(settingCurveThrottle) / 10.0));
			}
			else
			{
				throttle = Math::round (Math::wurve (settingMinThrottle + OFFSET_POTENTIOMETER, filterPotentiometerThrottle, settingMaxThrottle - OFFSET_POTENTIOMETER, 1023, ((float)(settingTrimThrottleTune) * 4.0) + 3.5, 0, (float)(settingCurveThrottle) / 10.0, (float)(settingCurveThrottle) / 10.0));
			}
		}
		else
		{
			if (settingInvertThrottle == false)
			{
				throttle = Math::round (Math::wurve (settingMinThrottle + OFFSET_POTENTIOMETER, filterPotentiometerThrottle, settingMaxThrottle - OFFSET_POTENTIOMETER, 0, 511.5, 1023, (float)(settingCurveThrottle) / 10.0, (float)(settingCurveThrottle) / 10.0));
			}
			else
			{
				throttle = Math::round (Math::wurve (settingMinThrottle + OFFSET_POTENTIOMETER, filterPotentiometerThrottle, settingMaxThrottle - OFFSET_POTENTIOMETER, 1023, 511.5, 0, (float)(settingCurveThrottle) / 10.0, (float)(settingCurveThrottle) / 10.0));
			}
		}
		
		throttleRaw = Math::round (Math::curve (settingMinThrottle + OFFSET_POTENTIOMETER, filterPotentiometerThrottle, settingMaxThrottle - OFFSET_POTENTIOMETER, 0, 1023, 0));
		
		if (settingTrimPitchTune != 255)
		{
			if (settingInvertPitch == false)
			{
				pitch = Math::round (Math::wurve (settingMinPitch + OFFSET_POTENTIOMETER, filterPotentiometerPitch, settingMaxPitch - OFFSET_POTENTIOMETER, 0, ((float)(settingTrimPitchTune) * 4.0) + 3.5, 1023, (float)(settingCurvePitch) / 10.0, (float)(settingCurvePitch) / 10.0));
			}
			else
			{
				pitch = Math::round (Math::wurve (settingMinPitch + OFFSET_POTENTIOMETER, filterPotentiometerPitch, settingMaxPitch - OFFSET_POTENTIOMETER, 1023, ((float)(settingTrimPitchTune) * 4.0) + 3.5, 0, (float)(settingCurvePitch) / 10.0, (float)(settingCurvePitch) / 10.0));
			}
		}
		else
		{
			if (settingInvertPitch == false)
			{
				pitch = Math::round (Math::wurve (settingMinPitch + OFFSET_POTENTIOMETER, filterPotentiometerPitch, settingMaxPitch - OFFSET_POTENTIOMETER, 0, 511.5, 1023, (float)(settingCurvePitch) / 10.0, (float)(settingCurvePitch) / 10.0));
			}
			else
			{
				pitch = Math::round (Math::wurve (settingMinPitch + OFFSET_POTENTIOMETER, filterPotentiometerPitch, settingMaxPitch - OFFSET_POTENTIOMETER, 1023, 511.5, 0, (float)(settingCurvePitch) / 10.0, (float)(settingCurvePitch) / 10.0));
			}
		}
		
		if (settingTrimRollTune != 255)
		{
			if (settingInvertRoll == false)
			{
				roll = Math::round (Math::wurve (settingMinRoll + OFFSET_POTENTIOMETER, filterPotentiometerRoll, settingMaxRoll - OFFSET_POTENTIOMETER, 0, ((float)(settingTrimRollTune) * 4.0) + 3.5, 1023, (float)(settingCurveRoll) / 10.0, (float)(settingCurveRoll) / 10.0));
			}
			else
			{
				roll = Math::round (Math::wurve (settingMinRoll + OFFSET_POTENTIOMETER, filterPotentiometerRoll, settingMaxRoll - OFFSET_POTENTIOMETER, 1023, ((float)(settingTrimRollTune) * 4.0) + 3.5, 0, (float)(settingCurveRoll) / 10.0, (float)(settingCurveRoll) / 10.0));
			}
		}
		else
		{
			if (settingInvertRoll == false)
			{
				roll = Math::round (Math::wurve (settingMinRoll + OFFSET_POTENTIOMETER, filterPotentiometerRoll, settingMaxRoll - OFFSET_POTENTIOMETER, 0, 511.5, 1023, (float)(settingCurveRoll) / 10.0, (float)(settingCurveRoll) / 10.0));
			}
			else
			{
				roll = Math::round (Math::wurve (settingMinRoll + OFFSET_POTENTIOMETER, filterPotentiometerRoll, settingMaxRoll - OFFSET_POTENTIOMETER, 1023, 511.5, 0, (float)(settingCurveRoll) / 10.0, (float)(settingCurveRoll) / 10.0));
			}
		}
		
		if (settingTrimYawTune != 255)
		{
			if (settingInvertYaw == false)
			{
				yaw = Math::round (Math::wurve (settingMinYaw + OFFSET_POTENTIOMETER, filterPotentiometerYaw, settingMaxYaw - OFFSET_POTENTIOMETER, 0, ((float)(settingTrimYawTune) * 4.0) + 3.5, 1023, (float)(settingCurveYaw) / 10.0, (float)(settingCurveYaw) / 10.0));
			}
			else
			{
				yaw = Math::round (Math::wurve (settingMinYaw + OFFSET_POTENTIOMETER, filterPotentiometerYaw, settingMaxYaw - OFFSET_POTENTIOMETER, 1023, ((float)(settingTrimYawTune) * 4.0) + 3.5, 0, (float)(settingCurveYaw) / 10.0, (float)(settingCurveYaw) / 10.0));
			}
		}
		else
		{
			if (settingInvertYaw == false)
			{
				yaw = Math::round (Math::wurve (settingMinYaw + OFFSET_POTENTIOMETER, filterPotentiometerYaw, settingMaxYaw - OFFSET_POTENTIOMETER, 0, 511.5, 1023, (float)(settingCurveYaw) / 10.0, (float)(settingCurveYaw) / 10.0));
			}
			else
			{
				yaw = Math::round (Math::wurve (settingMinYaw + OFFSET_POTENTIOMETER, filterPotentiometerYaw, settingMaxYaw - OFFSET_POTENTIOMETER, 1023, 511.5, 0, (float)(settingCurveYaw) / 10.0, (float)(settingCurveYaw) / 10.0));
			}
		}
		
		cut = switchCut.bistable;
		
		if (cut != cutPrevious)
		{
			cutPrevious = cut;
			
			if (cut == false)
			{
				soundSwitch1 = true;
			}
			else
			{
				soundSwitch2 = true;
			}
		}
		
		if (switchAuxiliaryA1.bistable == true)
		{
			auxiliaryA = 0;
		}
		else if (switchAuxiliaryA2.bistable == true)
		{
			auxiliaryA = 2;
		}
		else
		{
			auxiliaryA = 1;
		}
		
		if (auxiliaryA != auxiliaryAPrevious)
		{
			auxiliaryAPrevious = auxiliaryA;
			
			if (auxiliaryA == 0)
			{
				soundSwitch1 = true;
			}
			else if (auxiliaryA == 1)
			{
				soundSwitch2 = true;
			}
			else
			{
				soundSwitch3 = true;
			}
		}
		
		if (switchAuxiliaryB1.bistable == true)
		{
			auxiliaryB = 0;
		}
		else if (switchAuxiliaryB2.bistable == true)
		{
			auxiliaryB = 2;
		}
		else
		{
			auxiliaryB = 1;
		}
		
		if (auxiliaryB != auxiliaryBPrevious)
		{
			auxiliaryBPrevious = auxiliaryB;
			
			if (auxiliaryB == 0)
			{
				soundSwitch1 = true;
			}
			else if (auxiliaryB == 1)
			{
				soundSwitch2 = true;
			}
			else
			{
				soundSwitch3 = true;
			}
		}
		
		if (switchAuxiliaryC1.bistable == true)
		{
			auxiliaryC = 0;
		}
		else if (switchAuxiliaryC2.bistable == true)
		{
			auxiliaryC = 2;
		}
		else
		{
			auxiliaryC = 1;
		}
		
		if (auxiliaryC != auxiliaryCPrevious)
		{
			auxiliaryCPrevious = auxiliaryC;
			
			if (auxiliaryC == 0)
			{
				soundSwitch1 = true;
			}
			else if (auxiliaryC == 1)
			{
				soundSwitch2 = true;
			}
			else
			{
				soundSwitch3 = true;
			}
		}
		
		auxiliaryD = Math::round (Math::curve (settingMinAuxiliaryD + OFFSET_POTENTIOMETER, filterPotentiometerAuxiliaryD, settingMaxAuxiliaryD - OFFSET_POTENTIOMETER, 0, 1023, 0));
		
		if (failSafe < 31)
		{
			failSafe++;
		}
		else
		{
			failSafe = 0;
		}
		
		if (flipFlopTransmit == false)
		{
			channelThrottleRollAuxiliaryCAuxiliaryD.transmit ((signed long)(auxiliaryD) << 22 | (signed long)(auxiliaryC) << 20 | (signed long)(roll) << 10 | (signed long)(throttle));
			flipFlopTransmit = true;
		}
		else
		{
			channelPitchYawCutAuxiliaryAAuxiliaryBFailSafeUpdate.transmit ((signed long)(update) << 30 | (signed long)(failSafe) << 25 | (signed long)(auxiliaryB) << 23 | (signed long)(auxiliaryA) << 21 | (signed long)(cut) << 20 | (signed long)(yaw) << 10 | (signed long)(pitch));
			flipFlopTransmit = false;
		}
		
		if (downloadedSetting == false || locked == true || menuSetting == false)
		{
			if (switchTrimThrottle1.monostable == true)
			{
				if (settingTrimThrottleTune < 254 && buttonSelect.bistable == false)
				{
					settingTrimThrottleTune++;
					soundSwitch1 = true;
				}
				else
				{
					soundNull = true;
				}
			}
			else if (switchTrimThrottle2.monostable == true)
			{
				if (settingTrimThrottleTune > 0 && settingTrimThrottleTune != 255 && buttonSelect.bistable == false)
				{
					settingTrimThrottleTune--;
					soundSwitch1 = true;
				}
				else
				{
					soundNull = true;
				}
			}
			else if (switchTrimThrottle1.bistable == true)
			{
				delayTrimThrottle.state();
				
				if (delayTrimThrottle.update == true)
				{
					if (settingTrimThrottleTune < 254 && buttonSelect.bistable == false)
					{
						settingTrimThrottleTune++;
						soundSwitch1 = true;
					}
					else
					{
						soundNull = true;
					}
					
					delayTrimThrottle.duration (50);
				}
			}
			else if (switchTrimThrottle2.bistable == true)
			{
				delayTrimThrottle.state();
				
				if (delayTrimThrottle.update == true)
				{
					if (settingTrimThrottleTune > 0 && settingTrimThrottleTune != 255 && buttonSelect.bistable == false)
					{
						settingTrimThrottleTune--;
						soundSwitch1 = true;
					}
					else
					{
						soundNull = true;
					}
					
					delayTrimThrottle.duration (50);
				}
			}
			else
			{
				delayTrimThrottle.duration (1000);
				delayTrimThrottle.reset();
			}
			
			if (switchTrimPitch1.monostable == true)
			{
				if (settingTrimPitchTune < 254 && buttonSelect.bistable == false)
				{
					settingTrimPitchTune++;
					soundSwitch1 = true;
				}
				else
				{
					soundNull = true;
				}
			}
			else if (switchTrimPitch2.monostable == true)
			{
				if (settingTrimPitchTune > 0 && settingTrimPitchTune != 255 && buttonSelect.bistable == false)
				{
					settingTrimPitchTune--;
					soundSwitch1 = true;
				}
				else
				{
					soundNull = true;
				}
			}
			else if (switchTrimPitch1.bistable == true)
			{
				delayTrimPitch.state();
				
				if (delayTrimPitch.update == true)
				{
					if (settingTrimPitchTune < 254 && buttonSelect.bistable == false)
					{
						settingTrimPitchTune++;
						soundSwitch1 = true;
					}
					else
					{
						soundNull = true;
					}
					
					delayTrimPitch.duration (50);
				}
			}
			else if (switchTrimPitch2.bistable == true)
			{
				delayTrimPitch.state();
				
				if (delayTrimPitch.update == true)
				{
					if (settingTrimPitchTune > 0 && settingTrimPitchTune != 255 && buttonSelect.bistable == false)
					{
						settingTrimPitchTune--;
						soundSwitch1 = true;
					}
					else
					{
						soundNull = true;
					}
					
					delayTrimPitch.duration (50);
				}
			}
			else
			{
				delayTrimPitch.duration (1000);
				delayTrimPitch.reset();
			}
			
			if (switchTrimRoll1.monostable == true)
			{
				if (settingTrimRollTune < 254 && buttonSelect.bistable == false)
				{
					settingTrimRollTune++;
					soundSwitch1 = true;
				}
				else
				{
					soundNull = true;
				}
			}
			else if (switchTrimRoll2.monostable == true)
			{
				if (settingTrimRollTune > 0 && settingTrimRollTune != 255 && buttonSelect.bistable == false)
				{
					settingTrimRollTune--;
					soundSwitch1 = true;
				}
				else
				{
					soundNull = true;
				}
			}
			else if (switchTrimRoll1.bistable == true)
			{
				delayTrimRoll.state();
				
				if (delayTrimRoll.update == true)
				{
					if (settingTrimRollTune < 254 && buttonSelect.bistable == false)
					{
						settingTrimRollTune++;
						soundSwitch1 = true;
					}
					else
					{
						soundNull = true;
					}
					
					delayTrimRoll.duration (50);
				}
			}
			else if (switchTrimRoll2.bistable == true)
			{
				delayTrimRoll.state();
				
				if (delayTrimRoll.update == true)
				{
					if (settingTrimRollTune > 0 && settingTrimRollTune != 255 && buttonSelect.bistable == false)
					{
						settingTrimRollTune--;
						soundSwitch1 = true;
					}
					else
					{
						soundNull = true;
					}
					
					delayTrimRoll.duration (50);
				}
			}
			else
			{
				delayTrimRoll.duration (1000);
				delayTrimRoll.reset();
			}
			
			if (switchTrimYaw1.monostable == true)
			{
				if (settingTrimYawTune < 254 && buttonSelect.bistable == false)
				{
					settingTrimYawTune++;
					soundSwitch1 = true;
				}
				else
				{
					soundNull = true;
				}
			}
			else if (switchTrimYaw2.monostable == true)
			{
				if (settingTrimYawTune > 0 && settingTrimYawTune != 255 && buttonSelect.bistable == false)
				{
					settingTrimYawTune--;
					soundSwitch1 = true;
				}
				else
				{
					soundNull = true;
				}
			}
			else if (switchTrimYaw1.bistable == true)
			{
				delayTrimYaw.state();
				
				if (delayTrimYaw.update == true)
				{
					if (settingTrimYawTune < 254 && buttonSelect.bistable == false)
					{
						settingTrimYawTune++;
						soundSwitch1 = true;
					}
					else
					{
						soundNull = true;
					}
					
					delayTrimYaw.duration (50);
				}
			}
			else if (switchTrimYaw2.bistable == true)
			{
				delayTrimYaw.state();
				
				if (delayTrimYaw.update == true)
				{
					if (settingTrimYawTune > 0 && settingTrimYawTune != 255 && buttonSelect.bistable == false)
					{
						settingTrimYawTune--;
						soundSwitch1 = true;
					}
					else
					{
						soundNull = true;
					}
					
					delayTrimYaw.duration (50);
				}
			}
			else
			{
				delayTrimYaw.duration (1000);
				delayTrimYaw.reset();
			}
		}
		else
		{
			if (switchTrimThrottle1.monostable == true || switchTrimPitch1.monostable == true || switchTrimRoll1.monostable == true || switchTrimYaw1.monostable == true)
			{
				if (select.value == 0)
				{
					if (settingVoltageBatteryModelLowTune < 1000 && buttonSelect.bistable == false)
					{
						settingVoltageBatteryModelLowTune++;
						soundSwitch1 = true;
					}
					else
					{
						soundNull = true;
					}
				}
				else if (select.value == 1)
				{
					if (settingTimerEndTune < 3600 && buttonSelect.bistable == false)
					{
						settingTimerEndTune++;
						soundSwitch1 = true;
					}
					else
					{
						soundNull = true;
					}
				}
				else if (select.value == 2)
				{
					if (settingTimerTriggerTune < 1023 && buttonSelect.bistable == false)
					{
						settingTimerTriggerTune++;
						soundSwitch1 = true;
					}
					else
					{
						soundNull = true;
					}
				}
				else if (select.value == 3)
				{
					if (settingInvertThrottleTune == false)
					{
						settingInvertThrottleTune = true;
					}
					else
					{
						settingInvertThrottleTune = false;
					}
					
					soundSwitch1 = true;
				}
				else if (select.value == 4)
				{
					if (settingInvertPitchTune == false)
					{
						settingInvertPitchTune = true;
					}
					else
					{
						settingInvertPitchTune = false;
					}
					
					soundSwitch1 = true;
				}
				else if (select.value == 5)
				{
					if (settingInvertRollTune == false)
					{
						settingInvertRollTune = true;
					}
					else
					{
						settingInvertRollTune = false;
					}
					
					soundSwitch1 = true;
				}
				else if (select.value == 6)
				{
					if (settingInvertYawTune == false)
					{
						settingInvertYawTune = true;
					}
					else
					{
						settingInvertYawTune = false;
					}
					
					soundSwitch1 = true;
				}
				else if (select.value == 7)
				{
					if (settingCurveThrottleTune < 100 && buttonSelect.bistable == false)
					{
						settingCurveThrottleTune++;
						soundSwitch1 = true;
					}
					else
					{
						soundNull = true;
					}
				}
				else if (select.value == 8)
				{
					if (settingCurvePitchTune < 100 && buttonSelect.bistable == false)
					{
						settingCurvePitchTune++;
						soundSwitch1 = true;
					}
					else
					{
						soundNull = true;
					}
				}
				else if (select.value == 9)
				{
					if (settingCurveRollTune < 100 && buttonSelect.bistable == false)
					{
						settingCurveRollTune++;
						soundSwitch1 = true;
					}
					else
					{
						soundNull = true;
					}
				}
				else if (select.value == 10)
				{
					if (settingCurveYawTune < 100 && buttonSelect.bistable == false)
					{
						settingCurveYawTune++;
						soundSwitch1 = true;
					}
					else
					{
						soundNull = true;
					}
				}
				else if (select.value >= 11 && select.value < countSettingOption + 11)
				{
					if (settingOptionTune [mapSettingOption [select.value - 11]] < settingOptionMax [mapSettingOption [select.value - 11]] && buttonSelect.bistable == false)
					{
						settingOptionTune [mapSettingOption [select.value - 11]]++;
						soundSwitch1 = true;
					}
					else
					{
						soundNull = true;
					}
				}
				else
				{
					soundNull = true;
				}
			}
			else if (switchTrimThrottle2.monostable == true || switchTrimPitch2.monostable == true || switchTrimRoll2.monostable == true || switchTrimYaw2.monostable == true)
			{
				if (select.value == 0)
				{
					if (settingVoltageBatteryModelLowTune > 0 && buttonSelect.bistable == false)
					{
						settingVoltageBatteryModelLowTune--;
						soundSwitch1 = true;
					}
					else
					{
						soundNull = true;
					}
				}
				else if (select.value == 1)
				{
					if (settingTimerEndTune > 0 && buttonSelect.bistable == false)
					{
						settingTimerEndTune--;
						soundSwitch1 = true;
					}
					else
					{
						soundNull = true;
					}
				}
				else if (select.value == 2)
				{
					if (settingTimerTriggerTune > 0 && buttonSelect.bistable == false)
					{
						settingTimerTriggerTune--;
						soundSwitch1 = true;
					}
					else
					{
						soundNull = true;
					}
				}
				else if (select.value == 3)
				{
					if (settingInvertThrottleTune == true)
					{
						settingInvertThrottleTune = false;
					}
					else
					{
						settingInvertThrottleTune = true;
					}
					
					soundSwitch1 = true;
				}
				else if (select.value == 4)
				{
					if (settingInvertPitchTune == true)
					{
						settingInvertPitchTune = false;
					}
					else
					{
						settingInvertPitchTune = true;
					}
					
					soundSwitch1 = true;
				}
				else if (select.value == 5)
				{
					if (settingInvertRollTune == true)
					{
						settingInvertRollTune = false;
					}
					else
					{
						settingInvertRollTune = true;
					}
					
					soundSwitch1 = true;
				}
				else if (select.value == 6)
				{
					if (settingInvertYawTune == true)
					{
						settingInvertYawTune = false;
					}
					else
					{
						settingInvertYawTune = true;
					}
					
					soundSwitch1 = true;
				}
				else if (select.value == 7)
				{
					if (settingCurveThrottleTune > 0 && buttonSelect.bistable == false)
					{
						settingCurveThrottleTune--;
						soundSwitch1 = true;
					}
					else
					{
						soundNull = true;
					}
				}
				else if (select.value == 8)
				{
					if (settingCurvePitchTune > 0 && buttonSelect.bistable == false)
					{
						settingCurvePitchTune--;
						soundSwitch1 = true;
					}
					else
					{
						soundNull = true;
					}
				}
				else if (select.value == 9)
				{
					if (settingCurveRollTune > 0 && buttonSelect.bistable == false)
					{
						settingCurveRollTune--;
						soundSwitch1 = true;
					}
					else
					{
						soundNull = true;
					}
				}
				else if (select.value == 10)
				{
					if (settingCurveYawTune > 0 && buttonSelect.bistable == false)
					{
						settingCurveYawTune--;
						soundSwitch1 = true;
					}
					else
					{
						soundNull = true;
					}
				}
				else if (select.value >= 11 && select.value < countSettingOption + 11)
				{
					if (settingOptionTune [mapSettingOption [select.value - 11]] > settingOptionMin [mapSettingOption [select.value - 11]] && buttonSelect.bistable == false)
					{
						settingOptionTune [mapSettingOption [select.value - 11]]--;
						soundSwitch1 = true;
					}
					else
					{
						soundNull = true;
					}
				}
				else
				{
					soundNull = true;
				}
			}
			else if (switchTrimThrottle1.bistable == true || switchTrimPitch1.bistable == true || switchTrimRoll1.bistable == true || switchTrimYaw1.bistable == true)
			{
				delayTrimThrottle.state();
				
				if (delayTrimThrottle.update == true)
				{
					if (select.value == 0)
					{
						if (settingVoltageBatteryModelLowTune < 1000 && buttonSelect.bistable == false)
						{
							settingVoltageBatteryModelLowTune++;
							soundSwitch1 = true;
						}
						else
						{
							soundNull = true;
						}
					}
					else if (select.value == 1)
					{
						if (settingTimerEndTune < 3600 && buttonSelect.bistable == false)
						{
							settingTimerEndTune++;
							soundSwitch1 = true;
						}
						else
						{
							soundNull = true;
						}
					}
					else if (select.value == 2)
					{
						if (settingTimerTriggerTune < 1023 && buttonSelect.bistable == false)
						{
							settingTimerTriggerTune++;
							soundSwitch1 = true;
						}
						else
						{
							soundNull = true;
						}
					}
					else if (select.value == 7)
					{
						if (settingCurveThrottleTune < 100 && buttonSelect.bistable == false)
						{
							settingCurveThrottleTune++;
							soundSwitch1 = true;
						}
						else
						{
							soundNull = true;
						}
					}
					else if (select.value == 8)
					{
						if (settingCurvePitchTune < 100 && buttonSelect.bistable == false)
						{
							settingCurvePitchTune++;
							soundSwitch1 = true;
						}
						else
						{
							soundNull = true;
						}
					}
					else if (select.value == 9)
					{
						if (settingCurveRollTune < 100 && buttonSelect.bistable == false)
						{
							settingCurveRollTune++;
							soundSwitch1 = true;
						}
						else
						{
							soundNull = true;
						}
					}
					else if (select.value == 10)
					{
						if (settingCurveYawTune < 100 && buttonSelect.bistable == false)
						{
							settingCurveYawTune++;
							soundSwitch1 = true;
						}
						else
						{
							soundNull = true;
						}
					}
					else if (select.value >= 11 && select.value < countSettingOption + 11)
					{
						if (settingOptionTune [mapSettingOption [select.value - 11]] < settingOptionMax [mapSettingOption [select.value - 11]] && buttonSelect.bistable == false)
						{
							settingOptionTune [mapSettingOption [select.value - 11]]++;
							soundSwitch1 = true;
						}
						else
						{
							soundNull = true;
						}
					}
					else
					{
						soundNull = true;
					}
					
					delayTrimThrottle.duration (50);
				}
			}
			else if (switchTrimThrottle2.bistable == true || switchTrimPitch2.bistable == true || switchTrimRoll2.bistable == true || switchTrimYaw2.bistable == true)
			{
				delayTrimThrottle.state();
				
				if (delayTrimThrottle.update == true)
				{
					if (select.value == 0)
					{
						if (settingVoltageBatteryModelLowTune > 0 && buttonSelect.bistable == false)
						{
							settingVoltageBatteryModelLowTune--;
							soundSwitch1 = true;
						}
						else
						{
							soundNull = true;
						}
					}
					else if (select.value == 1)
					{
						if (settingTimerEndTune > 0 && buttonSelect.bistable == false)
						{
							settingTimerEndTune--;
							soundSwitch1 = true;
						}
						else
						{
							soundNull = true;
						}
					}
					else if (select.value == 2)
					{
						if (settingTimerTriggerTune > 0 && buttonSelect.bistable == false)
						{
							settingTimerTriggerTune--;
							soundSwitch1 = true;
						}
						else
						{
							soundNull = true;
						}
					}
					else if (select.value == 7)
					{
						if (settingCurveThrottleTune > 0 && buttonSelect.bistable == false)
						{
							settingCurveThrottleTune--;
							soundSwitch1 = true;
						}
						else
						{
							soundNull = true;
						}
					}
					else if (select.value == 8)
					{
						if (settingCurvePitchTune > 0 && buttonSelect.bistable == false)
						{
							settingCurvePitchTune--;
							soundSwitch1 = true;
						}
						else
						{
							soundNull = true;
						}
					}
					else if (select.value == 9)
					{
						if (settingCurveRollTune > 0 && buttonSelect.bistable == false)
						{
							settingCurveRollTune--;
							soundSwitch1 = true;
						}
						else
						{
							soundNull = true;
						}
					}
					else if (select.value == 10)
					{
						if (settingCurveYawTune > 0 && buttonSelect.bistable == false)
						{
							settingCurveYawTune--;
							soundSwitch1 = true;
						}
						else
						{
							soundNull = true;
						}
					}
					else if (select.value >= 11 && select.value < countSettingOption + 11)
					{
						if (settingOptionTune [mapSettingOption [select.value - 11]] > settingOptionMin [mapSettingOption [select.value - 11]] && buttonSelect.bistable == false)
						{
							settingOptionTune [mapSettingOption [select.value - 11]]--;
							soundSwitch1 = true;
						}
						else
						{
							soundNull = true;
						}
					}
					else
					{
						soundNull = true;
					}
					
					delayTrimThrottle.duration (50);
				}
			}
			else
			{
				delayTrimThrottle.duration (1000);
				delayTrimThrottle.reset();
			}
		}
		
		if (switchPowerState.bistable == false)
		{
			if (resetShutdown == false)
			{
				if (brightness == 16 && locked == false && ((select.value != 0 && menuSetting == false) || menuSetting == true))
				{
					SpiNrf24l01p::stop();
					
					SoundWrite::add (1024, 100);
					SoundWrite::add (512, 100);
					SoundWrite::add (0, 50);
					SoundWrite::add (512, 100);
					SoundWrite::add (256, 100);
					SoundWrite::add (0, 50);
					SoundWrite::add (256, 100);
					SoundWrite::add (128, 100);
					SoundWrite::play (0, 0);
					
					for (iterationAnimation = 0; iterationAnimation < 4; iterationAnimation++)
					{
						display.clearDevice();
						display.draw (0b00000110, 1 + iterationAnimation);
						display.draw (0b00110000, 8 - iterationAnimation);
						Timer::pause (100);
						display.draw (0b00110000, 1 + iterationAnimation);
						display.draw (0b00000110, 8 - iterationAnimation);
						Timer::pause (100);
					}
					
					display.clearDevice();
					
					switchPowerHold.off();
					
					Timer::pause (1000);
					
					display.brightness (1);
					display.word ("turn off");
					
					for (iterationAnimation = 2; iterationAnimation < 16; iterationAnimation++)
					{
						Timer::pause (30);
						display.brightness (iterationAnimation);
					}
					
					while (true)
					{
					}
				}
				else
				{
					resetShutdown = true;
					soundNull = true;
				}
			}
		}
		else
		{
			resetShutdown = false;
		}
		
		filterVoltageBatteryControl.set (Math::curve (0, voltageBatteryControl.value, 1023, 0, 30, 0));
		hysteresisVoltageBatteryControl.set (filterVoltageBatteryControl.value * 10.0);
		
		if (lowVoltageBatteryControl == false && (float)(hysteresisVoltageBatteryControl.value) / 10.0 < SETUP_LOW_VOLTAGE_BATTERY_CONTROL)
		{
			lowVoltageBatteryControl = true;
			soundLowVoltageBatteryControl = true;
		}
		
		if (settingVoltageBatteryModelLow != 0)
		{
			if (lowVoltageBatteryModel == false && (float)(hysteresisVoltageBatteryModel.value) / 10.0 < (float)(settingVoltageBatteryModelLow) / 10.0)
			{
				lowVoltageBatteryModel = true;
				
				soundLowVoltageBatteryModel = 1;
				soundTimerEnded = 0;
			}
		}
		else if (lowVoltageBatteryModel == true)
		{
			lowVoltageBatteryModel = false;
			
			displayVoltageBatteryModel = 0;
			soundLowVoltageBatteryModel = 0;
		}
		
		if (settingTimerEnd != 0)
		{
			if (timerStarted == false && timerEnded == false && throttleRaw >= settingTimerTrigger && settingTimerTrigger != 0)
			{
				timer.start (0);
				timerStarted = true;
				
				soundTimerStart = true;
			}
			else if (timerStarted == false && timerEnded == false && cut == false && settingTimerTrigger == 0)
			{
				timer.start (0);
				timerStarted = true;
				
				soundTimerStart = true;
			}
			else if (timerStarted == true && ((settingTimerEnd >= 5 && timer.s >= (unsigned long long)(settingTimerEnd) - 5ull) || settingTimerEnd < 5))
			{
				timerStarted = false;
				timerEnded = true;
				
				if (lowVoltageBatteryModel == false || (lowVoltageBatteryModel == true && soundLowVoltageBatteryModel == 7))
				{
					if (settingTimerEnd >= 5 && timer.s >= (unsigned long long)(settingTimerEnd) - 5ull)
					{
						soundTimerEnded = 1;
					}
					else
					{
						soundTimerEnded = 6 - settingTimerEnd;
					}
				}
			}
		}
		else if (timerStarted == true || timerEnded == true)
		{
			timer.stop();
			
			timerStarted = false;
			timerEnded = false;
			
			displayTimerEnded = 0;
			soundTimerEnded = 0;
		}
		
		if (lowVoltageBatteryControl == true || lowVoltageBatteryModel == true || timerEnded == true)
		{
			delaySoundAlarm.state();
			
			if (delaySoundAlarm.update == true)
			{
				soundAlarm = true;
			}
		}
		else
		{
			delaySoundAlarm.reset();
		}
		
		if (menuSetting == false)
		{
			select.set (Math::curve (0, potentiometerSelect.value, 1023, 0, 9, 0));
			
			if (select.value != 0)
			{
				stateLocked = 2;
			}
			
			if (select.value != selectPrevious)
			{
				selectPrevious = select.value;
				
				if (lowVoltageBatteryControl == true)
				{
					delayDisplayLowVoltageBatteryControl.reset();
					displayVoltageBatteryControl = 1;
				}
				
				if (lowVoltageBatteryModel == true)
				{
					delayDisplayLowVoltageBatteryModel.reset();
					displayVoltageBatteryModel = 1;
				}
				
				if (timerEnded == true)
				{
					delayDisplayTimerEnded.reset();
					displayTimerEnded = 1;
				}
				
				soundSelect = true;
			}
			
			if (select.value == 0)
			{
				if (locked == false)
				{
					display.word (". lock  ");
				}
				else
				{
					display.word ("-.locked-");
				}
			}
			else if (select.value == 1)
			{
				if (lowVoltageBatteryControl == false)
				{
					if ((float)(hysteresisVoltageBatteryControl.value) / 10.0 < 0.1)
					{
						display.word ("ct.rl off");
					}
					else
					{
						display.word ("ct.rl/");
					}
				}
				else
				{
					delayDisplayLowVoltageBatteryControl.state();
					
					if (delayDisplayLowVoltageBatteryControl.update == true)
					{
						if (displayVoltageBatteryControl == 0)
						{
							displayVoltageBatteryControl = 1;
							
							if ((float)(hysteresisVoltageBatteryControl.value) / 10.0 < 0.1)
							{
								display.word ("--.-- off");
							}
							else
							{
								display.word ("--.--/");
							}
						}
						else
						{
							displayVoltageBatteryControl = 0;
							
							if ((float)(hysteresisVoltageBatteryControl.value) / 10.0 < 0.1)
							{
								display.word ("ct.rl off");
							}
							else
							{
								display.word ("ct.rl/");
							}
						}
					}
				}
				
				if ((float)(hysteresisVoltageBatteryControl.value) / 10.0 >= 0.1)
				{
					display.decimal ((float)(hysteresisVoltageBatteryControl.value) / 10.0, 5, 8, 1, true);
				}
			}
			else if (select.value == 2)
			{
				if (lowVoltageBatteryModel == false)
				{
					if (watchDog == false || (float)(hysteresisVoltageBatteryModel.value) / 10.0 < 0.1)
					{
						display.word ("mod.l off");
					}
					else
					{
						display.word ("mod.l/");
					}
				}
				else
				{
					delayDisplayLowVoltageBatteryModel.state();
					
					if (delayDisplayLowVoltageBatteryModel.update == true)
					{
						if (displayVoltageBatteryModel == 0)
						{
							displayVoltageBatteryModel = 1;
							
							if (watchDog == false || (float)(hysteresisVoltageBatteryModel.value) / 10.0 < 0.1)
							{
								display.word ("---.- off");
							}
							else
							{
								display.word ("---.-/");
							}
						}
						else
						{
							displayVoltageBatteryModel = 0;
							
							if (watchDog == false || (float)(hysteresisVoltageBatteryModel.value) / 10.0 < 0.1)
							{
								display.word ("mod.l off");
							}
							else
							{
								display.word ("mod.l/");
							}
						}
					}
				}
				
				if (watchDog == true && (float)(hysteresisVoltageBatteryModel.value) / 10.0 >= 0.1)
				{
					display.decimal ((float)(hysteresisVoltageBatteryModel.value) / 10.0, 5, 8, 1, true);
				}
			}
			else if (select.value == 3)
			{
				if (settingTimerEnd == 0)
				{
					display.word ("time. off");
				}
				else
				{
					if (timerEnded == false)
					{
						display.word ("time./");
					}
					else
					{
						delayDisplayTimerEnded.state();
						
						if (delayDisplayTimerEnded.update == true)
						{
							if (displayTimerEnded == 0)
							{
								displayTimerEnded = 1;
								display.word ("----./");
							}
							else
							{
								displayTimerEnded = 0;
								display.word ("time./");
							}
						}
					}
					
					display.integer (timer.s, 5, 8, true);
				}
			}
			else if (select.value == 4)
			{
				if (settingTrimThrottleTune == 255)
				{
					display.word ("t.hro off");
				}
				else
				{
					display.word ("t.hro/");
					display.integer (settingTrimThrottleTune - 127, 5, 8, true);
				}
			}
			else if (select.value == 5)
			{
				if (settingTrimPitchTune == 255)
				{
					display.word ("pi.tc off");
				}
				else
				{
					display.word ("pi.tc/");
					display.integer (settingTrimPitchTune - 127, 5, 8, true);
				}
			}
			else if (select.value == 6)
			{
				if (settingTrimRollTune == 255)
				{
					display.word ("rol.l off");
				}
				else
				{
					display.word ("rol.l/");
					display.integer (settingTrimRollTune - 127, 5, 8, true);
				}
			}
			else if (select.value == 7)
			{
				if (settingTrimYawTune == 255)
				{
					display.word ("yaw . off");
				}
				else
				{
					display.word ("yaw ./");
					display.integer (settingTrimYawTune - 127, 5, 8, true);
				}
			}
			else if (select.value == 8)
			{
				if (watchDog == false || (float)(hysteresisTelemetry.value) / 10.0 > -0.1 || (float)(hysteresisTelemetry.value) / 10.0 < 0.1)
				{
					display.word ("t.lmt off");
				}
				else
				{
					display.word ("t.lmt/");
					display.decimal ((float)(hysteresisTelemetry.value) / 10.0, 5, 8, 1, true);
				}
			}
			else
			{
				display.word ("se.ttings");
			}
			
			if (select.value == 0)
			{
				if (buttonSelect.bistable == true)
				{
					if (switchPowerState.bistable == true)
					{
						if (stateLocked == 0)
						{
							timeButtonSelectPrevious = timeButtonSelect.ms;
							stateLocked = 1;
						}
						else if (stateLocked == 1 && timeButtonSelect.ms >= timeButtonSelectPrevious + 1000ull)
						{
							if (locked == false)
							{
								locked = true;
								soundLocked = true;
							}
							else
							{
								locked = false;
								soundLock = true;
							}
							
							stateLocked = 2;
						}
					}
					else if (buttonSelect.monostable == true)
					{
						soundNull = true;
					}
				}
				else
				{
					stateLocked = 0;
				}
			}
			else if (select.value == 1)
			{
				if (buttonSelect.monostable == true)
				{
					if (lowVoltageBatteryControl == true && soundLowVoltageBatteryControl == true)
					{
						soundLowVoltageBatteryControl = false;
						soundOk = true;
					}
					else
					{
						soundNull = true;
					}
				}
			}
			else if (select.value == 2)
			{
				if (buttonSelect.monostable == true)
				{
					if (watchDog == true && lowVoltageBatteryModel == true && (float)(hysteresisVoltageBatteryModel.value) / 10.0 >= (float)(settingVoltageBatteryModelLow) / 10.0)
					{
						lowVoltageBatteryModel = false;
						
						displayVoltageBatteryModel = 0;
						soundLowVoltageBatteryModel = 0;
						soundOk = true;
					}
					else
					{
						soundNull = true;
					}
				}
			}
			else if (select.value == 3)
			{
				if (buttonSelect.monostable == true)
				{
					if (timerStarted == true || timerEnded == true)
					{
						timer.stop();
						
						timerStarted = false;
						timerEnded = false;
						
						displayTimerEnded = 0;
						soundTimerEnded = 0;
						soundOk = true;
					}
					else
					{
						soundNull = true;
					}
				}
			}
			else if (select.value == 4)
			{
				if (buttonSelect.monostable == true)
				{
					if (locked == false)
					{
						if (settingTrimThrottleTune == 255)
						{
							settingTrimThrottleTune = 127;
						}
						else
						{
							settingTrimThrottleTune = 255;
						}
						
						delayTrimThrottle.duration (1000);
						delayTrimThrottle.reset();
						
						soundSwitch2 = true;
					}
					else
					{
						soundNull = true;
					}
				}
			}
			else if (select.value == 5)
			{
				if (buttonSelect.monostable == true)
				{
					if (locked == false)
					{
						if (settingTrimPitchTune == 255)
						{
							settingTrimPitchTune = 127;
						}
						else
						{
							settingTrimPitchTune = 255;
						}
						
						delayTrimPitch.duration (1000);
						delayTrimPitch.reset();
						
						soundSwitch2 = true;
					}
					else
					{
						soundNull = true;
					}
				}
			}
			else if (select.value == 6)
			{
				if (buttonSelect.monostable == true)
				{
					if (locked == false)
					{
						if (settingTrimRollTune == 255)
						{
							settingTrimRollTune = 127;
						}
						else
						{
							settingTrimRollTune = 255;
						}
						
						delayTrimRoll.duration (1000);
						delayTrimRoll.reset();
						
						soundSwitch2 = true;
					}
					else
					{
						soundNull = true;
					}
				}
			}
			else if (select.value == 7)
			{
				if (buttonSelect.monostable == true)
				{
					if (locked == false)
					{
						if (settingTrimYawTune == 255)
						{
							settingTrimYawTune = 127;
						}
						else
						{
							settingTrimYawTune = 255;
						}
						
						delayTrimYaw.duration (1000);
						delayTrimYaw.reset();
						
						soundSwitch2 = true;
					}
					else
					{
						soundNull = true;
					}
				}
			}
			else if (select.value == 9)
			{
				if (buttonSelect.monostable == true)
				{
					menuSetting = true;
					
					if (onAir == true)
					{
						if (downloadedSetting == true)
						{
							settingVoltageBatteryModelLowTune = settingVoltageBatteryModelLow;
							settingTimerEndTune = settingTimerEnd;
							settingTimerTriggerTune = settingTimerTrigger;
							settingInvertThrottleTune = settingInvertThrottle;
							settingInvertPitchTune = settingInvertPitch;
							settingInvertRollTune = settingInvertRoll;
							settingInvertYawTune = settingInvertYaw;
							settingCurveThrottleTune = settingCurveThrottle;
							settingCurvePitchTune = settingCurvePitch;
							settingCurveRollTune = settingCurveRoll;
							settingCurveYawTune = settingCurveYaw;
							
							for (iterationSettingOption = 0; iterationSettingOption < countSettingOption; iterationSettingOption++)
							{
								settingOptionTune [mapSettingOption [iterationSettingOption]] = settingOption [mapSettingOption [iterationSettingOption]];
							}
							
							stateSettingTune = 2;
							
							if (locked == false)
							{
								delayTrimThrottle.duration (1000);
								delayTrimThrottle.reset();
								delayTrimPitch.duration (1000);
								delayTrimPitch.reset();
								delayTrimRoll.duration (1000);
								delayTrimRoll.reset();
								delayTrimYaw.duration (1000);
								delayTrimYaw.reset();
								
								select.set (Math::curve (0, potentiometerSelect.value, 1023, 0, countSettingOption + 12, 0));
							}
							else
							{
								select.set (Math::curve (0, potentiometerSelect.value, 1023, 0, countSettingOption + 11, 0));
							}
						}
						else
						{
							select.set (11);
						}
					}
					else
					{
						settingMinThrottleTune = settingMinThrottle;
						settingMaxThrottleTune = settingMaxThrottle;
						settingMinPitchTune = settingMinPitch;
						settingMaxPitchTune = settingMaxPitch;
						settingMinRollTune = settingMinRoll;
						settingMaxRollTune = settingMaxRoll;
						settingMinYawTune = settingMinYaw;
						settingMaxYawTune = settingMaxYaw;
						settingMinAuxiliaryDTune = settingMinAuxiliaryD;
						settingMaxAuxiliaryDTune = settingMaxAuxiliaryD;
						
						stateSettingTune = 2;
						
						if (locked == false)
						{
							select.set (Math::curve (0, potentiometerSelect.value, 1023, 0, 6, 0));
						}
						else
						{
							select.set (Math::curve (0, potentiometerSelect.value, 1023, 0, 5, 0));
						}
					}
					
					selectPrevious = select.value;
					
					soundSwitch2 = true;
				}
			}
			else if (buttonSelect.monostable == true)
			{
				soundNull = true;
			}
		}
		else if (onAir == true)
		{
			if (downloadedSetting == true)
			{
				if (locked == false)
				{
					select.set (Math::curve (0, potentiometerSelect.value, 1023, 0, countSettingOption + 12, 0));
				}
				else
				{
					select.set (Math::curve (0, potentiometerSelect.value, 1023, 0, countSettingOption + 11, 0));
				}
			}
			else
			{
				select.set (11);
			}
			
			if (select.value != selectPrevious)
			{
				selectPrevious = select.value;
				
				if (downloadedSetting == true)
				{
					stateSettingTune = 2;
					
					if (locked == false)
					{
						delayTrimThrottle.duration (1000);
						delayTrimThrottle.reset();
						delayTrimPitch.duration (1000);
						delayTrimPitch.reset();
						delayTrimRoll.duration (1000);
						delayTrimRoll.reset();
						delayTrimYaw.duration (1000);
						delayTrimYaw.reset();
					}
				}
				
				soundSelect = true;
			}
			
			if (select.value == 0)
			{
				if (settingVoltageBatteryModelLowTune == 0)
				{
					display.word ("b.mdl off");
				}
				else
				{
					display.word ("b.mdl/");
					display.decimal ((float)(settingVoltageBatteryModelLowTune) / 10.0, 5, 8, 1, true);
				}
			}
			else if (select.value == 1)
			{
				if (settingTimerEndTune == 0)
				{
					display.word ("tm.ed off");
				}
				else
				{
					display.word ("tm.ed/");
					display.integer (settingTimerEndTune, 5, 8, true);
				}
			}
			else if (select.value == 2)
			{
				if (settingTimerTriggerTune == 0)
				{
					display.word ("tmt.r cut");
				}
				else
				{
					display.word ("tmt.r/");
					display.integer (settingTimerTriggerTune, 5, 8, true);
				}
			}
			else if (select.value == 3)
			{
				if (settingInvertThrottleTune == false)
				{
					display.word ("drth. nor");
				}
				else
				{
					display.word ("drth. rev");
				}
			}
			else if (select.value == 4)
			{
				if (settingInvertPitchTune == false)
				{
					display.word ("d.rpi nor");
				}
				else
				{
					display.word ("d.rpi rev");
				}
			}
			else if (select.value == 5)
			{
				if (settingInvertRollTune == false)
				{
					display.word ("dr.ro nor");
				}
				else
				{
					display.word ("dr.ro rev");
				}
			}
			else if (select.value == 6)
			{
				if (settingInvertYawTune == false)
				{
					display.word ("dry.a nor");
				}
				else
				{
					display.word ("dry.a rev");
				}
			}
			else if (select.value == 7)
			{
				if (settingCurveThrottleTune == 0)
				{
					display.word ("cuth. off");
				}
				else
				{
					display.word ("cuth./");
					display.integer (settingCurveThrottleTune, 5, 8, true);
				}
			}
			else if (select.value == 8)
			{
				if (settingCurvePitchTune == 0)
				{
					display.word ("c.upi off");
				}
				else
				{
					display.word ("c.upi/");
					display.integer (settingCurvePitchTune, 5, 8, true);
				}
			}
			else if (select.value == 9)
			{
				if (settingCurveRollTune == 0)
				{
					display.word ("cu.ro off");
				}
				else
				{
					display.word ("cu.ro/");
					display.integer (settingCurveRollTune, 5, 8, true);
				}
			}
			else if (select.value == 10)
			{
				if (settingCurveYawTune == 0)
				{
					display.word ("cuy.a off");
				}
				else
				{
					display.word ("cuy.a/");
					display.integer (settingCurveYawTune, 5, 8, true);
				}
			}
			else if (select.value >= 11 && select.value < countSettingOption + 11)
			{
				for (iterationAnimation = 0; iterationAnimation < 4; iterationAnimation++)
				{
					if (iterationAnimation == select.value % 4)
					{
						display.draw (settingOptionWord [mapSettingOption [select.value - 11]][iterationAnimation] | 0b10000000, iterationAnimation + 1);
					}
					else
					{
						display.draw (settingOptionWord [mapSettingOption [select.value - 11]][iterationAnimation], iterationAnimation + 1);
					}
				}
				
				if (settingOptionCenter [mapSettingOption [select.value - 11]] == false)
				{
					if (settingOptionDecimal [mapSettingOption [select.value - 11]] == false)
					{
						display.integer (settingOptionTune [mapSettingOption [select.value - 11]], 5, 8, true);
					}
					else
					{
						display.decimal ((float)(settingOptionTune [mapSettingOption [select.value - 11]]) / 10.0, 5, 8, 1, true);
					}
				}
				else
				{
					if (settingOptionDecimal [mapSettingOption [select.value - 11]] == false)
					{
						display.integer (settingOptionTune [mapSettingOption [select.value - 11]] - Math::round (Math::center (settingOptionMin [mapSettingOption [select.value - 11]], settingOptionMax [mapSettingOption [select.value - 11]])), 5, 8, true);
					}
					else
					{
						display.decimal (((float)(settingOptionTune [mapSettingOption [select.value - 11]]) - (float)(Math::round (Math::center (settingOptionMin [mapSettingOption [select.value - 11]], settingOptionMax [mapSettingOption [select.value - 11]])))) / 10.0, 5, 8, 1, true);
					}
				}
			}
			else if (select.value == countSettingOption + 11)
			{
				if (downloadedSetting == true)
				{
					for (iterationAnimation = 0; iterationAnimation < 8; iterationAnimation++)
					{
						if (iterationAnimation == select.value % 4)
						{
							display.draw (Tool::characterToByte (&WORD_EXIT [iterationAnimation]) | 0b10000000, iterationAnimation + 1);
						}
						else
						{
							display.draw (Tool::characterToByte (&WORD_EXIT [iterationAnimation]), iterationAnimation + 1);
						}
					}
				}
				else
				{
					display.word (". exit  ");
				}
			}
			else
			{
				if (settingVoltageBatteryModelLowTune != settingVoltageBatteryModelLow || settingTimerEndTune != settingTimerEnd || settingTimerTriggerTune != settingTimerTrigger || settingTrimThrottleTune != settingTrimThrottle || settingTrimPitchTune != settingTrimPitch || settingTrimRollTune != settingTrimRoll || settingTrimYawTune != settingTrimYaw || settingInvertThrottleTune != settingInvertThrottle || settingInvertPitchTune != settingInvertPitch || settingInvertRollTune != settingInvertRoll || settingInvertYawTune != settingInvertYaw || settingCurveThrottleTune != settingCurveThrottle || settingCurvePitchTune != settingCurvePitch || settingCurveRollTune != settingCurveRoll || settingCurveYawTune != settingCurveYaw)
				{
					updateNeeded = true;
				}
				else
				{
					updateNeeded = false;
				}
				
				for (iterationSettingOption = 0; iterationSettingOption < countSettingOption && updateNeeded == false; iterationSettingOption++)
				{
					if (settingOptionTune [mapSettingOption [iterationSettingOption]] != settingOption [mapSettingOption [iterationSettingOption]])
					{
						updateNeeded = true;
					}
				}
				
				if (updateLeaved == true)
				{
					updateNeeded = true;
				}
				
				for (iterationAnimation = 0; iterationAnimation < 8; iterationAnimation++)
				{
					if (iterationAnimation == select.value % 4)
					{
						if (updateNeeded == false)
						{
							display.draw (Tool::characterToByte (&WORD_UPDATE [iterationAnimation]) | 0b10000000, iterationAnimation + 1);
						}
						else
						{
							display.draw (Tool::characterToByte (&WORD_UPDATE_NEEDED [iterationAnimation]) | 0b10000000, iterationAnimation + 1);
						}
					}
					else
					{
						if (updateNeeded == false)
						{
							display.draw (Tool::characterToByte (&WORD_UPDATE [iterationAnimation]), iterationAnimation + 1);
						}
						else
						{
							display.draw (Tool::characterToByte (&WORD_UPDATE_NEEDED [iterationAnimation]), iterationAnimation + 1);
						}
					}
				}
			}
			
			if (select.value == 0)
			{
				if (buttonSelect.bistable == true && stateSettingTune == 0)
				{
					stateSettingTune = 1;
					filterPotentiometerSetting.reset();
					
					settingTunePrevious = settingVoltageBatteryModelLowTune;
					
					soundSwitch3 = true;
				}
				else if (buttonSelect.bistable == true && stateSettingTune == 1)
				{
					filterPotentiometerSetting.set (Math::curve (settingMinAuxiliaryD + OFFSET_POTENTIOMETER, filterPotentiometerAuxiliaryD, settingMaxAuxiliaryD - OFFSET_POTENTIOMETER, 0, 1000, 0));
					hysteresisPotentiometerSetting.set (filterPotentiometerSetting.value);
					settingVoltageBatteryModelLowTune = hysteresisPotentiometerSetting.value;
					
					if (settingVoltageBatteryModelLowTune != settingTunePrevious)
					{
						settingTunePrevious = settingVoltageBatteryModelLowTune;
						soundTune = true;
					}
				}
				else if (buttonSelect.bistable == false)
				{
					stateSettingTune = 0;
				}
			}
			else if (select.value == 1)
			{
				if (buttonSelect.bistable == true && stateSettingTune == 0)
				{
					stateSettingTune = 1;
					filterPotentiometerSetting.reset();
					
					settingTunePrevious = settingTimerEndTune;
					
					soundSwitch3 = true;
				}
				else if (buttonSelect.bistable == true && stateSettingTune == 1)
				{
					filterPotentiometerSetting.set (Math::curve (settingMinAuxiliaryD + OFFSET_POTENTIOMETER, filterPotentiometerAuxiliaryD, settingMaxAuxiliaryD - OFFSET_POTENTIOMETER, 0, 3600, 0));
					hysteresisPotentiometerSetting.set (filterPotentiometerSetting.value);
					settingTimerEndTune = hysteresisPotentiometerSetting.value;
					
					if (settingTimerEndTune != settingTunePrevious)
					{
						settingTunePrevious = settingTimerEndTune;
						soundTune = true;
					}
				}
				else if (buttonSelect.bistable == false)
				{
					stateSettingTune = 0;
				}
			}
			else if (select.value == 2)
			{
				if (buttonSelect.bistable == true && stateSettingTune == 0)
				{
					stateSettingTune = 1;
					filterPotentiometerSetting.reset();
					
					settingTunePrevious = settingTimerTriggerTune;
					
					soundSwitch3 = true;
				}
				else if (buttonSelect.bistable == true && stateSettingTune == 1)
				{
					filterPotentiometerSetting.set (Math::curve (settingMinThrottle + OFFSET_POTENTIOMETER, filterPotentiometerThrottle, settingMaxThrottle - OFFSET_POTENTIOMETER, 0, 1023, 0));
					hysteresisPotentiometerSetting.set (filterPotentiometerSetting.value);
					settingTimerTriggerTune = hysteresisPotentiometerSetting.value;
					
					if (settingTimerTriggerTune != settingTunePrevious)
					{
						settingTunePrevious = settingTimerTriggerTune;
						soundTune = true;
					}
				}
				else if (buttonSelect.bistable == false)
				{
					stateSettingTune = 0;
				}
			}
			else if (select.value == 3)
			{
				if (buttonSelect.monostable == true)
				{
					if (settingInvertThrottleTune == false)
					{
						settingInvertThrottleTune = true;
					}
					else
					{
						settingInvertThrottleTune = false;
					}
					
					soundSwitch3 = true;
				}
			}
			else if (select.value == 4)
			{
				if (buttonSelect.monostable == true)
				{
					if (settingInvertPitchTune == false)
					{
						settingInvertPitchTune = true;
					}
					else
					{
						settingInvertPitchTune = false;
					}
					
					soundSwitch3 = true;
				}
			}
			else if (select.value == 5)
			{
				if (buttonSelect.monostable == true)
				{
					if (settingInvertRollTune == false)
					{
						settingInvertRollTune = true;
					}
					else
					{
						settingInvertRollTune = false;
					}
					
					soundSwitch3 = true;
				}
			}
			else if (select.value == 6)
			{
				if (buttonSelect.monostable == true)
				{
					if (settingInvertYawTune == false)
					{
						settingInvertYawTune = true;
					}
					else
					{
						settingInvertYawTune = false;
					}
					
					soundSwitch3 = true;
				}
			}
			else if (select.value == 7)
			{
				if (buttonSelect.bistable == true && stateSettingTune == 0)
				{
					stateSettingTune = 1;
					filterPotentiometerSetting.reset();
					
					settingTunePrevious = settingCurveThrottleTune;
					
					soundSwitch3 = true;
				}
				else if (buttonSelect.bistable == true && stateSettingTune == 1)
				{
					filterPotentiometerSetting.set (Math::curve (settingMinAuxiliaryD + OFFSET_POTENTIOMETER, filterPotentiometerAuxiliaryD, settingMaxAuxiliaryD - OFFSET_POTENTIOMETER, 0, 100, 0));
					hysteresisPotentiometerSetting.set (filterPotentiometerSetting.value);
					settingCurveThrottleTune = hysteresisPotentiometerSetting.value;
					
					if (settingCurveThrottleTune != settingTunePrevious)
					{
						settingTunePrevious = settingCurveThrottleTune;
						soundTune = true;
					}
				}
				else if (buttonSelect.bistable == false)
				{
					stateSettingTune = 0;
				}
			}
			else if (select.value == 8)
			{
				if (buttonSelect.bistable == true && stateSettingTune == 0)
				{
					stateSettingTune = 1;
					filterPotentiometerSetting.reset();
					
					settingTunePrevious = settingCurvePitchTune;
					
					soundSwitch3 = true;
				}
				else if (buttonSelect.bistable == true && stateSettingTune == 1)
				{
					filterPotentiometerSetting.set (Math::curve (settingMinAuxiliaryD + OFFSET_POTENTIOMETER, filterPotentiometerAuxiliaryD, settingMaxAuxiliaryD - OFFSET_POTENTIOMETER, 0, 100, 0));
					hysteresisPotentiometerSetting.set (filterPotentiometerSetting.value);
					settingCurvePitchTune = hysteresisPotentiometerSetting.value;
					
					if (settingCurvePitchTune != settingTunePrevious)
					{
						settingTunePrevious = settingCurvePitchTune;
						soundTune = true;
					}
				}
				else if (buttonSelect.bistable == false)
				{
					stateSettingTune = 0;
				}
			}
			else if (select.value == 9)
			{
				if (buttonSelect.bistable == true && stateSettingTune == 0)
				{
					stateSettingTune = 1;
					filterPotentiometerSetting.reset();
					
					settingTunePrevious = settingCurveRollTune;
					
					soundSwitch3 = true;
				}
				else if (buttonSelect.bistable == true && stateSettingTune == 1)
				{
					filterPotentiometerSetting.set (Math::curve (settingMinAuxiliaryD + OFFSET_POTENTIOMETER, filterPotentiometerAuxiliaryD, settingMaxAuxiliaryD - OFFSET_POTENTIOMETER, 0, 100, 0));
					hysteresisPotentiometerSetting.set (filterPotentiometerSetting.value);
					settingCurveRollTune = hysteresisPotentiometerSetting.value;
					
					if (settingCurveRollTune != settingTunePrevious)
					{
						settingTunePrevious = settingCurveRollTune;
						soundTune = true;
					}
				}
				else if (buttonSelect.bistable == false)
				{
					stateSettingTune = 0;
				}
			}
			else if (select.value == 10)
			{
				if (buttonSelect.bistable == true && stateSettingTune == 0)
				{
					stateSettingTune = 1;
					filterPotentiometerSetting.reset();
					
					settingTunePrevious = settingCurveYawTune;
					
					soundSwitch3 = true;
				}
				else if (buttonSelect.bistable == true && stateSettingTune == 1)
				{
					filterPotentiometerSetting.set (Math::curve (settingMinAuxiliaryD + OFFSET_POTENTIOMETER, filterPotentiometerAuxiliaryD, settingMaxAuxiliaryD - OFFSET_POTENTIOMETER, 0, 100, 0));
					hysteresisPotentiometerSetting.set (filterPotentiometerSetting.value);
					settingCurveYawTune = hysteresisPotentiometerSetting.value;
					
					if (settingCurveYawTune != settingTunePrevious)
					{
						settingTunePrevious = settingCurveYawTune;
						soundTune = true;
					}
				}
				else if (buttonSelect.bistable == false)
				{
					stateSettingTune = 0;
				}
			}
			else if (select.value >= 11 && select.value < countSettingOption + 11)
			{
				if (buttonSelect.bistable == true && stateSettingTune == 0)
				{
					stateSettingTune = 1;
					filterPotentiometerSetting.reset();
					
					settingTunePrevious = settingOptionTune [mapSettingOption [select.value - 11]];
					
					soundSwitch3 = true;
				}
				else if (buttonSelect.bistable == true && stateSettingTune == 1)
				{
					filterPotentiometerSetting.set (Math::curve (settingMinAuxiliaryD + OFFSET_POTENTIOMETER, filterPotentiometerAuxiliaryD, settingMaxAuxiliaryD - OFFSET_POTENTIOMETER, settingOptionMin [mapSettingOption [select.value - 11]], settingOptionMax [mapSettingOption [select.value - 11]], 0));
					hysteresisPotentiometerSetting.set (filterPotentiometerSetting.value);
					settingOptionTune [mapSettingOption [select.value - 11]] = hysteresisPotentiometerSetting.value;
					
					if (settingOptionTune [mapSettingOption [select.value - 11]] != settingTunePrevious)
					{
						settingTunePrevious = settingOptionTune [mapSettingOption [select.value - 11]];
						soundTune = true;
					}
				}
				else if (buttonSelect.bistable == false)
				{
					stateSettingTune = 0;
				}
			}
			else if (select.value == countSettingOption + 11)
			{
				if (buttonSelect.monostable == true)
				{
					menuSetting = false;
					
					stateLocked = 2;
					
					if (downloadedSetting == true && locked == false)
					{
						delayTrimThrottle.duration (1000);
						delayTrimThrottle.reset();
						delayTrimPitch.duration (1000);
						delayTrimPitch.reset();
						delayTrimRoll.duration (1000);
						delayTrimRoll.reset();
						delayTrimYaw.duration (1000);
						delayTrimYaw.reset();
					}
					
					if (lowVoltageBatteryControl == true)
					{
						delayDisplayLowVoltageBatteryControl.reset();
						displayVoltageBatteryControl = 1;
					}
					
					if (lowVoltageBatteryModel == true)
					{
						delayDisplayLowVoltageBatteryModel.reset();
						displayVoltageBatteryModel = 1;
					}
					
					if (timerEnded == true)
					{
						delayDisplayTimerEnded.reset();
						displayTimerEnded = 1;
					}
					
					select.set (Math::curve (0, potentiometerSelect.value, 1023, 0, 9, 0));
					selectPrevious = select.value;
					
					soundNull = true;
				}
			}
			else
			{
				if (buttonSelect.monostable == true)
				{
					exit = false;
					binding = false;
					
					if (switchPowerState.bistable == false && locked == false)
					{
						resetShutdown = true;
					}
					
					delayBinding.reset();
					delayDotBinding.reset();
					dotBinding = select.value % 4;
					
					soundSwitch3 = true;
					
					while (updated == true && exit == false)
					{
						timeSound.state();
						timer.state();
						
						delayBinding.state();
						
						switchPowerState.read();
						buttonSelect.read();
						switchCut.read();
						switchAuxiliaryA1.read();
						switchAuxiliaryA2.read();
						switchAuxiliaryB1.read();
						switchAuxiliaryB2.read();
						switchAuxiliaryC1.read();
						switchAuxiliaryC2.read();
						switchTrimThrottle1.read();
						switchTrimThrottle2.read();
						switchTrimPitch1.read();
						switchTrimPitch2.read();
						switchTrimRoll1.read();
						switchTrimRoll2.read();
						switchTrimYaw1.read();
						switchTrimYaw2.read();
						voltageBatteryControl.read();
						
						filterPotentiometerThrottle = 0;
						filterPotentiometerPitch = 0;
						filterPotentiometerRoll = 0;
						filterPotentiometerYaw = 0;
						filterPotentiometerAuxiliaryD = 0;
						
						for (iterationFilterPotentiometer = 0; iterationFilterPotentiometer < COUNT_FILTER_POTENTIOMETER; iterationFilterPotentiometer++)
						{
							potentiometerThrottle.read();
							potentiometerPitch.read();
							potentiometerRoll.read();
							potentiometerYaw.read();
							potentiometerAuxiliaryD.read();
							
							filterPotentiometerThrottle += potentiometerThrottle.value;
							filterPotentiometerPitch += potentiometerPitch.value;
							filterPotentiometerRoll += potentiometerRoll.value;
							filterPotentiometerYaw += potentiometerYaw.value;
							filterPotentiometerAuxiliaryD += potentiometerAuxiliaryD.value;
						}
						
						filterPotentiometerThrottle = filterPotentiometerThrottle / (float)(COUNT_FILTER_POTENTIOMETER);
						filterPotentiometerPitch = filterPotentiometerPitch / (float)(COUNT_FILTER_POTENTIOMETER);
						filterPotentiometerRoll = filterPotentiometerRoll / (float)(COUNT_FILTER_POTENTIOMETER);
						filterPotentiometerYaw = filterPotentiometerYaw / (float)(COUNT_FILTER_POTENTIOMETER);
						filterPotentiometerAuxiliaryD = filterPotentiometerAuxiliaryD / (float)(COUNT_FILTER_POTENTIOMETER);
						
						channelVoltageBatteryModelTelemetryWatchDogUpdated.receive();
						
						if (switchPowerState.bistable == false)
						{
							if (resetShutdown == false)
							{
								if (brightness == 16)
								{
									SpiNrf24l01p::stop();
									
									SoundWrite::add (1024, 100);
									SoundWrite::add (512, 100);
									SoundWrite::add (0, 50);
									SoundWrite::add (512, 100);
									SoundWrite::add (256, 100);
									SoundWrite::add (0, 50);
									SoundWrite::add (256, 100);
									SoundWrite::add (128, 100);
									SoundWrite::play (0, 0);
									
									for (iterationAnimation = 0; iterationAnimation < 4; iterationAnimation++)
									{
										display.clearDevice();
										display.draw (0b00000110, 1 + iterationAnimation);
										display.draw (0b00110000, 8 - iterationAnimation);
										Timer::pause (100);
										display.draw (0b00110000, 1 + iterationAnimation);
										display.draw (0b00000110, 8 - iterationAnimation);
										Timer::pause (100);
									}
									
									display.clearDevice();
									
									switchPowerHold.off();
									
									Timer::pause (1000);
									
									display.brightness (1);
									display.word ("turn off");
									
									for (iterationAnimation = 2; iterationAnimation < 16; iterationAnimation++)
									{
										Timer::pause (30);
										display.brightness (iterationAnimation);
									}
									
									while (true)
									{
									}
								}
								else
								{
									resetShutdown = true;
									soundNull = true;
								}
							}
						}
						else
						{
							resetShutdown = false;
						}
						
						if (delayBinding.update == true)
						{
							binding = true;
						}
						
						if (buttonSelect.monostable == true)
						{
							if (binding == true)
							{
								exit = true;
							}
							
							soundNull = true;
						}
						
						if (settingTrimThrottleTune != 255)
						{
							if (settingInvertThrottle == false)
							{
								throttle = Math::round (Math::wurve (settingMinThrottle + OFFSET_POTENTIOMETER, filterPotentiometerThrottle, settingMaxThrottle - OFFSET_POTENTIOMETER, 0, ((float)(settingTrimThrottleTune) * 4.0) + 3.5, 1023, (float)(settingCurveThrottle) / 10.0, (float)(settingCurveThrottle) / 10.0));
							}
							else
							{
								throttle = Math::round (Math::wurve (settingMinThrottle + OFFSET_POTENTIOMETER, filterPotentiometerThrottle, settingMaxThrottle - OFFSET_POTENTIOMETER, 1023, ((float)(settingTrimThrottleTune) * 4.0) + 3.5, 0, (float)(settingCurveThrottle) / 10.0, (float)(settingCurveThrottle) / 10.0));
							}
						}
						else
						{
							if (settingInvertThrottle == false)
							{
								throttle = Math::round (Math::wurve (settingMinThrottle + OFFSET_POTENTIOMETER, filterPotentiometerThrottle, settingMaxThrottle - OFFSET_POTENTIOMETER, 0, 511.5, 1023, (float)(settingCurveThrottle) / 10.0, (float)(settingCurveThrottle) / 10.0));
							}
							else
							{
								throttle = Math::round (Math::wurve (settingMinThrottle + OFFSET_POTENTIOMETER, filterPotentiometerThrottle, settingMaxThrottle - OFFSET_POTENTIOMETER, 1023, 511.5, 0, (float)(settingCurveThrottle) / 10.0, (float)(settingCurveThrottle) / 10.0));
							}
						}
						
						if (settingTrimPitchTune != 255)
						{
							if (settingInvertPitch == false)
							{
								pitch = Math::round (Math::wurve (settingMinPitch + OFFSET_POTENTIOMETER, filterPotentiometerPitch, settingMaxPitch - OFFSET_POTENTIOMETER, 0, ((float)(settingTrimPitchTune) * 4.0) + 3.5, 1023, (float)(settingCurvePitch) / 10.0, (float)(settingCurvePitch) / 10.0));
							}
							else
							{
								pitch = Math::round (Math::wurve (settingMinPitch + OFFSET_POTENTIOMETER, filterPotentiometerPitch, settingMaxPitch - OFFSET_POTENTIOMETER, 1023, ((float)(settingTrimPitchTune) * 4.0) + 3.5, 0, (float)(settingCurvePitch) / 10.0, (float)(settingCurvePitch) / 10.0));
							}
						}
						else
						{
							if (settingInvertPitch == false)
							{
								pitch = Math::round (Math::wurve (settingMinPitch + OFFSET_POTENTIOMETER, filterPotentiometerPitch, settingMaxPitch - OFFSET_POTENTIOMETER, 0, 511.5, 1023, (float)(settingCurvePitch) / 10.0, (float)(settingCurvePitch) / 10.0));
							}
							else
							{
								pitch = Math::round (Math::wurve (settingMinPitch + OFFSET_POTENTIOMETER, filterPotentiometerPitch, settingMaxPitch - OFFSET_POTENTIOMETER, 1023, 511.5, 0, (float)(settingCurvePitch) / 10.0, (float)(settingCurvePitch) / 10.0));
							}
						}
						
						if (settingTrimRollTune != 255)
						{
							if (settingInvertRoll == false)
							{
								roll = Math::round (Math::wurve (settingMinRoll + OFFSET_POTENTIOMETER, filterPotentiometerRoll, settingMaxRoll - OFFSET_POTENTIOMETER, 0, ((float)(settingTrimRollTune) * 4.0) + 3.5, 1023, (float)(settingCurveRoll) / 10.0, (float)(settingCurveRoll) / 10.0));
							}
							else
							{
								roll = Math::round (Math::wurve (settingMinRoll + OFFSET_POTENTIOMETER, filterPotentiometerRoll, settingMaxRoll - OFFSET_POTENTIOMETER, 1023, ((float)(settingTrimRollTune) * 4.0) + 3.5, 0, (float)(settingCurveRoll) / 10.0, (float)(settingCurveRoll) / 10.0));
							}
						}
						else
						{
							if (settingInvertRoll == false)
							{
								roll = Math::round (Math::wurve (settingMinRoll + OFFSET_POTENTIOMETER, filterPotentiometerRoll, settingMaxRoll - OFFSET_POTENTIOMETER, 0, 511.5, 1023, (float)(settingCurveRoll) / 10.0, (float)(settingCurveRoll) / 10.0));
							}
							else
							{
								roll = Math::round (Math::wurve (settingMinRoll + OFFSET_POTENTIOMETER, filterPotentiometerRoll, settingMaxRoll - OFFSET_POTENTIOMETER, 1023, 511.5, 0, (float)(settingCurveRoll) / 10.0, (float)(settingCurveRoll) / 10.0));
							}
						}
						
						if (settingTrimYawTune != 255)
						{
							if (settingInvertYaw == false)
							{
								yaw = Math::round (Math::wurve (settingMinYaw + OFFSET_POTENTIOMETER, filterPotentiometerYaw, settingMaxYaw - OFFSET_POTENTIOMETER, 0, ((float)(settingTrimYawTune) * 4.0) + 3.5, 1023, (float)(settingCurveYaw) / 10.0, (float)(settingCurveYaw) / 10.0));
							}
							else
							{
								yaw = Math::round (Math::wurve (settingMinYaw + OFFSET_POTENTIOMETER, filterPotentiometerYaw, settingMaxYaw - OFFSET_POTENTIOMETER, 1023, ((float)(settingTrimYawTune) * 4.0) + 3.5, 0, (float)(settingCurveYaw) / 10.0, (float)(settingCurveYaw) / 10.0));
							}
						}
						else
						{
							if (settingInvertYaw == false)
							{
								yaw = Math::round (Math::wurve (settingMinYaw + OFFSET_POTENTIOMETER, filterPotentiometerYaw, settingMaxYaw - OFFSET_POTENTIOMETER, 0, 511.5, 1023, (float)(settingCurveYaw) / 10.0, (float)(settingCurveYaw) / 10.0));
							}
							else
							{
								yaw = Math::round (Math::wurve (settingMinYaw + OFFSET_POTENTIOMETER, filterPotentiometerYaw, settingMaxYaw - OFFSET_POTENTIOMETER, 1023, 511.5, 0, (float)(settingCurveYaw) / 10.0, (float)(settingCurveYaw) / 10.0));
							}
						}
						
						cut = switchCut.bistable;
						
						if (cut != cutPrevious)
						{
							cutPrevious = cut;
							
							if (cut == false)
							{
								soundSwitch1 = true;
							}
							else
							{
								soundSwitch2 = true;
							}
						}
						
						if (switchAuxiliaryA1.bistable == true)
						{
							auxiliaryA = 0;
						}
						else if (switchAuxiliaryA2.bistable == true)
						{
							auxiliaryA = 2;
						}
						else
						{
							auxiliaryA = 1;
						}
						
						if (auxiliaryA != auxiliaryAPrevious)
						{
							auxiliaryAPrevious = auxiliaryA;
							
							if (auxiliaryA == 0)
							{
								soundSwitch1 = true;
							}
							else if (auxiliaryA == 1)
							{
								soundSwitch2 = true;
							}
							else
							{
								soundSwitch3 = true;
							}
						}
						
						if (switchAuxiliaryB1.bistable == true)
						{
							auxiliaryB = 0;
						}
						else if (switchAuxiliaryB2.bistable == true)
						{
							auxiliaryB = 2;
						}
						else
						{
							auxiliaryB = 1;
						}
						
						if (auxiliaryB != auxiliaryBPrevious)
						{
							auxiliaryBPrevious = auxiliaryB;
							
							if (auxiliaryB == 0)
							{
								soundSwitch1 = true;
							}
							else if (auxiliaryB == 1)
							{
								soundSwitch2 = true;
							}
							else
							{
								soundSwitch3 = true;
							}
						}
						
						if (switchAuxiliaryC1.bistable == true)
						{
							auxiliaryC = 0;
						}
						else if (switchAuxiliaryC2.bistable == true)
						{
							auxiliaryC = 2;
						}
						else
						{
							auxiliaryC = 1;
						}
						
						if (auxiliaryC != auxiliaryCPrevious)
						{
							auxiliaryCPrevious = auxiliaryC;
							
							if (auxiliaryC == 0)
							{
								soundSwitch1 = true;
							}
							else if (auxiliaryC == 1)
							{
								soundSwitch2 = true;
							}
							else
							{
								soundSwitch3 = true;
							}
						}
						
						auxiliaryD = Math::round (Math::curve (settingMinAuxiliaryD + OFFSET_POTENTIOMETER, filterPotentiometerAuxiliaryD, settingMaxAuxiliaryD - OFFSET_POTENTIOMETER, 0, 1023, 0));
						
						if (failSafe < 31)
						{
							failSafe++;
						}
						else
						{
							failSafe = 0;
						}
						
						if (flipFlopTransmit == false)
						{
							channelThrottleRollAuxiliaryCAuxiliaryD.transmit ((signed long)(auxiliaryD) << 22 | (signed long)(auxiliaryC) << 20 | (signed long)(roll) << 10 | (signed long)(throttle));
							flipFlopTransmit = true;
						}
						else
						{
							channelPitchYawCutAuxiliaryAAuxiliaryBFailSafeUpdate.transmit ((signed long)(update) << 30 | (signed long)(failSafe) << 25 | (signed long)(auxiliaryB) << 23 | (signed long)(auxiliaryA) << 21 | (signed long)(cut) << 20 | (signed long)(yaw) << 10 | (signed long)(pitch));
							flipFlopTransmit = false;
						}
						
						filterVoltageBatteryModel.set (Math::curve (0, channelVoltageBatteryModelTelemetryWatchDogUpdated.data & 0b00000000000000000000001111111111, 1023, 0, 30, 0));
						hysteresisVoltageBatteryModel.set (filterVoltageBatteryModel.value * 10.0);
						filterTelemetry.set ((float)((channelVoltageBatteryModelTelemetryWatchDogUpdated.data & 0b00000011111111111111110000000000) >> 10) / 10.0);
						hysteresisTelemetry.set (filterTelemetry.value * 10.0);
						
						updated = (channelVoltageBatteryModelTelemetryWatchDogUpdated.data & 0b10000000000000000000000000000000) >> 31;
						
						if (switchTrimThrottle1.monostable == true)
						{
							soundNull = true;
						}
						else if (switchTrimThrottle2.monostable == true)
						{
							soundNull = true;
						}
						else if (switchTrimThrottle1.bistable == true)
						{
							delayTrimThrottle.state();
							
							if (delayTrimThrottle.update == true)
							{
								soundNull = true;
								delayTrimThrottle.duration (50);
							}
						}
						else if (switchTrimThrottle2.bistable == true)
						{
							delayTrimThrottle.state();
							
							if (delayTrimThrottle.update == true)
							{
								soundNull = true;
								delayTrimThrottle.duration (50);
							}
						}
						else
						{
							delayTrimThrottle.duration (1000);
							delayTrimThrottle.reset();
						}
						
						if (switchTrimPitch1.monostable == true)
						{
							soundNull = true;
						}
						else if (switchTrimPitch2.monostable == true)
						{
							soundNull = true;
						}
						else if (switchTrimPitch1.bistable == true)
						{
							delayTrimPitch.state();
							
							if (delayTrimPitch.update == true)
							{
								soundNull = true;
								delayTrimPitch.duration (50);
							}
						}
						else if (switchTrimPitch2.bistable == true)
						{
							delayTrimPitch.state();
							
							if (delayTrimPitch.update == true)
							{
								soundNull = true;
								delayTrimPitch.duration (50);
							}
						}
						else
						{
							delayTrimPitch.duration (1000);
							delayTrimPitch.reset();
						}
						
						if (switchTrimRoll1.monostable == true)
						{
							soundNull = true;
						}
						else if (switchTrimRoll2.monostable == true)
						{
							soundNull = true;
						}
						else if (switchTrimRoll1.bistable == true)
						{
							delayTrimRoll.state();
							
							if (delayTrimRoll.update == true)
							{
								soundNull = true;
								delayTrimRoll.duration (50);
							}
						}
						else if (switchTrimRoll2.bistable == true)
						{
							delayTrimRoll.state();
							
							if (delayTrimRoll.update == true)
							{
								soundNull = true;
								delayTrimRoll.duration (50);
							}
						}
						else
						{
							delayTrimRoll.duration (1000);
							delayTrimRoll.reset();
						}
						
						if (switchTrimYaw1.monostable == true)
						{
							soundNull = true;
						}
						else if (switchTrimYaw2.monostable == true)
						{
							soundNull = true;
						}
						else if (switchTrimYaw1.bistable == true)
						{
							delayTrimYaw.state();
							
							if (delayTrimYaw.update == true)
							{
								soundNull = true;
								delayTrimYaw.duration (50);
							}
						}
						else if (switchTrimYaw2.bistable == true)
						{
							delayTrimYaw.state();
							
							if (delayTrimYaw.update == true)
							{
								soundNull = true;
								delayTrimYaw.duration (50);
							}
						}
						else
						{
							delayTrimYaw.duration (1000);
							delayTrimYaw.reset();
						}
						
						filterVoltageBatteryControl.set (Math::curve (0, voltageBatteryControl.value, 1023, 0, 30, 0));
						hysteresisVoltageBatteryControl.set (filterVoltageBatteryControl.value * 10.0);
						
						if (lowVoltageBatteryControl == false && (float)(hysteresisVoltageBatteryControl.value) / 10.0 < SETUP_LOW_VOLTAGE_BATTERY_CONTROL)
						{
							lowVoltageBatteryControl = true;
							soundLowVoltageBatteryControl = true;
						}
						
						if (settingVoltageBatteryModelLow != 0)
						{
							if (lowVoltageBatteryModel == false && (float)(hysteresisVoltageBatteryModel.value) / 10.0 < (float)(settingVoltageBatteryModelLow) / 10.0)
							{
								lowVoltageBatteryModel = true;
								
								soundLowVoltageBatteryModel = 1;
								soundTimerEnded = 0;
							}
						}
						else if (lowVoltageBatteryModel == true)
						{
							lowVoltageBatteryModel = false;
							
							displayVoltageBatteryModel = 0;
							soundLowVoltageBatteryModel = 0;
						}
						
						if (settingTimerEnd != 0)
						{
							if (timerStarted == false && timerEnded == false && throttleRaw >= settingTimerTrigger && settingTimerTrigger != 0)
							{
								timer.start (0);
								timerStarted = true;
								
								soundTimerStart = true;
							}
							else if (timerStarted == false && timerEnded == false && cut == false && settingTimerTrigger == 0)
							{
								timer.start (0);
								timerStarted = true;
								
								soundTimerStart = true;
							}
							else if (timerStarted == true && ((settingTimerEnd >= 5 && timer.s >= (unsigned long long)(settingTimerEnd) - 5ull) || settingTimerEnd < 5))
							{
								timerStarted = false;
								timerEnded = true;
								
								if (lowVoltageBatteryModel == false || (lowVoltageBatteryModel == true && soundLowVoltageBatteryModel == 7))
								{
									if (settingTimerEnd >= 5 && timer.s >= (unsigned long long)(settingTimerEnd) - 5ull)
									{
										soundTimerEnded = 1;
									}
									else
									{
										soundTimerEnded = 6 - settingTimerEnd;
									}
								}
							}
						}
						else if (timerStarted == true || timerEnded == true)
						{
							timer.stop();
							
							timerStarted = false;
							timerEnded = false;
							
							displayTimerEnded = 0;
							soundTimerEnded = 0;
						}
						
						if (lowVoltageBatteryControl == true || lowVoltageBatteryModel == true || timerEnded == true)
						{
							delaySoundAlarm.state();
							
							if (delaySoundAlarm.update == true)
							{
								soundAlarm = true;
							}
						}
						else
						{
							delaySoundAlarm.reset();
						}
						
						if (binding == true)
						{
							delayDotBinding.state();
							
							if (delayDotBinding.update == true)
							{
								for (iterationAnimation = 0; iterationAnimation < 8; iterationAnimation++)
								{
									if (iterationAnimation == dotBinding)
									{
										display.draw (Tool::characterToByte (&WORD_BINDING [iterationAnimation]) | 0b10000000, iterationAnimation + 1);
									}
									else
									{
										display.draw (Tool::characterToByte (&WORD_BINDING [iterationAnimation]), iterationAnimation + 1);
									}
								}
								
								if (dotBinding < 7)
								{
									dotBinding++;
								}
								else
								{
									dotBinding = 0;
								}
							}
						}
						
						if (soundNull == true && inhibitSound == false)
						{
							SoundWrite::play (128, 200);
							timeSoundPrevious = timeSound.ms + 200ull + (unsigned long long)(TIME_SPACE_SOUND);
						}
						else if (soundTimerStart == true)
						{
							SoundWrite::add (256, 60);
							SoundWrite::add (0, 40);
							SoundWrite::add (512, 60);
							SoundWrite::add (0, 40);
							SoundWrite::add (1024, 60);
							SoundWrite::play (0, 0);
							
							timeSoundPrevious = timeSound.ms + 260ull + (unsigned long long)(TIME_SPACE_SOUND);
						}
						else if (soundSwitch1 == true && inhibitSound == false)
						{
							SoundWrite::play (1024, 20);
							timeSoundPrevious = timeSound.ms + 20ull + (unsigned long long)(TIME_SPACE_SOUND);
						}
						else if (soundSwitch2 == true && inhibitSound == false)
						{
							SoundWrite::add (1024, 20);
							SoundWrite::add (0, 40);
							SoundWrite::add (1024, 20);
							SoundWrite::play (0, 0);
							
							timeSoundPrevious = timeSound.ms + 80ull + (unsigned long long)(TIME_SPACE_SOUND);
						}
						else if (soundSwitch3 == true && inhibitSound == false)
						{
							SoundWrite::add (1024, 20);
							SoundWrite::add (0, 40);
							SoundWrite::add (1024, 20);
							SoundWrite::add (0, 40);
							SoundWrite::add (1024, 20);
							SoundWrite::play (0, 0);
							
							timeSoundPrevious = timeSound.ms + 140ull + (unsigned long long)(TIME_SPACE_SOUND);
						}
						else if (soundLowVoltageBatteryModel >= 1 && soundLowVoltageBatteryModel <= 6)
						{
							delaySoundLowVoltageBatteryModel.state();
							
							if (delaySoundLowVoltageBatteryModel.update == true)
							{
								if (soundLowVoltageBatteryModel != 6)
								{
									SoundWrite::add (2048, 100);
									SoundWrite::add (0, 50);
									SoundWrite::add (2048, 100);
									SoundWrite::play (0, 0);
									
									timeSoundPrevious = timeSound.ms + 250ull + (unsigned long long)(TIME_SPACE_SOUND);
								}
								else
								{
									SoundWrite::play (2048, 2000);
									timeSoundPrevious = timeSound.ms + 2000ull + (unsigned long long)(TIME_SPACE_SOUND);
								}
								
								soundLowVoltageBatteryModel++;
							}
						}
						else if (soundTimerEnded >= 1 && soundTimerEnded <= 6)
						{
							delaySoundTimerEnded.state();
							
							if (delaySoundTimerEnded.update == true)
							{
								if (soundTimerEnded == 1)
								{
									SoundWrite::add (2048, 20);
									SoundWrite::add (0, 50);
									SoundWrite::add (2048, 20);
									SoundWrite::add (0, 50);
									SoundWrite::add (2048, 20);
									SoundWrite::add (0, 50);
									SoundWrite::add (2048, 20);
									SoundWrite::add (0, 50);
									SoundWrite::add (2048, 20);
									SoundWrite::play (0, 0);
									
									timeSoundPrevious = timeSound.ms + 300ull + (unsigned long long)(TIME_SPACE_SOUND);
								}
								else if (soundTimerEnded == 2)
								{
									SoundWrite::add (2048, 20);
									SoundWrite::add (0, 50);
									SoundWrite::add (2048, 20);
									SoundWrite::add (0, 50);
									SoundWrite::add (2048, 20);
									SoundWrite::add (0, 50);
									SoundWrite::add (2048, 20);
									SoundWrite::play (0, 0);
									
									timeSoundPrevious = timeSound.ms + 230ull + (unsigned long long)(TIME_SPACE_SOUND);
								}
								else if (soundTimerEnded == 3)
								{
									SoundWrite::add (2048, 20);
									SoundWrite::add (0, 50);
									SoundWrite::add (2048, 20);
									SoundWrite::add (0, 50);
									SoundWrite::add (2048, 20);
									SoundWrite::play (0, 0);
									
									timeSoundPrevious = timeSound.ms + 160ull + (unsigned long long)(TIME_SPACE_SOUND);
								}
								else if (soundTimerEnded == 4)
								{
									SoundWrite::add (2048, 20);
									SoundWrite::add (0, 50);
									SoundWrite::add (2048, 20);
									SoundWrite::play (0, 0);
									
									timeSoundPrevious = timeSound.ms + 90ull + (unsigned long long)(TIME_SPACE_SOUND);
								}
								else if (soundTimerEnded == 5)
								{
									SoundWrite::play (2048, 20);
									timeSoundPrevious = timeSound.ms + 20ull + (unsigned long long)(TIME_SPACE_SOUND);
								}
								else
								{
									SoundWrite::play (2048, 2000);
									timeSoundPrevious = timeSound.ms + 2000ull + (unsigned long long)(TIME_SPACE_SOUND);
								}
								
								soundTimerEnded++;
							}
						}
						else if (soundAlarm == true)
						{
							SoundWrite::play (2048, 10);
							timeSoundPrevious = timeSound.ms + 10ull + (unsigned long long)(TIME_SPACE_SOUND);
						}
						
						if (soundLowVoltageBatteryControl == true && timeSound.ms > timeSoundPrevious)
						{
							delaySoundLowVoltageBatteryControl.state();
							
							if (delaySoundLowVoltageBatteryControl.update == true)
							{
								SoundWrite::play (2048, 100);
							}
						}
						
						soundNull = false;
						soundTimerStart = false;
						soundAlarm = false;
						soundSwitch1 = false;
						soundSwitch2 = false;
						soundSwitch3 = false;
						
						inhibitSound = false;
					}
					
					dataSettingBatteryTimer = (signed long)(settingTimerTriggerTune) << 22 | (signed long)(settingTimerEndTune) << 10 | (signed long)(settingVoltageBatteryModelLowTune);
					dataSettingTrim = (signed long)(settingTrimYawTune) << 24 | (signed long)(settingTrimRollTune) << 16 | (signed long)(settingTrimPitchTune) << 8 | (signed long)(settingTrimThrottleTune);
					dataSettingStick = (signed long)(settingCurveYawTune) << 25 | (signed long)(settingCurveRollTune) << 18 | (signed long)(settingCurvePitchTune) << 11 | (signed long)(settingCurveThrottleTune) << 4 | (signed long)(settingInvertYawTune) << 3 | (signed long)(settingInvertRollTune) << 2 | (signed long)(settingInvertPitchTune) << 1 | (signed long)(settingInvertThrottleTune);
					dataSettingOption1 = (signed long)(settingOptionDecimal [0]) << 31 | (signed long)(settingOptionCenter [0]) << 30 | (signed long)(settingOptionMax [0]) << 20 | (signed long)(settingOptionMin [0]) << 10 | (signed long)(settingOptionTune [0]);
					dataSettingOption2 = (signed long)(settingOptionDecimal [1]) << 31 | (signed long)(settingOptionCenter [1]) << 30 | (signed long)(settingOptionMax [1]) << 20 | (signed long)(settingOptionMin [1]) << 10 | (signed long)(settingOptionTune [1]);
					dataSettingOption3 = (signed long)(settingOptionDecimal [2]) << 31 | (signed long)(settingOptionCenter [2]) << 30 | (signed long)(settingOptionMax [2]) << 20 | (signed long)(settingOptionMin [2]) << 10 | (signed long)(settingOptionTune [2]);
					dataSettingOption4 = (signed long)(settingOptionDecimal [3]) << 31 | (signed long)(settingOptionCenter [3]) << 30 | (signed long)(settingOptionMax [3]) << 20 | (signed long)(settingOptionMin [3]) << 10 | (signed long)(settingOptionTune [3]);
					dataSettingOption5 = (signed long)(settingOptionDecimal [4]) << 31 | (signed long)(settingOptionCenter [4]) << 30 | (signed long)(settingOptionMax [4]) << 20 | (signed long)(settingOptionMin [4]) << 10 | (signed long)(settingOptionTune [4]);
					dataSettingOption6 = (signed long)(settingOptionDecimal [5]) << 31 | (signed long)(settingOptionCenter [5]) << 30 | (signed long)(settingOptionMax [5]) << 20 | (signed long)(settingOptionMin [5]) << 10 | (signed long)(settingOptionTune [5]);
					dataSettingOption7 = (signed long)(settingOptionDecimal [6]) << 31 | (signed long)(settingOptionCenter [6]) << 30 | (signed long)(settingOptionMax [6]) << 20 | (signed long)(settingOptionMin [6]) << 10 | (signed long)(settingOptionTune [6]);
					dataSettingOption8 = (signed long)(settingOptionDecimal [7]) << 31 | (signed long)(settingOptionCenter [7]) << 30 | (signed long)(settingOptionMax [7]) << 20 | (signed long)(settingOptionMin [7]) << 10 | (signed long)(settingOptionTune [7]);
					dataSettingOption9 = (signed long)(settingOptionDecimal [8]) << 31 | (signed long)(settingOptionCenter [8]) << 30 | (signed long)(settingOptionMax [8]) << 20 | (signed long)(settingOptionMin [8]) << 10 | (signed long)(settingOptionTune [8]);
					dataSettingOption10 = (signed long)(settingOptionDecimal [9]) << 31 | (signed long)(settingOptionCenter [9]) << 30 | (signed long)(settingOptionMax [9]) << 20 | (signed long)(settingOptionMin [9]) << 10 | (signed long)(settingOptionTune [9]);
					dataSettingOption11 = (signed long)(settingOptionDecimal [10]) << 31 | (signed long)(settingOptionCenter [10]) << 30 | (signed long)(settingOptionMax [10]) << 20 | (signed long)(settingOptionMin [10]) << 10 | (signed long)(settingOptionTune [10]);
					dataSettingOption12 = (signed long)(settingOptionDecimal [11]) << 31 | (signed long)(settingOptionCenter [11]) << 30 | (signed long)(settingOptionMax [11]) << 20 | (signed long)(settingOptionMin [11]) << 10 | (signed long)(settingOptionTune [11]);
					dataSettingOption13 = (signed long)(settingOptionDecimal [12]) << 31 | (signed long)(settingOptionCenter [12]) << 30 | (signed long)(settingOptionMax [12]) << 20 | (signed long)(settingOptionMin [12]) << 10 | (signed long)(settingOptionTune [12]);
					dataSettingOption14 = (signed long)(settingOptionDecimal [13]) << 31 | (signed long)(settingOptionCenter [13]) << 30 | (signed long)(settingOptionMax [13]) << 20 | (signed long)(settingOptionMin [13]) << 10 | (signed long)(settingOptionTune [13]);
					dataSettingOption15 = (signed long)(settingOptionDecimal [14]) << 31 | (signed long)(settingOptionCenter [14]) << 30 | (signed long)(settingOptionMax [14]) << 20 | (signed long)(settingOptionMin [14]) << 10 | (signed long)(settingOptionTune [14]);
					dataSettingOption16 = (signed long)(settingOptionDecimal [15]) << 31 | (signed long)(settingOptionCenter [15]) << 30 | (signed long)(settingOptionMax [15]) << 20 | (signed long)(settingOptionMin [15]) << 10 | (signed long)(settingOptionTune [15]);
					
					channelSettingBatteryTimer.reset();
					channelSettingTrim.reset();
					channelSettingStick.reset();
					channelSettingOption1.reset();
					channelSettingOption2.reset();
					channelSettingOption3.reset();
					channelSettingOption4.reset();
					channelSettingOption5.reset();
					channelSettingOption6.reset();
					channelSettingOption7.reset();
					channelSettingOption8.reset();
					channelSettingOption9.reset();
					channelSettingOption10.reset();
					channelSettingOption11.reset();
					channelSettingOption12.reset();
					channelSettingOption13.reset();
					channelSettingOption14.reset();
					channelSettingOption15.reset();
					channelSettingOption16.reset();
					
					update = 1;
					
					while (updated == false && exit == false)
					{
						timeSound.state();
						timer.state();
						
						delayBinding.state();
						
						switchPowerState.read();
						buttonSelect.read();
						switchCut.read();
						switchAuxiliaryA1.read();
						switchAuxiliaryA2.read();
						switchAuxiliaryB1.read();
						switchAuxiliaryB2.read();
						switchAuxiliaryC1.read();
						switchAuxiliaryC2.read();
						switchTrimThrottle1.read();
						switchTrimThrottle2.read();
						switchTrimPitch1.read();
						switchTrimPitch2.read();
						switchTrimRoll1.read();
						switchTrimRoll2.read();
						switchTrimYaw1.read();
						switchTrimYaw2.read();
						voltageBatteryControl.read();
						
						filterPotentiometerThrottle = 0;
						filterPotentiometerPitch = 0;
						filterPotentiometerRoll = 0;
						filterPotentiometerYaw = 0;
						filterPotentiometerAuxiliaryD = 0;
						
						for (iterationFilterPotentiometer = 0; iterationFilterPotentiometer < COUNT_FILTER_POTENTIOMETER; iterationFilterPotentiometer++)
						{
							potentiometerThrottle.read();
							potentiometerPitch.read();
							potentiometerRoll.read();
							potentiometerYaw.read();
							potentiometerAuxiliaryD.read();
							
							filterPotentiometerThrottle += potentiometerThrottle.value;
							filterPotentiometerPitch += potentiometerPitch.value;
							filterPotentiometerRoll += potentiometerRoll.value;
							filterPotentiometerYaw += potentiometerYaw.value;
							filterPotentiometerAuxiliaryD += potentiometerAuxiliaryD.value;
						}
						
						filterPotentiometerThrottle = filterPotentiometerThrottle / (float)(COUNT_FILTER_POTENTIOMETER);
						filterPotentiometerPitch = filterPotentiometerPitch / (float)(COUNT_FILTER_POTENTIOMETER);
						filterPotentiometerRoll = filterPotentiometerRoll / (float)(COUNT_FILTER_POTENTIOMETER);
						filterPotentiometerYaw = filterPotentiometerYaw / (float)(COUNT_FILTER_POTENTIOMETER);
						filterPotentiometerAuxiliaryD = filterPotentiometerAuxiliaryD / (float)(COUNT_FILTER_POTENTIOMETER);
						
						channelVoltageBatteryModelTelemetryWatchDogUpdated.receive();
						
						channelSettingBatteryTimer.receive();
						channelSettingTrim.receive();
						channelSettingStick.receive();
						channelSettingOption1.receive();
						channelSettingOption2.receive();
						channelSettingOption3.receive();
						channelSettingOption4.receive();
						channelSettingOption5.receive();
						channelSettingOption6.receive();
						channelSettingOption7.receive();
						channelSettingOption8.receive();
						channelSettingOption9.receive();
						channelSettingOption10.receive();
						channelSettingOption11.receive();
						channelSettingOption12.receive();
						channelSettingOption13.receive();
						channelSettingOption14.receive();
						channelSettingOption15.receive();
						channelSettingOption16.receive();
						
						channelSettingBatteryTimer.transmit (dataSettingBatteryTimer);
						channelSettingTrim.transmit (dataSettingTrim);
						channelSettingStick.transmit (dataSettingStick);
						channelSettingOption1.transmit (dataSettingOption1);
						channelSettingOption2.transmit (dataSettingOption2);
						channelSettingOption3.transmit (dataSettingOption3);
						channelSettingOption4.transmit (dataSettingOption4);
						channelSettingOption5.transmit (dataSettingOption5);
						channelSettingOption6.transmit (dataSettingOption6);
						channelSettingOption7.transmit (dataSettingOption7);
						channelSettingOption8.transmit (dataSettingOption8);
						channelSettingOption9.transmit (dataSettingOption9);
						channelSettingOption10.transmit (dataSettingOption10);
						channelSettingOption11.transmit (dataSettingOption11);
						channelSettingOption12.transmit (dataSettingOption12);
						channelSettingOption13.transmit (dataSettingOption13);
						channelSettingOption14.transmit (dataSettingOption14);
						channelSettingOption15.transmit (dataSettingOption15);
						channelSettingOption16.transmit (dataSettingOption16);
						
						if (switchPowerState.bistable == false)
						{
							if (resetShutdown == false)
							{
								if (brightness == 16)
								{
									SpiNrf24l01p::stop();
									
									SoundWrite::add (1024, 100);
									SoundWrite::add (512, 100);
									SoundWrite::add (0, 50);
									SoundWrite::add (512, 100);
									SoundWrite::add (256, 100);
									SoundWrite::add (0, 50);
									SoundWrite::add (256, 100);
									SoundWrite::add (128, 100);
									SoundWrite::play (0, 0);
									
									for (iterationAnimation = 0; iterationAnimation < 4; iterationAnimation++)
									{
										display.clearDevice();
										display.draw (0b00000110, 1 + iterationAnimation);
										display.draw (0b00110000, 8 - iterationAnimation);
										Timer::pause (100);
										display.draw (0b00110000, 1 + iterationAnimation);
										display.draw (0b00000110, 8 - iterationAnimation);
										Timer::pause (100);
									}
									
									display.clearDevice();
									
									switchPowerHold.off();
									
									Timer::pause (1000);
									
									display.brightness (1);
									display.word ("turn off");
									
									for (iterationAnimation = 2; iterationAnimation < 16; iterationAnimation++)
									{
										Timer::pause (30);
										display.brightness (iterationAnimation);
									}
									
									while (true)
									{
									}
								}
								else
								{
									resetShutdown = true;
									soundNull = true;
								}
							}
						}
						else
						{
							resetShutdown = false;
						}
						
						if (delayBinding.update == true)
						{
							binding = true;
						}
						
						if (buttonSelect.monostable == true)
						{
							if (binding == true)
							{
								exit = true;
							}
							
							soundNull = true;
						}
						
						if (settingTrimThrottleTune != 255)
						{
							if (settingInvertThrottle == false)
							{
								throttle = Math::round (Math::wurve (settingMinThrottle + OFFSET_POTENTIOMETER, filterPotentiometerThrottle, settingMaxThrottle - OFFSET_POTENTIOMETER, 0, ((float)(settingTrimThrottleTune) * 4.0) + 3.5, 1023, (float)(settingCurveThrottle) / 10.0, (float)(settingCurveThrottle) / 10.0));
							}
							else
							{
								throttle = Math::round (Math::wurve (settingMinThrottle + OFFSET_POTENTIOMETER, filterPotentiometerThrottle, settingMaxThrottle - OFFSET_POTENTIOMETER, 1023, ((float)(settingTrimThrottleTune) * 4.0) + 3.5, 0, (float)(settingCurveThrottle) / 10.0, (float)(settingCurveThrottle) / 10.0));
							}
						}
						else
						{
							if (settingInvertThrottle == false)
							{
								throttle = Math::round (Math::wurve (settingMinThrottle + OFFSET_POTENTIOMETER, filterPotentiometerThrottle, settingMaxThrottle - OFFSET_POTENTIOMETER, 0, 511.5, 1023, (float)(settingCurveThrottle) / 10.0, (float)(settingCurveThrottle) / 10.0));
							}
							else
							{
								throttle = Math::round (Math::wurve (settingMinThrottle + OFFSET_POTENTIOMETER, filterPotentiometerThrottle, settingMaxThrottle - OFFSET_POTENTIOMETER, 1023, 511.5, 0, (float)(settingCurveThrottle) / 10.0, (float)(settingCurveThrottle) / 10.0));
							}
						}
						
						if (settingTrimPitchTune != 255)
						{
							if (settingInvertPitch == false)
							{
								pitch = Math::round (Math::wurve (settingMinPitch + OFFSET_POTENTIOMETER, filterPotentiometerPitch, settingMaxPitch - OFFSET_POTENTIOMETER, 0, ((float)(settingTrimPitchTune) * 4.0) + 3.5, 1023, (float)(settingCurvePitch) / 10.0, (float)(settingCurvePitch) / 10.0));
							}
							else
							{
								pitch = Math::round (Math::wurve (settingMinPitch + OFFSET_POTENTIOMETER, filterPotentiometerPitch, settingMaxPitch - OFFSET_POTENTIOMETER, 1023, ((float)(settingTrimPitchTune) * 4.0) + 3.5, 0, (float)(settingCurvePitch) / 10.0, (float)(settingCurvePitch) / 10.0));
							}
						}
						else
						{
							if (settingInvertPitch == false)
							{
								pitch = Math::round (Math::wurve (settingMinPitch + OFFSET_POTENTIOMETER, filterPotentiometerPitch, settingMaxPitch - OFFSET_POTENTIOMETER, 0, 511.5, 1023, (float)(settingCurvePitch) / 10.0, (float)(settingCurvePitch) / 10.0));
							}
							else
							{
								pitch = Math::round (Math::wurve (settingMinPitch + OFFSET_POTENTIOMETER, filterPotentiometerPitch, settingMaxPitch - OFFSET_POTENTIOMETER, 1023, 511.5, 0, (float)(settingCurvePitch) / 10.0, (float)(settingCurvePitch) / 10.0));
							}
						}
						
						if (settingTrimRollTune != 255)
						{
							if (settingInvertRoll == false)
							{
								roll = Math::round (Math::wurve (settingMinRoll + OFFSET_POTENTIOMETER, filterPotentiometerRoll, settingMaxRoll - OFFSET_POTENTIOMETER, 0, ((float)(settingTrimRollTune) * 4.0) + 3.5, 1023, (float)(settingCurveRoll) / 10.0, (float)(settingCurveRoll) / 10.0));
							}
							else
							{
								roll = Math::round (Math::wurve (settingMinRoll + OFFSET_POTENTIOMETER, filterPotentiometerRoll, settingMaxRoll - OFFSET_POTENTIOMETER, 1023, ((float)(settingTrimRollTune) * 4.0) + 3.5, 0, (float)(settingCurveRoll) / 10.0, (float)(settingCurveRoll) / 10.0));
							}
						}
						else
						{
							if (settingInvertRoll == false)
							{
								roll = Math::round (Math::wurve (settingMinRoll + OFFSET_POTENTIOMETER, filterPotentiometerRoll, settingMaxRoll - OFFSET_POTENTIOMETER, 0, 511.5, 1023, (float)(settingCurveRoll) / 10.0, (float)(settingCurveRoll) / 10.0));
							}
							else
							{
								roll = Math::round (Math::wurve (settingMinRoll + OFFSET_POTENTIOMETER, filterPotentiometerRoll, settingMaxRoll - OFFSET_POTENTIOMETER, 1023, 511.5, 0, (float)(settingCurveRoll) / 10.0, (float)(settingCurveRoll) / 10.0));
							}
						}
						
						if (settingTrimYawTune != 255)
						{
							if (settingInvertYaw == false)
							{
								yaw = Math::round (Math::wurve (settingMinYaw + OFFSET_POTENTIOMETER, filterPotentiometerYaw, settingMaxYaw - OFFSET_POTENTIOMETER, 0, ((float)(settingTrimYawTune) * 4.0) + 3.5, 1023, (float)(settingCurveYaw) / 10.0, (float)(settingCurveYaw) / 10.0));
							}
							else
							{
								yaw = Math::round (Math::wurve (settingMinYaw + OFFSET_POTENTIOMETER, filterPotentiometerYaw, settingMaxYaw - OFFSET_POTENTIOMETER, 1023, ((float)(settingTrimYawTune) * 4.0) + 3.5, 0, (float)(settingCurveYaw) / 10.0, (float)(settingCurveYaw) / 10.0));
							}
						}
						else
						{
							if (settingInvertYaw == false)
							{
								yaw = Math::round (Math::wurve (settingMinYaw + OFFSET_POTENTIOMETER, filterPotentiometerYaw, settingMaxYaw - OFFSET_POTENTIOMETER, 0, 511.5, 1023, (float)(settingCurveYaw) / 10.0, (float)(settingCurveYaw) / 10.0));
							}
							else
							{
								yaw = Math::round (Math::wurve (settingMinYaw + OFFSET_POTENTIOMETER, filterPotentiometerYaw, settingMaxYaw - OFFSET_POTENTIOMETER, 1023, 511.5, 0, (float)(settingCurveYaw) / 10.0, (float)(settingCurveYaw) / 10.0));
							}
						}
						
						cut = switchCut.bistable;
						
						if (cut != cutPrevious)
						{
							cutPrevious = cut;
							
							if (cut == false)
							{
								soundSwitch1 = true;
							}
							else
							{
								soundSwitch2 = true;
							}
						}
						
						if (switchAuxiliaryA1.bistable == true)
						{
							auxiliaryA = 0;
						}
						else if (switchAuxiliaryA2.bistable == true)
						{
							auxiliaryA = 2;
						}
						else
						{
							auxiliaryA = 1;
						}
						
						if (auxiliaryA != auxiliaryAPrevious)
						{
							auxiliaryAPrevious = auxiliaryA;
							
							if (auxiliaryA == 0)
							{
								soundSwitch1 = true;
							}
							else if (auxiliaryA == 1)
							{
								soundSwitch2 = true;
							}
							else
							{
								soundSwitch3 = true;
							}
						}
						
						if (switchAuxiliaryB1.bistable == true)
						{
							auxiliaryB = 0;
						}
						else if (switchAuxiliaryB2.bistable == true)
						{
							auxiliaryB = 2;
						}
						else
						{
							auxiliaryB = 1;
						}
						
						if (auxiliaryB != auxiliaryBPrevious)
						{
							auxiliaryBPrevious = auxiliaryB;
							
							if (auxiliaryB == 0)
							{
								soundSwitch1 = true;
							}
							else if (auxiliaryB == 1)
							{
								soundSwitch2 = true;
							}
							else
							{
								soundSwitch3 = true;
							}
						}
						
						if (switchAuxiliaryC1.bistable == true)
						{
							auxiliaryC = 0;
						}
						else if (switchAuxiliaryC2.bistable == true)
						{
							auxiliaryC = 2;
						}
						else
						{
							auxiliaryC = 1;
						}
						
						if (auxiliaryC != auxiliaryCPrevious)
						{
							auxiliaryCPrevious = auxiliaryC;
							
							if (auxiliaryC == 0)
							{
								soundSwitch1 = true;
							}
							else if (auxiliaryC == 1)
							{
								soundSwitch2 = true;
							}
							else
							{
								soundSwitch3 = true;
							}
						}
						
						auxiliaryD = Math::round (Math::curve (settingMinAuxiliaryD + OFFSET_POTENTIOMETER, filterPotentiometerAuxiliaryD, settingMaxAuxiliaryD - OFFSET_POTENTIOMETER, 0, 1023, 0));
						
						if (failSafe < 31)
						{
							failSafe++;
						}
						else
						{
							failSafe = 0;
						}
						
						if (flipFlopTransmit == false)
						{
							channelThrottleRollAuxiliaryCAuxiliaryD.transmit ((signed long)(auxiliaryD) << 22 | (signed long)(auxiliaryC) << 20 | (signed long)(roll) << 10 | (signed long)(throttle));
							flipFlopTransmit = true;
						}
						else
						{
							channelPitchYawCutAuxiliaryAAuxiliaryBFailSafeUpdate.transmit ((signed long)(update) << 30 | (signed long)(failSafe) << 25 | (signed long)(auxiliaryB) << 23 | (signed long)(auxiliaryA) << 21 | (signed long)(cut) << 20 | (signed long)(yaw) << 10 | (signed long)(pitch));
							flipFlopTransmit = false;
						}
						
						filterVoltageBatteryModel.set (Math::curve (0, channelVoltageBatteryModelTelemetryWatchDogUpdated.data & 0b00000000000000000000001111111111, 1023, 0, 30, 0));
						hysteresisVoltageBatteryModel.set (filterVoltageBatteryModel.value * 10.0);
						filterTelemetry.set ((float)((channelVoltageBatteryModelTelemetryWatchDogUpdated.data & 0b00000011111111111111110000000000) >> 10) / 10.0);
						hysteresisTelemetry.set (filterTelemetry.value * 10.0);
						
						updated = (channelVoltageBatteryModelTelemetryWatchDogUpdated.data & 0b10000000000000000000000000000000) >> 31;
						
						if (channelSettingBatteryTimer.received == true && channelSettingTrim.received == true && channelSettingStick.received == true && channelSettingOption1.received == true && channelSettingOption2.received == true && channelSettingOption3.received == true && channelSettingOption4.received == true && channelSettingOption5.received == true && channelSettingOption6.received == true && channelSettingOption7.received == true && channelSettingOption8.received == true && channelSettingOption9.received == true && channelSettingOption10.received == true && channelSettingOption11.received == true && channelSettingOption12.received == true && channelSettingOption13.received == true && channelSettingOption14.received == true && channelSettingOption15.received == true && channelSettingOption16.received == true && channelSettingBatteryTimer.data == dataSettingBatteryTimer && channelSettingTrim.data == dataSettingTrim && channelSettingStick.data == dataSettingStick && channelSettingOption1.data == dataSettingOption1 && channelSettingOption2.data == dataSettingOption2 && channelSettingOption3.data == dataSettingOption3 && channelSettingOption4.data == dataSettingOption4 && channelSettingOption5.data == dataSettingOption5 && channelSettingOption6.data == dataSettingOption6 && channelSettingOption7.data == dataSettingOption7 && channelSettingOption8.data == dataSettingOption8 && channelSettingOption9.data == dataSettingOption9 && channelSettingOption10.data == dataSettingOption10 && channelSettingOption11.data == dataSettingOption11 && channelSettingOption12.data == dataSettingOption12 && channelSettingOption13.data == dataSettingOption13 && channelSettingOption14.data == dataSettingOption14 && channelSettingOption15.data == dataSettingOption15 && channelSettingOption16.data == dataSettingOption16)
						{
							update = 2;
						}
						
						if (switchTrimThrottle1.monostable == true)
						{
							soundNull = true;
						}
						else if (switchTrimThrottle2.monostable == true)
						{
							soundNull = true;
						}
						else if (switchTrimThrottle1.bistable == true)
						{
							delayTrimThrottle.state();
							
							if (delayTrimThrottle.update == true)
							{
								soundNull = true;
								delayTrimThrottle.duration (50);
							}
						}
						else if (switchTrimThrottle2.bistable == true)
						{
							delayTrimThrottle.state();
							
							if (delayTrimThrottle.update == true)
							{
								soundNull = true;
								delayTrimThrottle.duration (50);
							}
						}
						else
						{
							delayTrimThrottle.duration (1000);
							delayTrimThrottle.reset();
						}
						
						if (switchTrimPitch1.monostable == true)
						{
							soundNull = true;
						}
						else if (switchTrimPitch2.monostable == true)
						{
							soundNull = true;
						}
						else if (switchTrimPitch1.bistable == true)
						{
							delayTrimPitch.state();
							
							if (delayTrimPitch.update == true)
							{
								soundNull = true;
								delayTrimPitch.duration (50);
							}
						}
						else if (switchTrimPitch2.bistable == true)
						{
							delayTrimPitch.state();
							
							if (delayTrimPitch.update == true)
							{
								soundNull = true;
								delayTrimPitch.duration (50);
							}
						}
						else
						{
							delayTrimPitch.duration (1000);
							delayTrimPitch.reset();
						}
						
						if (switchTrimRoll1.monostable == true)
						{
							soundNull = true;
						}
						else if (switchTrimRoll2.monostable == true)
						{
							soundNull = true;
						}
						else if (switchTrimRoll1.bistable == true)
						{
							delayTrimRoll.state();
							
							if (delayTrimRoll.update == true)
							{
								soundNull = true;
								delayTrimRoll.duration (50);
							}
						}
						else if (switchTrimRoll2.bistable == true)
						{
							delayTrimRoll.state();
							
							if (delayTrimRoll.update == true)
							{
								soundNull = true;
								delayTrimRoll.duration (50);
							}
						}
						else
						{
							delayTrimRoll.duration (1000);
							delayTrimRoll.reset();
						}
						
						if (switchTrimYaw1.monostable == true)
						{
							soundNull = true;
						}
						else if (switchTrimYaw2.monostable == true)
						{
							soundNull = true;
						}
						else if (switchTrimYaw1.bistable == true)
						{
							delayTrimYaw.state();
							
							if (delayTrimYaw.update == true)
							{
								soundNull = true;
								delayTrimYaw.duration (50);
							}
						}
						else if (switchTrimYaw2.bistable == true)
						{
							delayTrimYaw.state();
							
							if (delayTrimYaw.update == true)
							{
								soundNull = true;
								delayTrimYaw.duration (50);
							}
						}
						else
						{
							delayTrimYaw.duration (1000);
							delayTrimYaw.reset();
						}
						
						filterVoltageBatteryControl.set (Math::curve (0, voltageBatteryControl.value, 1023, 0, 30, 0));
						hysteresisVoltageBatteryControl.set (filterVoltageBatteryControl.value * 10.0);
						
						if (lowVoltageBatteryControl == false && (float)(hysteresisVoltageBatteryControl.value) / 10.0 < SETUP_LOW_VOLTAGE_BATTERY_CONTROL)
						{
							lowVoltageBatteryControl = true;
							soundLowVoltageBatteryControl = true;
						}
						
						if (settingVoltageBatteryModelLow != 0)
						{
							if (lowVoltageBatteryModel == false && (float)(hysteresisVoltageBatteryModel.value) / 10.0 < (float)(settingVoltageBatteryModelLow) / 10.0)
							{
								lowVoltageBatteryModel = true;
								
								soundLowVoltageBatteryModel = 1;
								soundTimerEnded = 0;
							}
						}
						else if (lowVoltageBatteryModel == true)
						{
							lowVoltageBatteryModel = false;
							
							displayVoltageBatteryModel = 0;
							soundLowVoltageBatteryModel = 0;
						}
						
						if (settingTimerEnd != 0)
						{
							if (timerStarted == false && timerEnded == false && throttleRaw >= settingTimerTrigger && settingTimerTrigger != 0)
							{
								timer.start (0);
								timerStarted = true;
								
								soundTimerStart = true;
							}
							else if (timerStarted == false && timerEnded == false && cut == false && settingTimerTrigger == 0)
							{
								timer.start (0);
								timerStarted = true;
								
								soundTimerStart = true;
							}
							else if (timerStarted == true && ((settingTimerEnd >= 5 && timer.s >= (unsigned long long)(settingTimerEnd) - 5ull) || settingTimerEnd < 5))
							{
								timerStarted = false;
								timerEnded = true;
								
								if (lowVoltageBatteryModel == false || (lowVoltageBatteryModel == true && soundLowVoltageBatteryModel == 7))
								{
									if (settingTimerEnd >= 5 && timer.s >= (unsigned long long)(settingTimerEnd) - 5ull)
									{
										soundTimerEnded = 1;
									}
									else
									{
										soundTimerEnded = 6 - settingTimerEnd;
									}
								}
							}
						}
						else if (timerStarted == true || timerEnded == true)
						{
							timer.stop();
							
							timerStarted = false;
							timerEnded = false;
							
							displayTimerEnded = 0;
							soundTimerEnded = 0;
						}
						
						if (lowVoltageBatteryControl == true || lowVoltageBatteryModel == true || timerEnded == true)
						{
							delaySoundAlarm.state();
							
							if (delaySoundAlarm.update == true)
							{
								soundAlarm = true;
							}
						}
						else
						{
							delaySoundAlarm.reset();
						}
						
						if (binding == true)
						{
							delayDotBinding.state();
							
							if (delayDotBinding.update == true)
							{
								for (iterationAnimation = 0; iterationAnimation < 8; iterationAnimation++)
								{
									if (iterationAnimation == dotBinding)
									{
										display.draw (Tool::characterToByte (&WORD_BINDING [iterationAnimation]) | 0b10000000, iterationAnimation + 1);
									}
									else
									{
										display.draw (Tool::characterToByte (&WORD_BINDING [iterationAnimation]), iterationAnimation + 1);
									}
								}
								
								if (dotBinding < 7)
								{
									dotBinding++;
								}
								else
								{
									dotBinding = 0;
								}
							}
						}
						
						if (soundNull == true && inhibitSound == false)
						{
							SoundWrite::play (128, 200);
							timeSoundPrevious = timeSound.ms + 200ull + (unsigned long long)(TIME_SPACE_SOUND);
						}
						else if (soundTimerStart == true)
						{
							SoundWrite::add (256, 60);
							SoundWrite::add (0, 40);
							SoundWrite::add (512, 60);
							SoundWrite::add (0, 40);
							SoundWrite::add (1024, 60);
							SoundWrite::play (0, 0);
							
							timeSoundPrevious = timeSound.ms + 260ull + (unsigned long long)(TIME_SPACE_SOUND);
						}
						else if (soundSwitch1 == true && inhibitSound == false)
						{
							SoundWrite::play (1024, 20);
							timeSoundPrevious = timeSound.ms + 20ull + (unsigned long long)(TIME_SPACE_SOUND);
						}
						else if (soundSwitch2 == true && inhibitSound == false)
						{
							SoundWrite::add (1024, 20);
							SoundWrite::add (0, 40);
							SoundWrite::add (1024, 20);
							SoundWrite::play (0, 0);
							
							timeSoundPrevious = timeSound.ms + 80ull + (unsigned long long)(TIME_SPACE_SOUND);
						}
						else if (soundSwitch3 == true && inhibitSound == false)
						{
							SoundWrite::add (1024, 20);
							SoundWrite::add (0, 40);
							SoundWrite::add (1024, 20);
							SoundWrite::add (0, 40);
							SoundWrite::add (1024, 20);
							SoundWrite::play (0, 0);
							
							timeSoundPrevious = timeSound.ms + 140ull + (unsigned long long)(TIME_SPACE_SOUND);
						}
						else if (soundLowVoltageBatteryModel >= 1 && soundLowVoltageBatteryModel <= 6)
						{
							delaySoundLowVoltageBatteryModel.state();
							
							if (delaySoundLowVoltageBatteryModel.update == true)
							{
								if (soundLowVoltageBatteryModel != 6)
								{
									SoundWrite::add (2048, 100);
									SoundWrite::add (0, 50);
									SoundWrite::add (2048, 100);
									SoundWrite::play (0, 0);
									
									timeSoundPrevious = timeSound.ms + 250ull + (unsigned long long)(TIME_SPACE_SOUND);
								}
								else
								{
									SoundWrite::play (2048, 2000);
									timeSoundPrevious = timeSound.ms + 2000ull + (unsigned long long)(TIME_SPACE_SOUND);
								}
								
								soundLowVoltageBatteryModel++;
							}
						}
						else if (soundTimerEnded >= 1 && soundTimerEnded <= 6)
						{
							delaySoundTimerEnded.state();
							
							if (delaySoundTimerEnded.update == true)
							{
								if (soundTimerEnded == 1)
								{
									SoundWrite::add (2048, 20);
									SoundWrite::add (0, 50);
									SoundWrite::add (2048, 20);
									SoundWrite::add (0, 50);
									SoundWrite::add (2048, 20);
									SoundWrite::add (0, 50);
									SoundWrite::add (2048, 20);
									SoundWrite::add (0, 50);
									SoundWrite::add (2048, 20);
									SoundWrite::play (0, 0);
									
									timeSoundPrevious = timeSound.ms + 300ull + (unsigned long long)(TIME_SPACE_SOUND);
								}
								else if (soundTimerEnded == 2)
								{
									SoundWrite::add (2048, 20);
									SoundWrite::add (0, 50);
									SoundWrite::add (2048, 20);
									SoundWrite::add (0, 50);
									SoundWrite::add (2048, 20);
									SoundWrite::add (0, 50);
									SoundWrite::add (2048, 20);
									SoundWrite::play (0, 0);
									
									timeSoundPrevious = timeSound.ms + 230ull + (unsigned long long)(TIME_SPACE_SOUND);
								}
								else if (soundTimerEnded == 3)
								{
									SoundWrite::add (2048, 20);
									SoundWrite::add (0, 50);
									SoundWrite::add (2048, 20);
									SoundWrite::add (0, 50);
									SoundWrite::add (2048, 20);
									SoundWrite::play (0, 0);
									
									timeSoundPrevious = timeSound.ms + 160ull + (unsigned long long)(TIME_SPACE_SOUND);
								}
								else if (soundTimerEnded == 4)
								{
									SoundWrite::add (2048, 20);
									SoundWrite::add (0, 50);
									SoundWrite::add (2048, 20);
									SoundWrite::play (0, 0);
									
									timeSoundPrevious = timeSound.ms + 90ull + (unsigned long long)(TIME_SPACE_SOUND);
								}
								else if (soundTimerEnded == 5)
								{
									SoundWrite::play (2048, 20);
									timeSoundPrevious = timeSound.ms + 20ull + (unsigned long long)(TIME_SPACE_SOUND);
								}
								else
								{
									SoundWrite::play (2048, 2000);
									timeSoundPrevious = timeSound.ms + 2000ull + (unsigned long long)(TIME_SPACE_SOUND);
								}
								
								soundTimerEnded++;
							}
						}
						else if (soundAlarm == true)
						{
							SoundWrite::play (2048, 10);
							timeSoundPrevious = timeSound.ms + 10ull + (unsigned long long)(TIME_SPACE_SOUND);
						}
						
						if (soundLowVoltageBatteryControl == true && timeSound.ms > timeSoundPrevious)
						{
							delaySoundLowVoltageBatteryControl.state();
							
							if (delaySoundLowVoltageBatteryControl.update == true)
							{
								SoundWrite::play (2048, 100);
							}
						}
						
						soundNull = false;
						soundTimerStart = false;
						soundAlarm = false;
						soundSwitch1 = false;
						soundSwitch2 = false;
						soundSwitch3 = false;
						
						inhibitSound = false;
					}
					
					settingVoltageBatteryModelLow = settingVoltageBatteryModelLowTune;
					settingTimerEnd = settingTimerEndTune;
					settingTimerTrigger = settingTimerTriggerTune;
					settingTrimThrottle = settingTrimThrottleTune;
					settingTrimPitch = settingTrimPitchTune;
					settingTrimRoll = settingTrimRollTune;
					settingTrimYaw = settingTrimYawTune;
					settingInvertThrottle = settingInvertThrottleTune;
					settingInvertPitch = settingInvertPitchTune;
					settingInvertRoll = settingInvertRollTune;
					settingInvertYaw = settingInvertYawTune;
					settingCurveThrottle = settingCurveThrottleTune;
					settingCurvePitch = settingCurvePitchTune;
					settingCurveRoll = settingCurveRollTune;
					settingCurveYaw = settingCurveYawTune;
					
					for (iterationSettingOption = 0; iterationSettingOption < countSettingOption; iterationSettingOption++)
					{
						settingOption [mapSettingOption [iterationSettingOption]] = settingOptionTune [mapSettingOption [iterationSettingOption]];
					}
					
					if (exit == true)
					{
						updateLeaved = true;
					}
					else
					{
						updateLeaved = false;
					}
					
					update = 0;
					menuSetting = false;
					
					stateLocked = 2;
					
					delayTrimThrottle.duration (1000);
					delayTrimThrottle.reset();
					delayTrimPitch.duration (1000);
					delayTrimPitch.reset();
					delayTrimRoll.duration (1000);
					delayTrimRoll.reset();
					delayTrimYaw.duration (1000);
					delayTrimYaw.reset();
					
					if (lowVoltageBatteryControl == true)
					{
						delayDisplayLowVoltageBatteryControl.reset();
						displayVoltageBatteryControl = 1;
					}
					
					if (lowVoltageBatteryModel == true)
					{
						delayDisplayLowVoltageBatteryModel.reset();
						displayVoltageBatteryModel = 1;
					}
					
					if (timerEnded == true)
					{
						delayDisplayTimerEnded.reset();
						displayTimerEnded = 1;
					}
					
					select.set (Math::curve (0, potentiometerSelect.value, 1023, 0, 9, 0));
					selectPrevious = select.value;
					
					if (binding == true && exit == false)
					{
						soundSwitch2 = true;
					}
				}
			}
		}
		else
		{
			if (locked == false)
			{
				select.set (Math::curve (0, potentiometerSelect.value, 1023, 0, 6, 0));
			}
			else
			{
				select.set (Math::curve (0, potentiometerSelect.value, 1023, 0, 5, 0));
			}
			
			if (select.value != selectPrevious)
			{
				selectPrevious = select.value;
				
				stateSettingTune = 2;
				
				soundSelect = true;
			}
			
			if (select.value == 0)
			{
				display.word ("c.lth/");
				display.integer (settingMaxThrottleTune - settingMinThrottleTune, 5, 8, true);
			}
			else if (select.value == 1)
			{
				display.word ("cl.pi/");
				display.integer (settingMaxPitchTune - settingMinPitchTune, 5, 8, true);
			}
			else if (select.value == 2)
			{
				display.word ("clr.o/");
				display.integer (settingMaxRollTune - settingMinRollTune, 5, 8, true);
			}
			else if (select.value == 3)
			{
				display.word ("clya./");
				display.integer (settingMaxYawTune - settingMinYawTune, 5, 8, true);
			}
			else if (select.value == 4)
			{
				display.word ("c.lax/");
				display.integer (settingMaxAuxiliaryDTune - settingMinAuxiliaryDTune, 5, 8, true);
			}
			else if (select.value == 5)
			{
				display.word ("  .exit  ");
			}
			else
			{
				if (settingMinThrottleTune != settingMinThrottle || settingMaxThrottleTune != settingMaxThrottle || settingMinPitchTune != settingMinPitch || settingMaxPitchTune != settingMaxPitch || settingMinRollTune != settingMinRoll || settingMaxRollTune != settingMaxRoll || settingMinYawTune != settingMinYaw || settingMaxYawTune != settingMaxYaw || settingMinAuxiliaryDTune != settingMinAuxiliaryD || settingMaxAuxiliaryDTune != settingMaxAuxiliaryD)
				{
					display.word (" -s.ave- ");
				}
				else
				{
					display.word ("  s.ave  ");
				}
			}
			
			if (select.value == 0)
			{
				if (buttonSelect.bistable == true && stateSettingTune == 0)
				{
					stateSettingTune = 1;
					
					hysteresisPotentiometerSetting.set (filterPotentiometerThrottle);
					
					settingThrottleTune = hysteresisPotentiometerSetting.value;
					settingMinThrottleTune = hysteresisPotentiometerSetting.value;
					settingMaxThrottleTune = hysteresisPotentiometerSetting.value;
					settingTunePrevious = hysteresisPotentiometerSetting.value;
					
					soundSwitch3 = true;
				}
				else if (buttonSelect.bistable == true && stateSettingTune == 1)
				{
					hysteresisPotentiometerSetting.set (filterPotentiometerThrottle);
					settingThrottleTune = hysteresisPotentiometerSetting.value;
					
					if (settingThrottleTune > settingMaxThrottleTune)
					{
						settingMaxThrottleTune = settingThrottleTune;
					}
					else if (settingThrottleTune < settingMinThrottleTune)
					{
						settingMinThrottleTune = settingThrottleTune;
					}
					
					if (settingMaxThrottleTune - settingMinThrottleTune != settingTunePrevious)
					{
						settingTunePrevious = settingMaxThrottleTune - settingMinThrottleTune;
						soundTune = true;
					}
				}
				else if (buttonSelect.bistable == false)
				{
					stateSettingTune = 0;
				}
			}
			else if (select.value == 1)
			{
				if (buttonSelect.bistable == true && stateSettingTune == 0)
				{
					stateSettingTune = 1;
					
					hysteresisPotentiometerSetting.set (filterPotentiometerPitch);
					
					settingPitchTune = hysteresisPotentiometerSetting.value;
					settingMinPitchTune = hysteresisPotentiometerSetting.value;
					settingMaxPitchTune = hysteresisPotentiometerSetting.value;
					settingTunePrevious = hysteresisPotentiometerSetting.value;
					
					soundSwitch3 = true;
				}
				else if (buttonSelect.bistable == true && stateSettingTune == 1)
				{
					hysteresisPotentiometerSetting.set (filterPotentiometerPitch);
					settingPitchTune = hysteresisPotentiometerSetting.value;
					
					if (settingPitchTune > settingMaxPitchTune)
					{
						settingMaxPitchTune = settingPitchTune;
					}
					else if (settingPitchTune < settingMinPitchTune)
					{
						settingMinPitchTune = settingPitchTune;
					}
					
					if (settingMaxPitchTune - settingMinPitchTune != settingTunePrevious)
					{
						settingTunePrevious = settingMaxPitchTune - settingMinPitchTune;
						soundTune = true;
					}
				}
				else if (buttonSelect.bistable == false)
				{
					stateSettingTune = 0;
				}
			}
			else if (select.value == 2)
			{
				if (buttonSelect.bistable == true && stateSettingTune == 0)
				{
					stateSettingTune = 1;
					
					hysteresisPotentiometerSetting.set (filterPotentiometerRoll);
					
					settingRollTune = hysteresisPotentiometerSetting.value;
					settingMinRollTune = hysteresisPotentiometerSetting.value;
					settingMaxRollTune = hysteresisPotentiometerSetting.value;
					settingTunePrevious = hysteresisPotentiometerSetting.value;
					
					soundSwitch3 = true;
				}
				else if (buttonSelect.bistable == true && stateSettingTune == 1)
				{
					hysteresisPotentiometerSetting.set (filterPotentiometerRoll);
					settingRollTune = hysteresisPotentiometerSetting.value;
					
					if (settingRollTune > settingMaxRollTune)
					{
						settingMaxRollTune = settingRollTune;
					}
					else if (settingRollTune < settingMinRollTune)
					{
						settingMinRollTune = settingRollTune;
					}
					
					if (settingMaxRollTune - settingMinRollTune != settingTunePrevious)
					{
						settingTunePrevious = settingMaxRollTune - settingMinRollTune;
						soundTune = true;
					}
				}
				else if (buttonSelect.bistable == false)
				{
					stateSettingTune = 0;
				}
			}
			else if (select.value == 3)
			{
				if (buttonSelect.bistable == true && stateSettingTune == 0)
				{
					stateSettingTune = 1;
					
					hysteresisPotentiometerSetting.set (filterPotentiometerYaw);
					
					settingYawTune = hysteresisPotentiometerSetting.value;
					settingMinYawTune = hysteresisPotentiometerSetting.value;
					settingMaxYawTune = hysteresisPotentiometerSetting.value;
					settingTunePrevious = hysteresisPotentiometerSetting.value;
					
					soundSwitch3 = true;
				}
				else if (buttonSelect.bistable == true && stateSettingTune == 1)
				{
					hysteresisPotentiometerSetting.set (filterPotentiometerYaw);
					settingYawTune = hysteresisPotentiometerSetting.value;
					
					if (settingYawTune > settingMaxYawTune)
					{
						settingMaxYawTune = settingYawTune;
					}
					else if (settingYawTune < settingMinYawTune)
					{
						settingMinYawTune = settingYawTune;
					}
					
					if (settingMaxYawTune - settingMinYawTune != settingTunePrevious)
					{
						settingTunePrevious = settingMaxYawTune - settingMinYawTune;
						soundTune = true;
					}
				}
				else if (buttonSelect.bistable == false)
				{
					stateSettingTune = 0;
				}
			}
			else if (select.value == 4)
			{
				if (buttonSelect.bistable == true && stateSettingTune == 0)
				{
					stateSettingTune = 1;
					
					hysteresisPotentiometerSetting.set (filterPotentiometerAuxiliaryD);
					
					settingAuxiliaryDTune = hysteresisPotentiometerSetting.value;
					settingMinAuxiliaryDTune = hysteresisPotentiometerSetting.value;
					settingMaxAuxiliaryDTune = hysteresisPotentiometerSetting.value;
					settingTunePrevious = hysteresisPotentiometerSetting.value;
					
					soundSwitch3 = true;
				}
				else if (buttonSelect.bistable == true && stateSettingTune == 1)
				{
					hysteresisPotentiometerSetting.set (filterPotentiometerAuxiliaryD);
					settingAuxiliaryDTune = hysteresisPotentiometerSetting.value;
					
					if (settingAuxiliaryDTune > settingMaxAuxiliaryDTune)
					{
						settingMaxAuxiliaryDTune = settingAuxiliaryDTune;
					}
					else if (settingAuxiliaryDTune < settingMinAuxiliaryDTune)
					{
						settingMinAuxiliaryDTune = settingAuxiliaryDTune;
					}
					
					if (settingMaxAuxiliaryDTune - settingMinAuxiliaryDTune != settingTunePrevious)
					{
						settingTunePrevious = settingMaxAuxiliaryDTune - settingMinAuxiliaryDTune;
						soundTune = true;
					}
				}
				else if (buttonSelect.bistable == false)
				{
					stateSettingTune = 0;
				}
			}
			else if (select.value == 5)
			{
				if (buttonSelect.monostable == true)
				{
					menuSetting = false;
					
					stateLocked = 2;
					
					if (lowVoltageBatteryControl == true)
					{
						delayDisplayLowVoltageBatteryControl.reset();
						displayVoltageBatteryControl = 1;
					}
					
					if (lowVoltageBatteryModel == true)
					{
						delayDisplayLowVoltageBatteryModel.reset();
						displayVoltageBatteryModel = 1;
					}
					
					if (timerEnded == true)
					{
						delayDisplayTimerEnded.reset();
						displayTimerEnded = 1;
					}
					
					select.set (Math::curve (0, potentiometerSelect.value, 1023, 0, 9, 0));
					selectPrevious = select.value;
					
					soundNull = true;
				}
			}
			else
			{
				if (buttonSelect.monostable == true)
				{
					Eeprom::write (2, settingMinThrottleTune, 16);
					Eeprom::write (4, settingMaxThrottleTune, 16);
					Eeprom::write (6, settingMinPitchTune, 16);
					Eeprom::write (8, settingMaxPitchTune, 16);
					Eeprom::write (10, settingMinRollTune, 16);
					Eeprom::write (12, settingMaxRollTune, 16);
					Eeprom::write (14, settingMinYawTune, 16);
					Eeprom::write (16, settingMaxYawTune, 16);
					Eeprom::write (18, settingMinAuxiliaryDTune, 16);
					Eeprom::write (20, settingMaxAuxiliaryDTune, 16);
					
					settingMinThrottle = settingMinThrottleTune;
					settingMaxThrottle = settingMaxThrottleTune;
					settingMinPitch = settingMinPitchTune;
					settingMaxPitch = settingMaxPitchTune;
					settingMinRoll = settingMinRollTune;
					settingMaxRoll = settingMaxRollTune;
					settingMinYaw = settingMinYawTune;
					settingMaxYaw = settingMaxYawTune;
					settingMinAuxiliaryD = settingMinAuxiliaryDTune;
					settingMaxAuxiliaryD = settingMaxAuxiliaryDTune;
					
					menuSetting = false;
					
					stateLocked = 2;
					
					if (lowVoltageBatteryControl == true)
					{
						delayDisplayLowVoltageBatteryControl.reset();
						displayVoltageBatteryControl = 1;
					}
					
					if (lowVoltageBatteryModel == true)
					{
						delayDisplayLowVoltageBatteryModel.reset();
						displayVoltageBatteryModel = 1;
					}
					
					if (timerEnded == true)
					{
						delayDisplayTimerEnded.reset();
						displayTimerEnded = 1;
					}
					
					select.set (Math::curve (0, potentiometerSelect.value, 1023, 0, 9, 0));
					selectPrevious = select.value;
					
					soundSwitch3 = true;
				}
			}
		}
		
		if (brightness < 16 && timeDisplay.ms >= timeDisplayPrevious)
		{
			brightness++;
			
			display.brightness (brightness);
			
			timeDisplayPrevious = timeDisplay.ms + 30ull;
		}
		
		if (soundSelect == true && inhibitSound == false)
		{
			SoundWrite::play (1024, 20);
			timeSoundPrevious = timeSound.ms + 20ull + (unsigned long long)(TIME_SPACE_SOUND);
		}
		else if (soundOk == true)
		{
			SoundWrite::add (1024, 20);
			SoundWrite::add (0, 20);
			SoundWrite::add (1024, 20);
			SoundWrite::play (0, 0);
			
			timeSoundPrevious = timeSound.ms + 60ull + (unsigned long long)(TIME_SPACE_SOUND);
		}
		else if (soundNull == true && inhibitSound == false)
		{
			SoundWrite::play (128, 200);
			timeSoundPrevious = timeSound.ms + 200ull + (unsigned long long)(TIME_SPACE_SOUND);
		}
		else if (soundLock == true)
		{
			SoundWrite::add (1024, 20);
			SoundWrite::add (0, 20);
			SoundWrite::add (1024, 20);
			SoundWrite::play (0, 0);
			
			timeSoundPrevious = timeSound.ms + 60ull + (unsigned long long)(TIME_SPACE_SOUND);
		}
		else if (soundLocked == true)
		{
			SoundWrite::add (1024, 20);
			SoundWrite::add (0, 20);
			SoundWrite::add (1024, 20);
			SoundWrite::add (0, 20);
			SoundWrite::add (1024, 20);
			SoundWrite::add (0, 20);
			SoundWrite::add (1024, 20);
			SoundWrite::add (0, 20);
			SoundWrite::add (1024, 20);
			SoundWrite::add (0, 20);
			SoundWrite::add (1024, 20);
			SoundWrite::play (0, 0);
			
			timeSoundPrevious = timeSound.ms + 220ull + (unsigned long long)(TIME_SPACE_SOUND);
		}
		else if (soundTimerStart == true)
		{
			SoundWrite::add (256, 60);
			SoundWrite::add (0, 40);
			SoundWrite::add (512, 60);
			SoundWrite::add (0, 40);
			SoundWrite::add (1024, 60);
			SoundWrite::play (0, 0);
			
			timeSoundPrevious = timeSound.ms + 260ull + (unsigned long long)(TIME_SPACE_SOUND);
		}
		else if (soundSwitch1 == true && inhibitSound == false)
		{
			SoundWrite::play (1024, 20);
			timeSoundPrevious = timeSound.ms + 20ull + (unsigned long long)(TIME_SPACE_SOUND);
		}
		else if (soundSwitch2 == true && inhibitSound == false)
		{
			SoundWrite::add (1024, 20);
			SoundWrite::add (0, 40);
			SoundWrite::add (1024, 20);
			SoundWrite::play (0, 0);
			
			timeSoundPrevious = timeSound.ms + 80ull + (unsigned long long)(TIME_SPACE_SOUND);
		}
		else if (soundSwitch3 == true && inhibitSound == false)
		{
			SoundWrite::add (1024, 20);
			SoundWrite::add (0, 40);
			SoundWrite::add (1024, 20);
			SoundWrite::add (0, 40);
			SoundWrite::add (1024, 20);
			SoundWrite::play (0, 0);
			
			timeSoundPrevious = timeSound.ms + 140ull + (unsigned long long)(TIME_SPACE_SOUND);
		}
		else if (soundTune == true && inhibitSound == false && timeSound.ms > timeSoundPrevious)
		{
			SoundWrite::play (2048, 1);
			timeSoundPrevious = timeSound.ms + 30ull + (unsigned long long)(TIME_SPACE_SOUND);
		}
		else if (soundLowVoltageBatteryModel >= 1 && soundLowVoltageBatteryModel <= 6)
		{
			delaySoundLowVoltageBatteryModel.state();
			
			if (delaySoundLowVoltageBatteryModel.update == true)
			{
				if (soundLowVoltageBatteryModel != 6)
				{
					SoundWrite::add (2048, 100);
					SoundWrite::add (0, 50);
					SoundWrite::add (2048, 100);
					SoundWrite::play (0, 0);
					
					timeSoundPrevious = timeSound.ms + 250ull + (unsigned long long)(TIME_SPACE_SOUND);
				}
				else
				{
					SoundWrite::play (2048, 2000);
					timeSoundPrevious = timeSound.ms + 2000ull + (unsigned long long)(TIME_SPACE_SOUND);
				}
				
				soundLowVoltageBatteryModel++;
			}
		}
		else if (soundTimerEnded >= 1 && soundTimerEnded <= 6)
		{
			delaySoundTimerEnded.state();
			
			if (delaySoundTimerEnded.update == true)
			{
				if (soundTimerEnded == 1)
				{
					SoundWrite::add (2048, 20);
					SoundWrite::add (0, 50);
					SoundWrite::add (2048, 20);
					SoundWrite::add (0, 50);
					SoundWrite::add (2048, 20);
					SoundWrite::add (0, 50);
					SoundWrite::add (2048, 20);
					SoundWrite::add (0, 50);
					SoundWrite::add (2048, 20);
					SoundWrite::play (0, 0);
					
					timeSoundPrevious = timeSound.ms + 300ull + (unsigned long long)(TIME_SPACE_SOUND);
				}
				else if (soundTimerEnded == 2)
				{
					SoundWrite::add (2048, 20);
					SoundWrite::add (0, 50);
					SoundWrite::add (2048, 20);
					SoundWrite::add (0, 50);
					SoundWrite::add (2048, 20);
					SoundWrite::add (0, 50);
					SoundWrite::add (2048, 20);
					SoundWrite::play (0, 0);
					
					timeSoundPrevious = timeSound.ms + 230ull + (unsigned long long)(TIME_SPACE_SOUND);
				}
				else if (soundTimerEnded == 3)
				{
					SoundWrite::add (2048, 20);
					SoundWrite::add (0, 50);
					SoundWrite::add (2048, 20);
					SoundWrite::add (0, 50);
					SoundWrite::add (2048, 20);
					SoundWrite::play (0, 0);
					
					timeSoundPrevious = timeSound.ms + 160ull + (unsigned long long)(TIME_SPACE_SOUND);
				}
				else if (soundTimerEnded == 4)
				{
					SoundWrite::add (2048, 20);
					SoundWrite::add (0, 50);
					SoundWrite::add (2048, 20);
					SoundWrite::play (0, 0);
					
					timeSoundPrevious = timeSound.ms + 90ull + (unsigned long long)(TIME_SPACE_SOUND);
				}
				else if (soundTimerEnded == 5)
				{
					SoundWrite::play (2048, 20);
					timeSoundPrevious = timeSound.ms + 20ull + (unsigned long long)(TIME_SPACE_SOUND);
				}
				else
				{
					SoundWrite::play (2048, 2000);
					timeSoundPrevious = timeSound.ms + 2000ull + (unsigned long long)(TIME_SPACE_SOUND);
				}
				
				soundTimerEnded++;
			}
		}
		else if (soundAlarm == true)
		{
			SoundWrite::play (2048, 10);
			timeSoundPrevious = timeSound.ms + 10ull + (unsigned long long)(TIME_SPACE_SOUND);
		}
		
		if (soundLowVoltageBatteryControl == true && timeSound.ms > timeSoundPrevious)
		{
			delaySoundLowVoltageBatteryControl.state();
			
			if (delaySoundLowVoltageBatteryControl.update == true)
			{
				SoundWrite::play (2048, 100);
			}
		}
		
		if (soundWatchDog == 1 && timeSound.ms > timeSoundPrevious)
		{
			SoundWrite::add (128, 100);
			SoundWrite::add (512, 100);
			SoundWrite::play (0, 0);
		}
		else if (soundWatchDog == 2 && timeSound.ms > timeSoundPrevious)
		{
			SoundWrite::add (512, 100);
			SoundWrite::add (128, 100);
			SoundWrite::play (0, 0);
		}
		
		soundSelect = false;
		soundOk = false;
		soundNull = false;
		soundLock = false;
		soundLocked = false;
		soundTimerStart = false;
		soundAlarm = false;
		soundSwitch1 = false;
		soundSwitch2 = false;
		soundSwitch3 = false;
		soundTune = false;
		soundWatchDog = 0;
		
		inhibitSound = false;
	}
	
	return 0;
}
