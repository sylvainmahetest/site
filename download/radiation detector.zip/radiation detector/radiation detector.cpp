#include <InterruptRead.h>
#include <SpiMax7219.h>
#include <SoundWrite.h>
#include <Filter.h>
#include <Timer.h>
#include <Delay.h>
#include <GpioWrite.h>
#include <GpioRead.h>
#include <AnalogRead.h>
#include <Hysteresis.h>
#include <Math.h>

unsigned long _countTotal = 0;

void shock()
{
	_countTotal++;
}

int main()
{
	unsigned char iterationAnimation = 0;
	unsigned char iterationSubAnimation = 0;
	unsigned char byteAnimation = 0b00001000;
	GpioWrite led = GpioWrite (1);
	GpioWrite galvanometer = GpioWrite (2);
	InterruptRead callShock = InterruptRead (4);
	SpiMax7219 display1 = SpiMax7219 (11);
	SpiMax7219 display2 = SpiMax7219 (11);
	SpiMax7219 display3 = SpiMax7219 (11);
	SpiMax7219 display4 = SpiMax7219 (11);
	AnalogRead potentiometerSelect = AnalogRead (16);
	GpioRead buttonCountPerSecondMax = GpioRead (17, true, 10);
	GpioRead buttonDoseMax = GpioRead (18, true, 10);
	AnalogRead voltageBattery = AnalogRead (20);
	bool lowVoltageBattery = false;
	Filter filterVoltageBattery = Filter (500, true);
	Hysteresis hysteresisVoltageBattery = Hysteresis();
	Delay delayLowVoltageBattery = Delay (250, true);
	bool flipFlopLowVoltageBattery = false;
	Timer time = Timer();
	unsigned long long timePreviousShock = 0;
	unsigned long long timeIntervalShock = 0;
	unsigned long countTotalPrevious = 0;
	unsigned long long timePreviousDisplayModeSelect = 0;
	float countPerSecondRaw = 0;
	float doseCurrent = 0;
	float doseMax = 0;
	float countPerSecondMax = 0;
	Filter countPerSecond = Filter (4000, true);
	Filter doseTotal = Filter (4000, true);
	unsigned long countTotalInterval = 0;
	Hysteresis modeSelect = Hysteresis();
	unsigned char modeSelectPrevious = 0;
	unsigned char brightness = 1;
	unsigned char brightnessPrevious = 1;
	bool modeCountPerSecondMax = false;
	bool modeCountPerSecondMaxPrevious = false;
	bool modeDoseMax = false;
	bool modeDoseMaxPrevious = false;
	bool displayModeSelect = false;
	bool displayShock = false;
	bool soundShock = false;
	bool soundOn = false;
	bool soundOff = false;
	bool soundSelect = false;
	bool loopWait = true;
	const float SETUP_CPS_BACKGROUND = 0.36;
	const float SETUP_LOW_VOLTAGE_BATTERY = 6;
	
	time.start (0);
	
	while (loopWait == true)
	{
		potentiometerSelect.read();
		time.state();
		
		if (time.ms >= 100)
		{
			loopWait = false;
		}
	}
	
	modeSelect.set (Math::curve (0, potentiometerSelect.value, 1023, 0, 8, 0));
	modeSelectPrevious = modeSelect.value;
	
	if (modeSelect.value != 0)
	{
		brightness = modeSelect.value * 2;
	}
	
	display1.brightness (brightness);
	display2.brightness (brightness);
	display3.brightness (brightness);
	display4.brightness (brightness);
	
	brightnessPrevious = brightness;
	
	for (iterationAnimation = 8; iterationAnimation >= 1; iterationAnimation--)
	{
		display1.clearDevice();
		display1.draw (byteAnimation, iterationAnimation);
		Timer::pause (10);
	}
	
	for (iterationAnimation = 0; iterationAnimation <= 1; iterationAnimation++)
	{
		byteAnimation = 0b00000100 >> iterationAnimation;
		
		display1.clearDevice();
		display1.draw (byteAnimation, 1);
		Timer::pause (10);
	}
	
	display1.clearDevice();
	
	for (iterationAnimation = 0; iterationAnimation <= 1; iterationAnimation++)
	{
		byteAnimation = 0b00000100 >> iterationAnimation;
		
		display2.clearDevice();
		display2.draw (byteAnimation, 1);
		Timer::pause (10);
	}
	
	display2.clearDevice();
	
	for (iterationAnimation = 0; iterationAnimation <= 1; iterationAnimation++)
	{
		byteAnimation = 0b00000100 >> iterationAnimation;
		
		display3.clearDevice();
		display3.draw (byteAnimation, 1);
		Timer::pause (10);
	}
	
	display3.clearDevice();
	
	for (iterationAnimation = 0; iterationAnimation <= 1; iterationAnimation++)
	{
		byteAnimation = 0b00000100 >> iterationAnimation;
		
		display4.clearDevice();
		display4.draw (byteAnimation, 1);
		Timer::pause (10);
	}
	
	byteAnimation = 0b01000000;
	
	for (iterationAnimation = 1; iterationAnimation <= 8; iterationAnimation++)
	{
		display4.clearDevice();
		display4.draw (byteAnimation, iterationAnimation);
		Timer::pause (10);
	}
	
	for (iterationAnimation = 8; iterationAnimation >= 6; iterationAnimation--)
	{
		if (iterationAnimation != 8)
		{
			byteAnimation = 0b00100000;
		}
		
		for (iterationSubAnimation = 0; iterationSubAnimation <= 4; iterationSubAnimation++)
		{
			byteAnimation |= 0b00100000 >> iterationSubAnimation;
			
			if (iterationSubAnimation == 1 && iterationAnimation == 6)
			{
				byteAnimation |= 0b10000000;
			}
			
			display4.draw (byteAnimation, iterationAnimation);
			Timer::pause (10);
		}
		
		if (iterationAnimation != 8)
		{
			byteAnimation |= 0b01000000;
			
			display4.draw (byteAnimation, iterationAnimation);
			Timer::pause (10);
		}
	}
	
	for (iterationAnimation = 6; iterationAnimation <= 8; iterationAnimation++)
	{
		byteAnimation = 0b00000010;
		
		for (iterationSubAnimation = 0; iterationSubAnimation <= 4; iterationSubAnimation++)
		{
			byteAnimation |= 0b00000010 << iterationSubAnimation;
			
			if (iterationSubAnimation == 2 && iterationAnimation == 6)
			{
				byteAnimation |= 0b10000000;
			}
			
			display3.draw (byteAnimation, iterationAnimation);
			Timer::pause (10);
		}
		
		byteAnimation |= 0b01000000;
		
		display3.draw (byteAnimation, iterationAnimation);
		Timer::pause (10);
	}
	
	for (iterationAnimation = 8; iterationAnimation >= 6; iterationAnimation--)
	{
		byteAnimation = 0b00100000;
		
		for (iterationSubAnimation = 0; iterationSubAnimation <= 4; iterationSubAnimation++)
		{
			byteAnimation |= 0b00100000 >> iterationSubAnimation;
			
			if (iterationSubAnimation == 1 && iterationAnimation == 6)
			{
				byteAnimation |= 0b10000000;
			}
			
			display2.draw (byteAnimation, iterationAnimation);
			Timer::pause (10);
		}
		
		byteAnimation |= 0b01000000;
		
		display2.draw (byteAnimation, iterationAnimation);
		Timer::pause (10);
	}
	
	byteAnimation = 0b01000000;
	
	for (iterationAnimation = 6; iterationAnimation <= 8; iterationAnimation++)
	{
		display1.clearDevice();
		display1.draw (byteAnimation, iterationAnimation);
		Timer::pause (10);
	}
	
	for (iterationAnimation = 0; iterationAnimation <= 4; iterationAnimation++)
	{
		byteAnimation |= 0b00100000 >> iterationAnimation;
		
		display1.draw (byteAnimation, 8);
		Timer::pause (10);
	}
	
	countPerSecond.set (0);
	doseTotal.set (0);
	
	SoundWrite::pin (3);
	
	time.start (0);
	
	callShock.start (0, shock);
	
	while (true)
	{
		time.state();
		
		voltageBattery.read();
		buttonCountPerSecondMax.read();
		buttonDoseMax.read();
		potentiometerSelect.read();
		
		filterVoltageBattery.set (Math::curve (0, voltageBattery.value, 1023, 0, 30, 0));
		hysteresisVoltageBattery.set (filterVoltageBattery.value * 10.0);
		
		if ((float)(hysteresisVoltageBattery.value) / 10.0 < SETUP_LOW_VOLTAGE_BATTERY)
		{
			lowVoltageBattery = true;
		}
		else
		{
			lowVoltageBattery = false;
		}
		
		modeCountPerSecondMax = buttonCountPerSecondMax.bistable;
		
		if (modeCountPerSecondMaxPrevious != modeCountPerSecondMax && time.ms >= 100)
		{
			if (modeCountPerSecondMax == false)
			{
				soundOff = true;
			}
			else
			{
				soundOn = true;
			}
		}
		
		modeCountPerSecondMaxPrevious = modeCountPerSecondMax;
		
		modeDoseMax = buttonDoseMax.bistable;
		
		if (modeDoseMaxPrevious != modeDoseMax && time.ms >= 100)
		{
			if (modeDoseMax == false)
			{
				soundOff = true;
			}
			else
			{
				soundOn = true;
			}
		}
		
		modeDoseMaxPrevious = modeDoseMax;
		
		modeSelect.set (Math::curve (0, potentiometerSelect.value, 1023, 0, 8, 0));
		
		if (modeSelectPrevious != modeSelect.value && time.ms >= 100)
		{
			displayModeSelect = true;
			soundSelect = true;
			
			timePreviousDisplayModeSelect = time.ms;
		}
		
		modeSelectPrevious = modeSelect.value;
		
		if (modeSelect.value != 0)
		{
			brightness = modeSelect.value * 2;
		}
		else
		{
			brightness = 1;
		}
		
		if (brightnessPrevious != brightness)
		{
			display1.brightness (brightness);
			display2.brightness (brightness);
			display3.brightness (brightness);
			display4.brightness (brightness);
		}
		
		brightnessPrevious = brightness;
		
		if (_countTotal != 0)
		{
			if (countTotalPrevious < _countTotal && time.ms > timePreviousShock)
			{
				countTotalInterval = _countTotal - countTotalPrevious;
				timeIntervalShock = time.ms - timePreviousShock;
				
				countPerSecondRaw = ((float)(countTotalInterval) / (float)(timeIntervalShock)) * 1000.0;
				
				countTotalPrevious = _countTotal;
				timePreviousShock = time.ms;
				
				displayShock = true;
				
				if (modeSelect.value != 0)
				{
					soundShock = true;
				}
			}
			else if (time.ms - timePreviousShock >= timeIntervalShock && time.ms > timePreviousShock)
			{
				countPerSecondRaw = ((float)(countTotalInterval) / ((float)(time.ms) - (float)(timePreviousShock))) * 1000.0;
			}
			
			countPerSecond.set (countPerSecondRaw);
			
			if (countPerSecond.value > countPerSecondMax)
			{
				countPerSecondMax = countPerSecond.value;
			}
			
			doseCurrent = countPerSecond.value * (1.0 / SETUP_CPS_BACKGROUND);
			
			if (doseCurrent > doseMax)
			{
				doseMax = doseCurrent;
			}
			
			if (time.ms - timePreviousShock >= timeIntervalShock && time.ms > timePreviousShock)
			{
				doseTotal.set ((float)(_countTotal) / (((float)(time.ms) / 1000.0) * SETUP_CPS_BACKGROUND));
			}
		}
		
		if (lowVoltageBattery == false)
		{
			display1.integer (_countTotal, 1, 8, true);
		}
		else
		{
			delayLowVoltageBattery.state();
			
			if (delayLowVoltageBattery.update == true)
			{
				if (flipFlopLowVoltageBattery == true)
				{
					display1.word (" - - - -");
					flipFlopLowVoltageBattery = false;
				}
				else
				{
					display1.word ("- - - - ");
					flipFlopLowVoltageBattery = true;
				}
			}
		}
		
		if (modeCountPerSecondMax == false)
		{
			display2.decimal (countPerSecond.value, 1, 8, 2, true);
		}
		else
		{
			display2.decimal (countPerSecondMax, 1, 8, 2, true);
		}
		
		display3.decimal (doseTotal.value, 1, 8, 2, true);
		
		if (displayModeSelect == false)
		{
			if (modeDoseMax == false)
			{
				display4.decimal (doseCurrent, 1, 8, 2, true);
			}
			else
			{
				display4.decimal (doseMax, 1, 8, 2, true);
			}
		}
		else
		{
			if (modeSelect.value == 0)
			{
				display4.word ("-----off");
			}
			else
			{
				if (modeSelect.value == 1)
				{
					display4.word (" -------");
				}
				else if (modeSelect.value == 2)
				{
					display4.word ("- ------");
				}
				else if (modeSelect.value == 3)
				{
					display4.word ("-- -----");
				}
				else if (modeSelect.value == 4)
				{
					display4.word ("--- ----");
				}
				else if (modeSelect.value == 5)
				{
					display4.word ("---- ---");
				}
				else if (modeSelect.value == 6)
				{
					display4.word ("----- --");
				}
				else if (modeSelect.value == 7)
				{
					display4.word ("------ -");
				}
				else
				{
					display4.word ("------- ");
				}
				
				display4.digit (modeSelect.value, false, modeSelect.value);
			}
			
			if (time.ms - timePreviousDisplayModeSelect >= 2000)
			{
				displayModeSelect = false;
			}
		}
		
		if (displayShock == true)
		{
			led.on();
			galvanometer.on();
		}
		else if (time.ms - timePreviousShock >= 10)
		{
			led.off();
			galvanometer.off();
		}
		
		displayShock = false;
		
		if (lowVoltageBattery == false)
		{
			if (soundShock == true)
			{
				SoundWrite::play (4096, 2);
			}
			else if (soundOff == true)
			{
				SoundWrite::play (50, 40);
			}
			else if (soundOn == true)
			{
				SoundWrite::add (100, 40);
				SoundWrite::add (0, 40);
				SoundWrite::add (100, 40);
				SoundWrite::play (0, 0);
			}
			else if (soundSelect == true)
			{
				SoundWrite::play (50, 20);
			}
		}
		else if (delayLowVoltageBattery.update == true)
		{
			SoundWrite::play (100, 100);
		}
		
		soundShock = false;
		soundOff = false;
		soundOn = false;
		soundSelect = false;
	}
	
	return 0;
}
