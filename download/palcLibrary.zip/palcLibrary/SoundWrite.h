#include "Core.h"

class SoundWrite
{
	private:
	static unsigned char _countAddKey;
	
	public:
	static void pin (const unsigned char PIN);
	static void play (const float FREQUENCY, const unsigned int DURATION);
	static void add (const float FREQUENCY, const unsigned int DURATION);
	static void modulate (const float FREQUENCY);
	static void stop();
};

unsigned char SoundWrite::_countAddKey = 0;

#include "SoundWrite.cpp"
