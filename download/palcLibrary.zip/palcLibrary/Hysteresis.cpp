Hysteresis::Hysteresis()
{
}

void Hysteresis::set (const float VALUE)
{
	signed long valueHysteresisNext = 0;
	
	if (VALUE > (float)(_valueHysteresisPrevious) + 0.9 || VALUE < (float)(_valueHysteresisPrevious) - 0.9)
	{
		valueHysteresisNext = Core::round (VALUE);
		_valueHysteresisPrevious = valueHysteresisNext;
	}
	else
	{
		valueHysteresisNext = _valueHysteresisPrevious;
	}
	
	value = valueHysteresisNext;
}
