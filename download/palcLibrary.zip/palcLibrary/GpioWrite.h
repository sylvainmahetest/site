#include "Core.h"

class GpioWrite
{
	private:
	volatile unsigned char *_registerPort = 0;
	volatile unsigned char *_registerPin = 0;
	unsigned char _bytePort = 0;
	
	public:
	GpioWrite (const unsigned char PIN);
	void toggle();
	void on();
	void off();
};

#include "GpioWrite.cpp"
