AnalogRead::AnalogRead (const unsigned char PIN_ANALOG)
{
	_byteAdmux = Core::pinToByteAdmux (PIN_ANALOG);
	Core::startAnalog();
}

void AnalogRead::read()
{
	value = Core::readAnalog (_byteAdmux);
}
