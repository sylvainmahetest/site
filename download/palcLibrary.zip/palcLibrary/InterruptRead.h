#ifndef _INTERRUPT_INCLUDED
#define _INTERRUPT_INCLUDED

#include "Core.h"

class InterruptRead
{
	private:
	volatile unsigned char *_registerPcmsk = 0;
	static volatile unsigned char *_registerPcicr;
	unsigned char _bytePcicr = 0;
	bool _hardware = true;
	unsigned char _interrupt = 0;
	
	public:
	InterruptRead (const unsigned char PIN);
	void start (void functionJumpRising(), void functionJumpFalling());
	void stop();
};

volatile unsigned char *InterruptRead::_registerPcicr = Core::registerPinChangeInterrupt();

#include "InterruptRead.cpp"
#endif
