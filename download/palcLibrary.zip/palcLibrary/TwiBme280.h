#include "Core.h"

class TwiBme280
{
	private:
	unsigned char _device = 0;
	unsigned int _digT1 = 0;
	signed int _digT2 = 0;
	signed int _digT3 = 0;
	unsigned int _digP1 = 0;
	signed int _digP2 = 0;
	signed int _digP3 = 0;
	signed int _digP4 = 0;
	signed int _digP5 = 0;
	signed int _digP6 = 0;
	signed int _digP7 = 0;
	signed int _digP8 = 0;
	signed int _digP9 = 0;
	unsigned char _digH1 = 0;
	signed int _digH2 = 0;
	unsigned char _digH3 = 0;
	signed int _digH4 = 0;
	signed int _digH5 = 0;
	signed char _digH6 = 0;
	
	public:
	float humidity = 0;
	float pressure = 0;
	float temperature = 0;
	TwiBme280 (const unsigned char DEVICE);
	void read();
};

#include "TwiBme280.cpp"
