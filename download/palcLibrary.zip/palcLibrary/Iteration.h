#include "Core.h"

class Iteration
{
	private:
	signed long _min = 0;
	signed long _start = 0;
	signed long _max = 0;
	bool _loop = false;
	
	public:
	signed long value = 0;
	Iteration (const signed long MIN, const signed long START, const signed long MAX, const bool LOOP);
	void increment (const signed long INCREMENT);
	void min (const signed long MIN);
	void set (const signed long VALUE);
	void max (const signed long MAX);
	void loop (const bool LOOP);
	void reset();
};

#include "Iteration.cpp"
