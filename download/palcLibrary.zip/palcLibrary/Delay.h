#include "Core.h"

class Delay
{
	private:
	unsigned long long _timePrevious = 0;
	unsigned long long _timeNext = 0;
	unsigned long long _duration = 0;
	bool _noStartDelay = false;
	bool _started = false;
	
	public:
	bool update = false;
	Delay (const unsigned long long DURATION, const bool NO_START_DELAY);
	void state();
	void duration (const unsigned long long DURATION);
	void reset();
};

#include "Delay.cpp"
