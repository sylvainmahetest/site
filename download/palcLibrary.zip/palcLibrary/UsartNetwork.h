#ifndef _USART_INCLUDED
#define _USART_INCLUDED

#include "Core.h"

class UsartNetwork
{
	private:
	unsigned char _address = 0;
	
	public:
	signed long data = 0;
	UsartNetwork (const unsigned char ADDRESS);
	static void start (void functionJump(), const unsigned long ID);
	void receive();
	void transmit (const signed long DATA);
	static void stop();
};

#include "UsartNetwork.cpp"
#endif
