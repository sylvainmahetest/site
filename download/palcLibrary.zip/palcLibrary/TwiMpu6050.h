#include "Core.h"

class TwiMpu6050
{
	private:
	unsigned char _device = 0;
	
	public:
	float tx = 0;
	float ty = 0;
	float tz = 0;
	float rx = 0;
	float ry = 0;
	float rz = 0;
	float temperature = 0;
	TwiMpu6050 (const unsigned char DEVICE);
	void read();
	void readTranslation();
	void readRotation();
	void readTemperature();
};

#include "TwiMpu6050.cpp"
