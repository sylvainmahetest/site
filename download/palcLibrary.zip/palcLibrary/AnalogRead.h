#include "Core.h"

class AnalogRead
{
	private:
	unsigned char _byteAdmux = 0;
	
	public:
	unsigned int value = 0;
	AnalogRead (const unsigned char PIN_ANALOG);
	void read();
};

#include "AnalogRead.cpp"
