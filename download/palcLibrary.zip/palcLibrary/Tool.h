#include "Core.h"

class Tool
{
	public:
	static unsigned char digitToByte (const unsigned char DIGIT, const bool COMMA);
	static unsigned char characterToByte (const char *CHARACTER);
	static unsigned char scanTwi();
	static signed int mcuSram();
	static void mcuSleep();
	static void mcuWakeUp();
};

#include "Tool.cpp"
