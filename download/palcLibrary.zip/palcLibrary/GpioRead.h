#include "Core.h"

class GpioRead
{
	private:
	volatile unsigned char *_registerPin = 0;
	unsigned char _bytePort = 0;
	bool _pullUpInternal = false;
	unsigned char _debouncing = 0;
	unsigned long long _timePreviousBistable = 0;
	unsigned long long _timePreviousMonostable = 0;
	bool _lockMonostable = false;
	
	public:
	bool monostable = false;
	bool bistable = false;
	GpioRead (const unsigned char PIN, const bool PULL_UP_INTERNAL, const unsigned char DEBOUNCING);
	void read();
};

#include "GpioRead.cpp"
