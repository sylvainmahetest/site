#include "Core.h"

class Eeprom
{
	public:
	static signed long read (const unsigned int ADDRESS, const signed char LENGTH);
	static void write (const unsigned int ADDRESS, const signed long DATA, const signed char LENGTH);
	static void erase();
};

#include "Eeprom.cpp"
