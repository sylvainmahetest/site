#if defined _ATMEGA164P || defined _ATMEGA324P || defined _ATMEGA644P || defined _ATMEGA1284P
#define _PINA (volatile unsigned char *)(0x20)
#define _DDRA (volatile unsigned char *)(0x21)
#define _PORTA (volatile unsigned char *)(0x22)
#endif
#define _PINB (volatile unsigned char *)(0x23)
#define _DDRB (volatile unsigned char *)(0x24)
#define _PORTB (volatile unsigned char *)(0x25)
#define _PINC (volatile unsigned char *)(0x26)
#define _DDRC (volatile unsigned char *)(0x27)
#define _PORTC (volatile unsigned char *)(0x28)
#define _PIND (volatile unsigned char *)(0x29)
#define _DDRD (volatile unsigned char *)(0x2a)
#define _PORTD (volatile unsigned char *)(0x2b)
#define _TIFR0 (volatile unsigned char *)(0x35)
#define _TIFR1 (volatile unsigned char *)(0x36)
#define _TIFR2 (volatile unsigned char *)(0x37)
#if defined _ATMEGA1284P
#define _TIFR3 (volatile unsigned char *)(0x38)
#endif
#define _PCIFR (volatile unsigned char *)(0x3b)
#define _EIFR (volatile unsigned char *)(0x3c)
#define _EIMSK (volatile unsigned char *)(0x3d)
#define _GPIOR0 (volatile unsigned char *)(0x3e)
#define _EECR (volatile unsigned char *)(0x3f)
#define _EEDR (volatile unsigned char *)(0x40)
#define _EEARL (volatile unsigned char *)(0x41)
#define _EEARH (volatile unsigned char *)(0x42)
#define _EEARLH (volatile unsigned int *)(0x41)
#define _GTCCR (volatile unsigned char *)(0x43)
#define _TCCR0A (volatile unsigned char *)(0x44)
#define _TCCR0B (volatile unsigned char *)(0x45)
#define _TCNT0 (volatile unsigned char *)(0x46)
#define _OCR0A (volatile unsigned char *)(0x47)
#define _OCR0B (volatile unsigned char *)(0x48)
#define _GPIOR1 (volatile unsigned char *)(0x4a)
#define _GPIOR2 (volatile unsigned char *)(0x4b)
#define _SPCR (volatile unsigned char *)(0x4c)
#define _SPSR (volatile unsigned char *)(0x4d)
#define _SPDR (volatile unsigned char *)(0x4e)
#define _ACSR (volatile unsigned char *)(0x50)
#if defined _ATMEGA164P || defined _ATMEGA324P || defined _ATMEGA644P || defined _ATMEGA1284P
#define _OCDR (volatile unsigned char *)(0x51)
#endif
#define _SMCR (volatile unsigned char *)(0x53)
#define _MCUSR (volatile unsigned char *)(0x54)
#define _MCUCR (volatile unsigned char *)(0x55)
#define _SPMCSR (volatile unsigned char *)(0x57)
#define _SPL (volatile unsigned char *)(0x5d)
#define _SPH (volatile unsigned char *)(0x5e)
#define _SPLH (volatile unsigned int *)(0x5d)
#define _SREG (volatile unsigned char *)(0x5f)
#define _WDTCSR (volatile unsigned char *)(0x60)
#define _CLKPR (volatile unsigned char *)(0x61)
#if defined _ATMEGA48P || defined _ATMEGA88P || defined _ATMEGA168P || defined _ATMEGA328P || defined _ATMEGA164P || defined _ATMEGA324P || defined _ATMEGA644P
#define _PRR (volatile unsigned char *)(0x64)
#elif defined _ATMEGA1284P
#define _PRR0 (volatile unsigned char *)(0x64)
#define _PRR1 (volatile unsigned char *)(0x65)
#endif
#define _OSCCAL (volatile unsigned char *)(0x66)
#define _PCICR (volatile unsigned char *)(0x68)
#define _EICRA (volatile unsigned char *)(0x69)
#define _PCMSK0 (volatile unsigned char *)(0x6b)
#define _PCMSK1 (volatile unsigned char *)(0x6c)
#define _PCMSK2 (volatile unsigned char *)(0x6d)
#define _TIMSK0 (volatile unsigned char *)(0x6e)
#define _TIMSK1 (volatile unsigned char *)(0x6f)
#define _TIMSK2 (volatile unsigned char *)(0x70)
#if defined _ATMEGA1284P
#define _TIMSK3 (volatile unsigned char *)(0x71)
#endif
#if defined _ATMEGA164P || defined _ATMEGA324P || defined _ATMEGA644P || defined _ATMEGA1284P
#define _PCMSK3 (volatile unsigned char *)(0x73)
#endif
#define _ADCL (volatile unsigned char *)(0x78)
#define _ADCH (volatile unsigned char *)(0x79)
#define _ADCLH (volatile unsigned int *)(0x78)
#define _ADCSRA (volatile unsigned char *)(0x7a)
#define _ADCSRB (volatile unsigned char *)(0x7b)
#define _ADMUX (volatile unsigned char *)(0x7c)
#define _DIDR0 (volatile unsigned char *)(0x7e)
#define _DIDR1 (volatile unsigned char *)(0x7f)
#define _TCCR1A (volatile unsigned char *)(0x80)
#define _TCCR1B (volatile unsigned char *)(0x81)
#define _TCCR1C (volatile unsigned char *)(0x82)
#define _TCNT1L (volatile unsigned char *)(0x84)
#define _TCNT1H (volatile unsigned char *)(0x85)
#define _TCNT1LH (volatile unsigned int *)(0x84)
#define _ICR1L (volatile unsigned char *)(0x86)
#define _ICR1H (volatile unsigned char *)(0x87)
#define _ICR1LH (volatile unsigned int *)(0x86)
#define _OCR1AL (volatile unsigned char *)(0x88)
#define _OCR1AH (volatile unsigned char *)(0x89)
#define _OCR1ALH (volatile unsigned int *)(0x88)
#define _OCR1BL (volatile unsigned char *)(0x8a)
#define _OCR1BH (volatile unsigned char *)(0x8b)
#define _OCR1BLH (volatile unsigned int *)(0x8a)
#if defined _ATMEGA1284P
#define _TCCR3A (volatile unsigned char *)(0x90)
#define _TCCR3B (volatile unsigned char *)(0x91)
#define _TCCR3C (volatile unsigned char *)(0x92)
#define _TCNT3L (volatile unsigned char *)(0x94)
#define _TCNT3H (volatile unsigned char *)(0x95)
#define _TCNT3LH (volatile unsigned int *)(0x94)
#define _ICR3L (volatile unsigned char *)(0x96)
#define _ICR3H (volatile unsigned char *)(0x97)
#define _ICR3LH (volatile unsigned int *)(0x96)
#define _OCR3AL (volatile unsigned char *)(0x98)
#define _OCR3AH (volatile unsigned char *)(0x99)
#define _OCR3ALH (volatile unsigned int *)(0x98)
#define _OCR3BL (volatile unsigned char *)(0x9a)
#define _OCR3BH (volatile unsigned char *)(0x9b)
#define _OCR3BLH (volatile unsigned int *)(0x9a)
#endif
#define _TCCR2A (volatile unsigned char *)(0xb0)
#define _TCCR2B (volatile unsigned char *)(0xb1)
#define _TCNT2 (volatile unsigned char *)(0xb2)
#define _OCR2A (volatile unsigned char *)(0xb3)
#define _OCR2B (volatile unsigned char *)(0xb4)
#define _ASSR (volatile unsigned char *)(0xb6)
#define _TWBR (volatile unsigned char *)(0xb8)
#define _TWSR (volatile unsigned char *)(0xb9)
#define _TWAR (volatile unsigned char *)(0xba)
#define _TWDR (volatile unsigned char *)(0xbb)
#define _TWCR (volatile unsigned char *)(0xbc)
#define _TWAMR (volatile unsigned char *)(0xbd)
#define _UCSR0A (volatile unsigned char *)(0xc0)
#define _UCSR0B (volatile unsigned char *)(0xc1)
#define _UCSR0C (volatile unsigned char *)(0xc2)
#define _UBRR0L (volatile unsigned char *)(0xc4)
#define _UBRR0H (volatile unsigned char *)(0xc5)
#define _UBRR0LH (volatile unsigned int *)(0xc4)
#define _UDR0 (volatile unsigned char *)(0xc6)
#if defined _ATMEGA164P || defined _ATMEGA324P || defined _ATMEGA644P || defined _ATMEGA1284P
#define _UCSR1A (volatile unsigned char *)(0xc8)
#define _UCSR1B (volatile unsigned char *)(0xc9)
#define _UCSR1C (volatile unsigned char *)(0xca)
#define _UBRR1L (volatile unsigned char *)(0xcc)
#define _UBRR1H (volatile unsigned char *)(0xcd)
#define _UBRR1LH (volatile unsigned int *)(0xcc)
#define _UDR1 (volatile unsigned char *)(0xce)
#endif

#define _RESET __vector_ ## 0
#define _INT0 __vector_ ## 1
#define _INT1 __vector_ ## 2
#if defined _ATMEGA48P || defined _ATMEGA88P || defined _ATMEGA168P || defined _ATMEGA328P
#define _PCINT0 __vector_ ## 3
#define _PCINT1 __vector_ ## 4
#define _PCINT2 __vector_ ## 5
#define _WDT __vector_ ## 6
#define _TIMER2_COMPA __vector_ ## 7
#define _TIMER2_COMPB __vector_ ## 8
#define _TIMER2_OVF __vector_ ## 9
#define _TIMER1_CAPT __vector_ ## 10
#define _TIMER1_COMPA __vector_ ## 11
#define _TIMER1_COMPB __vector_ ## 12
#define _TIMER1_OVF __vector_ ## 13
#define _TIMER0_COMPA __vector_ ## 14
#define _TIMER0_COMPB __vector_ ## 15
#define _TIMER0_OVF __vector_ ## 16
#define _SPI_STC __vector_ ## 17
#define _USART_RX __vector_ ## 18
#define _USART_UDRE __vector_ ## 19
#define _USART_TX __vector_ ## 20
#define _ADC __vector_ ## 21
#define _EE_READY __vector_ ## 22
#define _ANALOG_COMP __vector_ ## 23
#define _TWI __vector_ ## 24
#define _SPM_READY __vector_ ## 25
#elif defined _ATMEGA164P || defined _ATMEGA324P || defined _ATMEGA644P || defined _ATMEGA1284P
#define _INT2 __vector_ ## 3
#define _PCINT0 __vector_ ## 4
#define _PCINT1 __vector_ ## 5
#define _PCINT2 __vector_ ## 6
#define _PCINT3 __vector_ ## 7
#define _WDT __vector_ ## 8
#define _TIMER2_COMPA __vector_ ## 9
#define _TIMER2_COMPB __vector_ ## 10
#define _TIMER2_OVF __vector_ ## 11
#define _TIMER1_CAPT __vector_ ## 12
#define _TIMER1_COMPA __vector_ ## 13
#define _TIMER1_COMPB __vector_ ## 14
#define _TIMER1_OVF __vector_ ## 15
#define _TIMER0_COMPA __vector_ ## 16
#define _TIMER0_COMPB __vector_ ## 17
#define _TIMER0_OVF __vector_ ## 18
#define _SPI_STC __vector_ ## 19
#define _USART0_RX __vector_ ## 20
#define _USART0_UDRE __vector_ ## 21
#define _USART0_TX __vector_ ## 22
#define _ANALOG_COMP __vector_ ## 23
#define _ADC __vector_ ## 24
#define _EE_READY __vector_ ## 25
#define _TWI __vector_ ## 26
#define _SPM_READY __vector_ ## 27
#define _USART1_RX __vector_ ## 28
#define _USART1_UDRE __vector_ ## 29
#define _USART1_TX __vector_ ## 30
#endif
#if defined _ATMEGA1284P
#define _TIMER3_CAPT __vector_ ## 31
#define _TIMER3_COMPA __vector_ ## 32
#define _TIMER3_COMPB __vector_ ## 33
#define _TIMER3_OVF __vector_ ## 34
#endif

#define _INTERRUPT_JUMP(vector) extern "C" void vector() __attribute__ ((signal)); void vector()

#define _MCU_SLEEP() __asm__ __volatile__ ("sleep")
