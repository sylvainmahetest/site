#ifndef _USART_INCLUDED
#define _USART_INCLUDED

#include "Core.h"

class UsartRs232
{
	public:
	static unsigned char data;
	static void start (void functionJump());
	static void receive();
	static void transmit (const unsigned char DATA);
	static void stop();
};

unsigned char UsartRs232::data = 0;

#include "UsartRs232.cpp"
#endif
