#include "Core.h"

class TwiBno055
{
	private:
	unsigned char _device = 0;
	
	public:
	float gx = 0;
	float gy = 0;
	float gz = 0;
	float tx = 0;
	float ty = 0;
	float tz = 0;
	float rx = 0;
	float ry = 0;
	float rz = 0;
	float mx = 0;
	float my = 0;
	float mz = 0;
	float qw = 0;
	float qx = 0;
	float qy = 0;
	float qz = 0;
	float pitch = 0;
	float pitchAero = 0;
	float roll = 0;
	float rollAero = 0;
	float compass = 0;
	bool north = false;
	signed int temperature = 0;
	TwiBno055 (const unsigned char DEVICE);
	void read();
	void readGravity();
	void readTranslation();
	void readRotation();
	void readQuaternion();
	void readMagnetism();
	void readHorizon();
	void readDirection();
	void readTemperature();
};

#include "TwiBno055.cpp"
