#include "Core.h"

class Timer
{
	private:
	unsigned long long _timeStart = 0;
	bool _started = false;
	
	public:
	unsigned long long s = 0;
	unsigned long long ms = 0;
	unsigned long long us = 0;
	Timer();
	void start (const unsigned long long TIME_START);
	void state();
	void stop();
	static void pause (const unsigned long long DURATION);
};

#include "Timer.cpp"
