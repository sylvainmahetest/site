#include "Core.h"

class Hysteresis
{
	private:
	signed long _valueHysteresisPrevious = 0;
	
	public:
	signed long value = 0;
	Hysteresis();
	void set (const float VALUE);
};

#include "Hysteresis.cpp"
