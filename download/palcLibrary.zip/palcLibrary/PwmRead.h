#ifndef _INTERRUPT_INCLUDED
#define _INTERRUPT_INCLUDED

#include "Core.h"

class PwmRead
{
	private:
	unsigned char _channel = 0;
	static unsigned long long _timePrevious;
	static unsigned int _timeOut;
	static bool _started;
	
	public:
	unsigned long us = 0;
	PwmRead (const unsigned char PIN, const bool RISING);
	static void start (const unsigned int TIME_OUT);
	void read();
	static void stop();
};

unsigned long long PwmRead::_timePrevious = 0;
unsigned int PwmRead::_timeOut = 0;
bool PwmRead::_started = false;

#include "PwmRead.cpp"
#endif
