#include "Core.h"

class Spi25aa1024
{
	private:
	volatile unsigned char *_registerPin = 0;
	unsigned char _bytePort = 0;
	
	public:
	Spi25aa1024 (const unsigned char PIN_SS);
	signed long read (const unsigned long ADDRESS, const signed char LENGTH);
	void write (const unsigned long ADDRESS, const signed long DATA, const signed char LENGTH);
	void erase();
};

#include "Spi25aa1024.cpp"
