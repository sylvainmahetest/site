Period::Period()
{
	Core::startGlobalInterrupt();
	Core::startInterruptTimerCounter();
}

void Period::state()
{
	const unsigned long long US = Core::us();
	
	if (_timePrevious != 0)
	{
		s = (US - _timePrevious) / 1000000ull;
		ms = (US - _timePrevious) / 1000ull;
		us = US - _timePrevious;
	}
	
	_timePrevious = US;
}

void Period::reset()
{
	s = 0;
	ms = 0;
	us = 0;
	
	_timePrevious = 0;
}
