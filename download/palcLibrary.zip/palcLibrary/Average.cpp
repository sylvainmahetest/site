Average::Average (const unsigned char AMOUNT)
{
	_amount = AMOUNT;
}

void Average::set (const float VALUE)
{
	float average = 0;
	unsigned char iterationSet = 0;
	
	if (_amount > 1)
	{
		for (iterationSet = _countSet; iterationSet > 0; iterationSet--)
		{
			_average [iterationSet] = _average [iterationSet - 1];
		}
		
		_average [0] = VALUE;
		
		if (_countSet < _amount)
		{
			_countSet++;
		}
		
		for (iterationSet = 0; iterationSet < _countSet; iterationSet++)
		{
			average += _average [iterationSet];
		}
		
		value = average / (float)(_countSet);
	}
	else
	{
		value = VALUE;
	}
}

void Average::amount (const unsigned char AMOUNT)
{
	_amount = AMOUNT;
}

void Average::reset()
{
	_countSet = 0;
}
