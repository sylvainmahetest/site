volatile unsigned char __pwmReadCountChannel = 0;
volatile unsigned char __pwmReadIterationChannel = 0;
#if defined _ATMEGA48P || defined _ATMEGA88P || defined _ATMEGA168P || defined _ATMEGA328P
volatile unsigned char *__pwmReadRegisterPin [20] = {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
volatile unsigned char __pwmReadBytePort [20] = {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
volatile unsigned char *__pwmReadRegisterPcmsk [20] = {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
volatile unsigned char __pwmReadBytePcicr [20] = {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
volatile bool __pwmReadRising [20] = {false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false};
#elif defined _ATMEGA164P || defined _ATMEGA324P || defined _ATMEGA644P || defined _ATMEGA1284P
volatile unsigned char *__pwmReadRegisterPin [32] = {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
volatile unsigned char __pwmReadBytePort [32] = {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
volatile unsigned char *__pwmReadRegisterPcmsk [32] = {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
volatile unsigned char __pwmReadBytePcicr [32] = {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
volatile bool __pwmReadRising [32] = {false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false};
#endif
volatile unsigned char *__pwmReadRegisterPcicr = Core::registerPinChangeInterrupt();
volatile unsigned char __pwmReadEdge = 0;
volatile unsigned long long __pwmReadTimePrevious = 0;
#if defined _ATMEGA48P || defined _ATMEGA88P || defined _ATMEGA168P || defined _ATMEGA328P
volatile unsigned long __pwmReadUs [20] = {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
#elif defined _ATMEGA164P || defined _ATMEGA324P || defined _ATMEGA644P || defined _ATMEGA1284P
volatile unsigned long __pwmReadUs [32] = {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
#endif
volatile bool __pwmReadValuePin = false;

_INTERRUPT_JUMP (_PCINT0)
{
	__pwmReadValuePin = *__pwmReadRegisterPin [__pwmReadIterationChannel] & __pwmReadBytePort [__pwmReadIterationChannel];
	
	if (__pwmReadEdge == 0 && ((__pwmReadRising [__pwmReadIterationChannel] == true && __pwmReadValuePin == true) || (__pwmReadRising [__pwmReadIterationChannel] == false && __pwmReadValuePin == false)))
	{
		__pwmReadTimePrevious = Core::us();
		__pwmReadEdge = 1;
	}
	else if (__pwmReadEdge == 1 && ((__pwmReadRising [__pwmReadIterationChannel] == true && __pwmReadValuePin == false) || (__pwmReadRising [__pwmReadIterationChannel] == false && __pwmReadValuePin == true)))
	{
		*__pwmReadRegisterPcicr &= ~__pwmReadBytePcicr [__pwmReadIterationChannel];
		*__pwmReadRegisterPcmsk [__pwmReadIterationChannel] = 0b00000000;
		
		__pwmReadUs [__pwmReadIterationChannel] = Core::us() - __pwmReadTimePrevious;
		__pwmReadEdge = 2;
	}
}

_INTERRUPT_JUMP (_PCINT1)
{
	__pwmReadValuePin = *__pwmReadRegisterPin [__pwmReadIterationChannel] & __pwmReadBytePort [__pwmReadIterationChannel];
	
	if (__pwmReadEdge == 0 && ((__pwmReadRising [__pwmReadIterationChannel] == true && __pwmReadValuePin == true) || (__pwmReadRising [__pwmReadIterationChannel] == false && __pwmReadValuePin == false)))
	{
		__pwmReadTimePrevious = Core::us();
		__pwmReadEdge = 1;
	}
	else if (__pwmReadEdge == 1 && ((__pwmReadRising [__pwmReadIterationChannel] == true && __pwmReadValuePin == false) || (__pwmReadRising [__pwmReadIterationChannel] == false && __pwmReadValuePin == true)))
	{
		*__pwmReadRegisterPcicr &= ~__pwmReadBytePcicr [__pwmReadIterationChannel];
		*__pwmReadRegisterPcmsk [__pwmReadIterationChannel] = 0b00000000;
		
		__pwmReadUs [__pwmReadIterationChannel] = Core::us() - __pwmReadTimePrevious;
		__pwmReadEdge = 2;
	}
}

_INTERRUPT_JUMP (_PCINT2)
{
	__pwmReadValuePin = *__pwmReadRegisterPin [__pwmReadIterationChannel] & __pwmReadBytePort [__pwmReadIterationChannel];
	
	if (__pwmReadEdge == 0 && ((__pwmReadRising [__pwmReadIterationChannel] == true && __pwmReadValuePin == true) || (__pwmReadRising [__pwmReadIterationChannel] == false && __pwmReadValuePin == false)))
	{
		__pwmReadTimePrevious = Core::us();
		__pwmReadEdge = 1;
	}
	else if (__pwmReadEdge == 1 && ((__pwmReadRising [__pwmReadIterationChannel] == true && __pwmReadValuePin == false) || (__pwmReadRising [__pwmReadIterationChannel] == false && __pwmReadValuePin == true)))
	{
		*__pwmReadRegisterPcicr &= ~__pwmReadBytePcicr [__pwmReadIterationChannel];
		*__pwmReadRegisterPcmsk [__pwmReadIterationChannel] = 0b00000000;
		
		__pwmReadUs [__pwmReadIterationChannel] = Core::us() - __pwmReadTimePrevious;
		__pwmReadEdge = 2;
	}
}

#if defined _ATMEGA164P || defined _ATMEGA324P || defined _ATMEGA644P || defined _ATMEGA1284P
_INTERRUPT_JUMP (_PCINT3)
{
	__pwmReadValuePin = *__pwmReadRegisterPin [__pwmReadIterationChannel] & __pwmReadBytePort [__pwmReadIterationChannel];
	
	if (__pwmReadEdge == 0 && ((__pwmReadRising [__pwmReadIterationChannel] == true && __pwmReadValuePin == true) || (__pwmReadRising [__pwmReadIterationChannel] == false && __pwmReadValuePin == false)))
	{
		__pwmReadTimePrevious = Core::us();
		__pwmReadEdge = 1;
	}
	else if (__pwmReadEdge == 1 && ((__pwmReadRising [__pwmReadIterationChannel] == true && __pwmReadValuePin == false) || (__pwmReadRising [__pwmReadIterationChannel] == false && __pwmReadValuePin == true)))
	{
		*__pwmReadRegisterPcicr &= ~__pwmReadBytePcicr [__pwmReadIterationChannel];
		*__pwmReadRegisterPcmsk [__pwmReadIterationChannel] = 0b00000000;
		
		__pwmReadUs [__pwmReadIterationChannel] = Core::us() - __pwmReadTimePrevious;
		__pwmReadEdge = 2;
	}
}
#endif

PwmRead::PwmRead (const unsigned char PIN, const bool RISING)
{
	__pwmReadRegisterPin [__pwmReadCountChannel] = Core::pinToRegisterPin (PIN);
	__pwmReadBytePort [__pwmReadCountChannel] = Core::pinToBytePort (PIN);
	__pwmReadRegisterPcmsk [__pwmReadCountChannel] = Core::pinToRegisterPcmsk (PIN);
	__pwmReadBytePcicr [__pwmReadCountChannel] = Core::pinToBytePcicr (PIN);
	__pwmReadRising [__pwmReadCountChannel] = RISING;
	
	_channel = __pwmReadCountChannel;
	
	__pwmReadCountChannel++;
}

void PwmRead::start (const unsigned int TIME_OUT)
{
	const unsigned long long MS = Core::ms();
	
	Core::startGlobalInterrupt();
	Core::startInterruptTimerCounter();
	
	*__pwmReadRegisterPcmsk [0] = __pwmReadBytePort [0];
	*__pwmReadRegisterPcicr |= __pwmReadBytePcicr [0];
	
	_timePrevious = MS;
	_timeOut = TIME_OUT;
	
	_started = true;
}

void PwmRead::read()
{
	const unsigned long long MS = Core::ms();
	
	if (_started == true)
	{
		if (__pwmReadEdge == 2)
		{
		  	if (__pwmReadIterationChannel < __pwmReadCountChannel - 1)
			{
				__pwmReadIterationChannel++;
			}
			else
			{
				__pwmReadIterationChannel = 0;
			}
			
			__pwmReadEdge = 0;
			_timePrevious = MS;
			
			*__pwmReadRegisterPcmsk [__pwmReadIterationChannel] = __pwmReadBytePort [__pwmReadIterationChannel];
			*__pwmReadRegisterPcicr |= __pwmReadBytePcicr [__pwmReadIterationChannel];
		}
		else if (MS > _timePrevious + (unsigned long long)(_timeOut))
		{
			*__pwmReadRegisterPcicr &= ~__pwmReadBytePcicr [__pwmReadIterationChannel];
			*__pwmReadRegisterPcmsk [__pwmReadIterationChannel] = 0b00000000;
			
			if (__pwmReadIterationChannel < __pwmReadCountChannel - 1)
			{
				__pwmReadIterationChannel++;
			}
			else
			{
				__pwmReadIterationChannel = 0;
			}
			
			__pwmReadEdge = 0;
			_timePrevious = MS;
			
			*__pwmReadRegisterPcmsk [__pwmReadIterationChannel] = __pwmReadBytePort [__pwmReadIterationChannel];
			*__pwmReadRegisterPcicr |= __pwmReadBytePcicr [__pwmReadIterationChannel];
		}
		
		us = __pwmReadUs [_channel];
	}
}

void PwmRead::stop()
{
	unsigned char iterationChannel = 0;
	
	if (_started == true)
	{
		for (iterationChannel = 0; iterationChannel < __pwmReadCountChannel; iterationChannel++)
		{
			*__pwmReadRegisterPcicr &= ~__pwmReadBytePcicr [iterationChannel];
			*__pwmReadRegisterPcmsk [iterationChannel] = 0b00000000;
			
			__pwmReadEdge = 0;
		}
		
		__pwmReadIterationChannel = 0;
		
		_started = false;
	}
}
