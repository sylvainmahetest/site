typedef void (*__interruptReadFunction)();

#if defined _ATMEGA48P || defined _ATMEGA88P || defined _ATMEGA168P || defined _ATMEGA328P
volatile unsigned char *__interruptReadRegisterPin [5] = {0, 0, 0, 0, 0};
volatile unsigned char __interruptReadBytePort [5] = {0, 0, 0, 0, 0};
volatile bool __interruptReadRising [5] = {false, false, false, false, false};
volatile bool __interruptReadFalling [5] = {false, false, false, false, false};
volatile __interruptReadFunction __interruptReadFunctionJumpRising [5] = {0, 0, 0, 0, 0};
volatile __interruptReadFunction __interruptReadFunctionJumpFalling [5] = {0, 0, 0, 0, 0};
#elif defined _ATMEGA164P || defined _ATMEGA324P || defined _ATMEGA644P || defined _ATMEGA1284P
volatile unsigned char *__interruptReadRegisterPin [7] = {0, 0, 0, 0, 0, 0, 0};
volatile unsigned char __interruptReadBytePort [7] = {0, 0, 0, 0, 0, 0, 0};
volatile bool __interruptReadRising [7] = {false, false, false, false, false, false, false};
volatile bool __interruptReadFalling [7] = {false, false, false, false, false, false, false};
volatile __interruptReadFunction __interruptReadFunctionJumpRising [7] = {0, 0, 0, 0, 0, 0, 0};
volatile __interruptReadFunction __interruptReadFunctionJumpFalling [7] = {0, 0, 0, 0, 0, 0, 0};
#endif
volatile bool __interruptReadValuePin = false;

_INTERRUPT_JUMP (_INT0)
{
	__interruptReadValuePin = *__interruptReadRegisterPin [0] & __interruptReadBytePort [0];
	
	if (__interruptReadRising [0] == true && __interruptReadValuePin == true)
	{
		__interruptReadFunctionJumpRising [0]();
	}
	
	if (__interruptReadFalling [0] == true && __interruptReadValuePin == false)
	{
		__interruptReadFunctionJumpFalling [0]();
	}
}

_INTERRUPT_JUMP (_INT1)
{
	__interruptReadValuePin = *__interruptReadRegisterPin [1] & __interruptReadBytePort [1];
	
	if (__interruptReadRising [1] == true && __interruptReadValuePin == true)
	{
		__interruptReadFunctionJumpRising [1]();
	}
	
	if (__interruptReadFalling [1] == true && __interruptReadValuePin == false)
	{
		__interruptReadFunctionJumpFalling [1]();
	}
}

#if defined _ATMEGA164P || defined _ATMEGA324P || defined _ATMEGA644P || defined _ATMEGA1284P
_INTERRUPT_JUMP (_INT2)
{
	__interruptReadValuePin = *__interruptReadRegisterPin [2] & __interruptReadBytePort [2];
	
	if (__interruptReadRising [2] == true && __interruptReadValuePin == true)
	{
		__interruptReadFunctionJumpRising [2]();
	}
	
	if (__interruptReadFalling [2] == true && __interruptReadValuePin == false)
	{
		__interruptReadFunctionJumpFalling [2]();
	}
}
#endif

_INTERRUPT_JUMP (_PCINT0)
{
	#if defined _ATMEGA48P || defined _ATMEGA88P || defined _ATMEGA168P || defined _ATMEGA328P
	__interruptReadValuePin = *__interruptReadRegisterPin [2] & __interruptReadBytePort [2];
	
	if (__interruptReadRising [2] == true && __interruptReadValuePin == true)
	{
		__interruptReadFunctionJumpRising [2]();
	}
	
	if (__interruptReadFalling [2] == true && __interruptReadValuePin == false)
	{
		__interruptReadFunctionJumpFalling [2]();
	}
	#elif defined _ATMEGA164P || defined _ATMEGA324P || defined _ATMEGA644P || defined _ATMEGA1284P
	__interruptReadValuePin = *__interruptReadRegisterPin [3] & __interruptReadBytePort [3];
	
	if (__interruptReadRising [3] == true && __interruptReadValuePin == true)
	{
		__interruptReadFunctionJumpRising [3]();
	}
	
	if (__interruptReadFalling [3] == true && __interruptReadValuePin == false)
	{
		__interruptReadFunctionJumpFalling [3]();
	}
	#endif
}

_INTERRUPT_JUMP (_PCINT1)
{
	#if defined _ATMEGA48P || defined _ATMEGA88P || defined _ATMEGA168P || defined _ATMEGA328P
	__interruptReadValuePin = *__interruptReadRegisterPin [3] & __interruptReadBytePort [3];
	
	if (__interruptReadRising [3] == true && __interruptReadValuePin == true)
	{
		__interruptReadFunctionJumpRising [3]();
	}
	
	if (__interruptReadFalling [3] == true && __interruptReadValuePin == false)
	{
		__interruptReadFunctionJumpFalling [3]();
	}
	#elif defined _ATMEGA164P || defined _ATMEGA324P || defined _ATMEGA644P || defined _ATMEGA1284P
	__interruptReadValuePin = *__interruptReadRegisterPin [4] & __interruptReadBytePort [4];
	
	if (__interruptReadRising [4] == true && __interruptReadValuePin == true)
	{
		__interruptReadFunctionJumpRising [4]();
	}
	
	if (__interruptReadFalling [4] == true && __interruptReadValuePin == false)
	{
		__interruptReadFunctionJumpFalling [4]();
	}
	#endif
}

_INTERRUPT_JUMP (_PCINT2)
{
	#if defined _ATMEGA48P || defined _ATMEGA88P || defined _ATMEGA168P || defined _ATMEGA328P
	__interruptReadValuePin = *__interruptReadRegisterPin [4] & __interruptReadBytePort [4];
	
	if (__interruptReadRising [4] == true && __interruptReadValuePin == true)
	{
		__interruptReadFunctionJumpRising [4]();
	}
	
	if (__interruptReadFalling [4] == true && __interruptReadValuePin == false)
	{
		__interruptReadFunctionJumpFalling [4]();
	}
	#elif defined _ATMEGA164P || defined _ATMEGA324P || defined _ATMEGA644P || defined _ATMEGA1284P
	__interruptReadValuePin = *__interruptReadRegisterPin [5] & __interruptReadBytePort [5];
	
	if (__interruptReadRising [5] == true && __interruptReadValuePin == true)
	{
		__interruptReadFunctionJumpRising [5]();
	}
	
	if (__interruptReadFalling [5] == true && __interruptReadValuePin == false)
	{
		__interruptReadFunctionJumpFalling [5]();
	}
	#endif
}

#if defined _ATMEGA164P || defined _ATMEGA324P || defined _ATMEGA644P || defined _ATMEGA1284P
_INTERRUPT_JUMP (_PCINT3)
{
	__interruptReadValuePin = *__interruptReadRegisterPin [6] & __interruptReadBytePort [6];
	
	if (__interruptReadRising [6] == true && __interruptReadValuePin == true)
	{
		__interruptReadFunctionJumpRising [6]();
	}
	
	if (__interruptReadFalling [6] == true && __interruptReadValuePin == false)
	{
		__interruptReadFunctionJumpFalling [6]();
	}
}
#endif

InterruptRead::InterruptRead (const unsigned char PIN)
{
	const unsigned char INTERRUPT = Core::pinToInterruptOrPinChangeInterrupt (PIN);
	
	__interruptReadRegisterPin [INTERRUPT] = Core::pinToRegisterPin (PIN);
	__interruptReadBytePort [INTERRUPT] = Core::pinToBytePort (PIN);
	
	if (Core::pinIsInterrupt (PIN) == false)
	{
		_hardware = false;
		
		_registerPcmsk = Core::pinToRegisterPcmsk (PIN);
		_bytePcicr = Core::pinToBytePcicr (PIN);
	}
	
	_interrupt = INTERRUPT;
}

void InterruptRead::start (void functionJumpRising(), void functionJumpFalling())
{
	if (functionJumpRising != 0)
	{
		__interruptReadRising [_interrupt] = true;
		__interruptReadFunctionJumpRising [_interrupt] = functionJumpRising;
	}
	else
	{
		__interruptReadRising [_interrupt] = false;
		__interruptReadFunctionJumpRising [_interrupt] = 0;
	}
	
	if (functionJumpFalling != 0)
	{
		__interruptReadFalling [_interrupt] = true;
		__interruptReadFunctionJumpFalling [_interrupt] = functionJumpFalling;
	}
	else
	{
		__interruptReadFalling [_interrupt] = false;
		__interruptReadFunctionJumpFalling [_interrupt] = 0;
	}
	
	Core::startGlobalInterrupt();
	
	if (_hardware == true)
	{
		if (functionJumpRising != 0 && functionJumpFalling == 0)
		{
			Core::startInterrupt (_interrupt, true, false);
		}
		else if (functionJumpRising == 0 && functionJumpFalling != 0)
		{
			Core::startInterrupt (_interrupt, false, true);
		}
		else if (functionJumpRising != 0 && functionJumpFalling != 0)
		{
			Core::startInterrupt (_interrupt, true, true);
		}
	}
	else
	{
		*_registerPcmsk |= __interruptReadBytePort [_interrupt];
		*_registerPcicr |= _bytePcicr;
	}
}

void InterruptRead::stop()
{
	if (_hardware == true)
	{
		Core::stopInterrupt (_interrupt);
	}
	else
	{
		*_registerPcicr &= ~_bytePcicr;
		*_registerPcmsk &= ~__interruptReadBytePort [_interrupt];
	}
	
	__interruptReadFunctionJumpRising [_interrupt] = 0;
	__interruptReadFunctionJumpFalling [_interrupt] = 0;
	
	__interruptReadRising [_interrupt] = false;
	__interruptReadFalling [_interrupt] = false;
}
