signed long Math::floor (const float VALUE)
{
	return Core::floor (VALUE);
}

signed long Math::round (const float VALUE)
{
	return Core::round (VALUE);
}

signed long Math::ceil (const float VALUE)
{
	return Core::ceil (VALUE);
}

float Math::curve (const float INPUT_START, const float INPUT_CURRENT, const float INPUT_END, const float OUTPUT_START, const float OUTPUT_END, const float CURVE)
{
	return Core::curve (INPUT_START, INPUT_CURRENT, INPUT_END, OUTPUT_START, OUTPUT_END, CURVE);
}

float Math::wurve (const float INPUT_START, const float INPUT_CURRENT, const float INPUT_END, const float OUTPUT_START, const float OUTPUT_CENTER, const float OUTPUT_END, const float CURVE_START, const float CURVE_END)
{
	return Core::wurve (INPUT_START, INPUT_CURRENT, INPUT_END, OUTPUT_START, OUTPUT_CENTER, OUTPUT_END, CURVE_START, CURVE_END);
}

float Math::range (const float RANGE_START, const float VALUE_CURRENT, const float RANGE_END)
{
	return Core::range (RANGE_START, VALUE_CURRENT, RANGE_END);
}

float Math::center (const float VALUE_START, const float VALUE_END)
{
	return Core::center (VALUE_START, VALUE_END);
}

float Math::pow (const float NUMBER, const unsigned long EXPONENT)
{
	return Core::pow (NUMBER, EXPONENT);
}

float Math::sqrt (const float RADICAND)
{
	return Core::sqrt (RADICAND);
}

unsigned long long Math::fact (const unsigned long INTEGER)
{
	return Core::fact (INTEGER);
}

float Math::sin (const float ANGLE)
{
	return Core::sin (ANGLE);
}

float Math::cos (const float ANGLE)
{
	return Core::cos (ANGLE);
}

float Math::tan (const float ANGLE)
{
	return Core::tan (ANGLE);
}

float Math::arcsin (const float SINUS)
{
	return Core::arcsin (SINUS);
}

float Math::arccos (const float COSINUS)
{
	return Core::arccos (COSINUS);
}

float Math::arctan (const float TANGENT)
{
	return Core::arctan (TANGENT);
}

float Math::arctan2 (const float X, const float Y)
{
	return Core::arctan2 (X, Y);
}
