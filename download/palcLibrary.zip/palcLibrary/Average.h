#include "Core.h"

class Average
{
	private:
	unsigned char _amount = 0;
	unsigned char _countSet = 0;
	float _average [64] = {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
	
	public:
	float value = 0;
	Average (const unsigned char AMOUNT);
	void set (const float VALUE);
	void amount (const unsigned char AMOUNT);
	void reset();
};

#include "Average.cpp"
