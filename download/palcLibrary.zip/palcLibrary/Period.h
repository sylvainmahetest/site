#include "Core.h"

class Period
{
	private:
	unsigned long long _timePrevious = 0;
	
	public:
	unsigned long long s = 0;
	unsigned long long ms = 0;
	unsigned long long us = 0;
	Period();
	void state();
	void reset();
};

#include "Period.cpp"
