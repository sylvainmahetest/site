#include "Core.h"

class Math
{
	public:
	static signed long floor (const float VALUE);
	static signed long round (const float VALUE);
	static signed long ceil (const float VALUE);
	static float curve (const float INPUT_START, const float INPUT_CURRENT, const float INPUT_END, const float OUTPUT_START, const float OUTPUT_END, const float CURVE);
	static float wurve (const float INPUT_START, const float INPUT_CURRENT, const float INPUT_END, const float OUTPUT_START, const float OUTPUT_CENTER, const float OUTPUT_END, const float CURVE_START, const float CURVE_END);
	static float range (const float RANGE_START, const float VALUE_CURRENT, const float RANGE_END);
	static float center (const float VALUE_START, const float VALUE_END);
	static float pow (const float NUMBER, const unsigned long EXPONENT);
	static float sqrt (const float RADICAND);
	static unsigned long long fact (const unsigned long INTEGER);
	static float sin (const float ANGLE);
	static float cos (const float ANGLE);
	static float tan (const float ANGLE);
	static float arcsin (const float SINUS);
	static float arccos (const float COSINUS);
	static float arctan (const float TANGENT);
	static float arctan2 (const float X, const float Y);
};

#include "Math.cpp"
