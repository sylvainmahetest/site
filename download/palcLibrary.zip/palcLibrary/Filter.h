#include "Core.h"

class Filter
{
	private:
	unsigned long _amount = 0;
	bool _timeCompensation = false;
	bool _firstSet = false;
	unsigned long long _timePrevious = 0;
	
	public:
	float value = 0;
	Filter (const unsigned long AMOUNT, const bool TIME_COMPENSATION);
	void set (const float VALUE);
	void amount (const unsigned long AMOUNT);
	void reset();
};

#include "Filter.cpp"
