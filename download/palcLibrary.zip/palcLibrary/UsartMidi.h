#ifndef _USART_INCLUDED
#define _USART_INCLUDED

#include "Core.h"

class UsartMidi
{
	public:
	static unsigned char status;
	static unsigned char data;
	static unsigned char description;
	static void start (void functionJump());
	static void receive();
	static void transmit (const unsigned char STATUS, const unsigned char DATA, const unsigned char DESCRIPTION);
	static void stop();
};

unsigned char UsartMidi::status = 0;
unsigned char UsartMidi::data = 0;
unsigned char UsartMidi::description = 0;

#include "UsartMidi.cpp"
#endif
