#include "Core.h"

class Random
{
	private:
	static unsigned char _byteAdmux;
	static bool _analog;
	static unsigned long _seed;
	
	public:
	static void seed (const unsigned char PIN_ANALOG);
	static bool boolean();
	static signed long integer (const signed long MIN, const signed long MAX);
};

unsigned char Random::_byteAdmux = 0;
bool Random::_analog = false;
unsigned long Random::_seed = 0;

#include "Random.cpp"
