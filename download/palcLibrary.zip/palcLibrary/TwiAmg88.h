#include "Core.h"

class TwiAmg88
{
	private:
	unsigned char _device = 0;
	
	public:
	float temperature [64] = {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
	TwiAmg88 (const unsigned char DEVICE);
	void read();
};

#include "TwiAmg88.cpp"
